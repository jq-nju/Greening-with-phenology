
clear
clc

load('MCD19A3_NDVI_ALPHA_2000_2020.mat')
load('MCD19A3_NDVI_BETA_2000_2020.mat')
load('MCD19A3_NDVI_AMP_2000_2020.mat')
load('MCD19A3_NDVI_SPL_2000_2020.mat')
load('MCD19A3_NDVI_APL_2000_2020.mat')
load('MCD19A3_NDVI_NDVIgs_2000_2020.mat')

% fill missing values (e.g., NAN)
MCD19A3_NDVI_ALPHA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        ALPHA = MCD19A3_NDVI_ALPHA_2000_2020 (i,j,:);
        ALPHA = ALPHA (1,:);

        ALPHA (ALPHA >= 1) = nan;
        ALPHA (ALPHA <= 0) = nan;

        nan_length = length (ALPHA (isnan (ALPHA)));

        if nan_length ~= 19

            outlier_1 = nanmean (ALPHA) - 3*nanstd (ALPHA);
            outlier_2 = nanmean (ALPHA) + 3*nanstd (ALPHA);

            ALPHA (ALPHA < outlier_1) = nan;
            ALPHA (ALPHA > outlier_2) = nan;

            MCD19A3_NDVI_ALPHA_2000_2020_filled (i,j,:) = fillmissing(ALPHA,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_ALPHA_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_ALPHA_2000_2020_filled MCD19A3_NDVI_ALPHA_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_BETA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        BETA = MCD19A3_NDVI_BETA_2000_2020 (i,j,:);
        BETA = BETA (1,:);

        BETA (BETA >= 1) = nan;
        BETA (BETA <= 0) = nan;

        nan_length = length (BETA (isnan (BETA)));

        if nan_length ~= 19

            outlier_1 = nanmean (BETA) - 3*nanstd (BETA);
            outlier_2 = nanmean (BETA) + 3*nanstd (BETA);

            BETA (BETA < outlier_1) = nan;
            BETA (BETA > outlier_2) = nan;

            MCD19A3_NDVI_BETA_2000_2020_filled (i,j,:) = fillmissing(BETA,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_BETA_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_BETA_2000_2020_filled MCD19A3_NDVI_BETA_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_AMP_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        MAX = MCD19A3_NDVI_AMP_2000_2020 (i,j,:);
        MAX = MAX (1,:);

        MAX (MAX <= 0) = nan;
        MAX (MAX >= 1) = nan;

        nan_length = length (MAX (isnan (MAX)));

        if nan_length ~= 19

            outlier_1 = nanmean (MAX) - 3*nanstd (MAX);
            outlier_2 = nanmean (MAX) + 3*nanstd (MAX);

            MAX (MAX < outlier_1) = nan;
            MAX (MAX > outlier_2) = nan;

            MCD19A3_NDVI_AMP_2000_2020_filled (i,j,:) = fillmissing(MAX,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_AMP_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_AMP_2000_2020_filled MCD19A3_NDVI_AMP_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_SPL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        spl = MCD19A3_NDVI_SPL_2000_2020 (i,j,:);
        spl = spl (1,:);

        spl (spl >= 365) = nan;
        spl (spl <= 0) = nan;

        nan_length = length (spl (isnan (spl)));

        if nan_length ~= 19

            outlier_1 = nanmean (spl) - 3*nanstd (spl);
            outlier_2 = nanmean (spl) + 3*nanstd (spl);

            spl (spl < outlier_1) = nan;
            spl (spl > outlier_2) = nan;

            MCD19A3_NDVI_SPL_2000_2020_filled (i,j,:) = fillmissing(spl,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_SPL_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_SPL_2000_2020_filled MCD19A3_NDVI_SPL_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_APL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        APL = MCD19A3_NDVI_APL_2000_2020 (i,j,:);
        APL = APL (1,:);

        APL (APL >= 365) = nan;
        APL (APL <= 0) = nan;

        nan_length = length (APL (isnan (APL)));

        if nan_length ~= 19

            outlier_1 = nanmean (APL) - 3*nanstd (APL);
            outlier_2 = nanmean (APL) + 3*nanstd (APL);

            APL (APL < outlier_1) = nan;
            APL (APL > outlier_2) = nan;

            MCD19A3_NDVI_APL_2000_2020_filled (i,j,:) = fillmissing(APL,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_APL_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_APL_2000_2020_filled MCD19A3_NDVI_APL_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_NDVIgs_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        NDVIgs = MCD19A3_NDVI_NDVIgs_2000_2020 (i,j,:);
        NDVIgs = NDVIgs (1,:);

        NDVIgs (NDVIgs <= 0) = nan;
        NDVIgs (NDVIgs >= 365) = nan;

        nan_length = length (NDVIgs (isnan (NDVIgs)));

        if nan_length ~= 19

            outlier_1 = nanmean (NDVIgs) - 3*nanstd (NDVIgs);
            outlier_2 = nanmean (NDVIgs) + 3*nanstd (NDVIgs);

            NDVIgs (NDVIgs < outlier_1) = nan;
            NDVIgs (NDVIgs > outlier_2) = nan;

            MCD19A3_NDVI_NDVIgs_2000_2020_filled (i,j,:) = fillmissing(NDVIgs,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_NDVIgs_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_NDVIgs_2000_2020_filled MCD19A3_NDVI_NDVIgs_2000_2020_filled