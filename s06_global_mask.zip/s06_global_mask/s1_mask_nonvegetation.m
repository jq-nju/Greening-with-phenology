%% to generate a mask to exclude non-vegetation pixels
%% ref: Tian et al., GCB, 2024; Shen et al., AFM, 2014

% exclude "permanent bare/built/snow/water" pixels
% exclude "spare vegetation" pixels

clear
clc

load('MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled_sgfilter.mat')
load('MCD12C1_LCC_2001_2020_05degree.mat')

MCD12C1_LCC_2001_2020_05degree = MCD12C1_LCC_2001_2020_05degree (7:353,:,:);

% i = 110; j = 585; % this is a winter wheat pixel
% i = 75;  j = 620; % this is a northern forest pixel
for i = 1:347
    for j = 1:720
        
        %% MCD12C1 land cover types
        lcc = MCD12C1_LCC_2001_2020_05degree (i,j,:);
        lcc = lcc (1,:);
        
        lcc (lcc == 0)  = 0; % water bodies
        lcc (lcc == 11) = 0; % wetlands
        lcc (lcc == 13) = 0; % urban and built-up
        lcc (lcc == 15) = 0; % snow and ice
        lcc (lcc == 16) = 0; % barren
        
        non_vegetation_length = length (lcc (lcc == 0));
        
        %% sparse vegetation
        ndvi = MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled_sgfilter (i,j,:);
        ndvi = ndvi (1,:);
        ndvi (ndvi <= 0) = nan;
        
        ndvi_array = reshape (ndvi, [24,21]);
        
        for year = 1:21
            annual_mean_ndvi (year) = mean (ndvi_array(:,year));
        end
        
        annual_mean_ndvi_length = length (annual_mean_ndvi (annual_mean_ndvi > 0.1));
        
        %% mask
        if non_vegetation_length == 20 || annual_mean_ndvi_length ~= 21
            mask_nonvegetation (i,j) = 0;
        else
            mask_nonvegetation (i,j) = 1;
        end
        
    end
end

save mask_nonvegetation mask_nonvegetation