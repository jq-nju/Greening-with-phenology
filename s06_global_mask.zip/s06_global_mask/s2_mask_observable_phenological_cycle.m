%% to generate a mask for observable phenological cycles
%% ref: Tian et al., GCB, 2024; Shen et al., AFM, 2014

clear
clc

load('MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled_sgfilter.mat')
load('mask_nonvegetation.mat')

for i = 1:347
    for j = 1:720

        % i = 110; j = 585; % this is a winter wheat pixel
        % i = 75;  j = 620; % this is a northern forest pixel
        mask = mask_nonvegetation (i,j);
        ndvi = MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled_sgfilter (i,j,:);
        ndvi = ndvi (1,:);

        ndvi_array = reshape (ndvi, [24,21]);

        if mask == 1

            %% 1.2 times
            for year = 1:21
                max_ndvi (year) = max (ndvi_array(:,year));
                min_ndvi (year) = min (ndvi_array(:,year));
            end

            ratio_ndvi = max_ndvi./min_ndvi;
            ratio_length = length (ratio_ndvi (ratio_ndvi > 1.2));

            %% harmonic analysis
            for year = 1:21
                ndvi_annual = ndvi_array(:,year);
                ndvi_3years = [ndvi_annual',ndvi_annual',ndvi_annual'];

                L = length(ndvi_3years);

                startyear = 2001;
                endyear   = 2003;
                yr_num = length(startyear:endyear);

                X = normalize(ndvi_3years);
                Y = fft(X,[]);
                P1 = abs(Y/L);

                first_h  = P1 (yr_num + 1);
                second_h = P1 (yr_num*2 + 1);

                harmo_ratio (year) = second_h / first_h;
            end

            harmo_ratio_length = length (harmo_ratio (harmo_ratio < 0.75));

            %% mask
            if ratio_length == 21 && harmo_ratio_length == 21
                mask_phenological_cycle (i,j) = 1;
            else
                mask_phenological_cycle (i,j) = 0;
            end

        else
            mask_phenological_cycle (i,j) = nan;
        end
    end
end

save mask_phenological_cycle mask_phenological_cycle