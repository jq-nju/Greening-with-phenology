%% snow pixels filled by 5th percentile

clear
clc

load('chl_15days_05degree_2003_2011.mat')
load('Freeze_Thaw_2003_2011_05degree.mat')

chl_15days_05degree_2003_2011 = chl_15days_05degree_2003_2011 (7:353,:,:);
chl_15days_05degree_2003_2011_snowfilled = zeros (347,720,234);
Freeze_Thaw_mask = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        % i = 120; j = 582;
        chl = chl_15days_05degree_2003_2011 (i,j,:);
        chl = chl (1,:);
        
        chl (chl <= 0)  = nan;
        chl (chl >= 100) = nan;
        chl (isnan (chl)) = 0;
        
        nan_length = length (chl (chl == 0));
        
        if nan_length >= 200 % background pixels
        % if nan_length == 234 % background pixels
            
            chl_15days_05degree_2003_2011_snowfilled (i,j,:) = 0;
            
        else
            
            %             ft_01 = Freeze_Thaw_1982_05degree (i,j,:); ft_01 = ft_01 (1,7:14:365);
            %             ft_02 = Freeze_Thaw_1983_05degree (i,j,:); ft_02 = ft_02 (1,7:14:365);
            %             ft_03 = Freeze_Thaw_1984_05degree (i,j,:); ft_03 = ft_03 (1,7:14:365);
            %             ft_04 = Freeze_Thaw_1985_05degree (i,j,:); ft_04 = ft_04 (1,7:14:365);
            %             ft_05 = Freeze_Thaw_1986_05degree (i,j,:); ft_05 = ft_05 (1,7:14:365);
            %             ft_06 = Freeze_Thaw_1987_05degree (i,j,:); ft_06 = ft_06 (1,7:14:365);
            %             ft_07 = Freeze_Thaw_1988_05degree (i,j,:); ft_07 = ft_07 (1,7:14:365);
            %             ft_08 = Freeze_Thaw_1989_05degree (i,j,:); ft_08 = ft_08 (1,7:14:365);
            %             ft_09 = Freeze_Thaw_1990_05degree (i,j,:); ft_09 = ft_09 (1,7:14:365);
            %             ft_10 = Freeze_Thaw_1991_05degree (i,j,:); ft_10 = ft_10 (1,7:14:365);
            %             ft_11 = Freeze_Thaw_1992_05degree (i,j,:); ft_11 = ft_11 (1,7:14:365);
            %             ft_12 = Freeze_Thaw_1993_05degree (i,j,:); ft_12 = ft_12 (1,7:14:365);
            %             ft_13 = Freeze_Thaw_1994_05degree (i,j,:); ft_13 = ft_13 (1,7:14:365);
            %             ft_14 = Freeze_Thaw_1995_05degree (i,j,:); ft_14 = ft_14 (1,7:14:365);
            %             ft_15 = Freeze_Thaw_1996_05degree (i,j,:); ft_15 = ft_15 (1,7:14:365);
            %             ft_16 = Freeze_Thaw_1997_05degree (i,j,:); ft_16 = ft_16 (1,7:14:365);
            %             ft_17 = Freeze_Thaw_1998_05degree (i,j,:); ft_17 = ft_17 (1,7:14:365);
            %             ft_18 = Freeze_Thaw_1999_05degree (i,j,:); ft_18 = ft_18 (1,7:14:365);
            %             ft_19 = Freeze_Thaw_2000_05degree (i,j,:); ft_19 = ft_19 (1,7:14:365);
            %             ft_20 = Freeze_Thaw_2001_05degree (i,j,:); ft_20 = ft_20 (1,7:14:365);
            %             ft_21 = Freeze_Thaw_2002_05degree (i,j,:); ft_21 = ft_21 (1,7:14:365);
            ft_22 = Freeze_Thaw_2003_05degree (i,j,:); ft_22 = ft_22 (1,7:14:365);
            ft_23 = Freeze_Thaw_2004_05degree (i,j,:); ft_23 = ft_23 (1,7:14:365);
            ft_24 = Freeze_Thaw_2005_05degree (i,j,:); ft_24 = ft_24 (1,7:14:365);
            ft_25 = Freeze_Thaw_2006_05degree (i,j,:); ft_25 = ft_25 (1,7:14:365);
            ft_26 = Freeze_Thaw_2007_05degree (i,j,:); ft_26 = ft_26 (1,7:14:365);
            ft_27 = Freeze_Thaw_2008_05degree (i,j,:); ft_27 = ft_27 (1,7:14:365);
            ft_28 = Freeze_Thaw_2009_05degree (i,j,:); ft_28 = ft_28 (1,7:14:365);
            ft_29 = Freeze_Thaw_2010_05degree (i,j,:); ft_29 = ft_29 (1,7:14:365);
            ft_30 = Freeze_Thaw_2011_05degree (i,j,:); ft_30 = ft_30 (1,7:14:365);
            %             ft_31 = Freeze_Thaw_2012_05degree (i,j,:); ft_31 = ft_31 (1,7:14:365);
            %             ft_32 = Freeze_Thaw_2013_05degree (i,j,:); ft_32 = ft_32 (1,7:14:365);
            %             ft_33 = Freeze_Thaw_2014_05degree (i,j,:); ft_33 = ft_33 (1,7:14:365);
            %             ft_34 = Freeze_Thaw_2015_05degree (i,j,:); ft_34 = ft_34 (1,7:14:365);
            %             ft_35 = Freeze_Thaw_2016_05degree (i,j,:); ft_35 = ft_35 (1,7:14:365);
            %             ft_36 = Freeze_Thaw_2017_05degree (i,j,:); ft_36 = ft_36 (1,7:14:365);
            %             ft_37 = Freeze_Thaw_2018_05degree (i,j,:); ft_37 = ft_37 (1,7:14:365);
            %             ft_38 = Freeze_Thaw_2019_05degree (i,j,:); ft_38 = ft_38 (1,7:14:365);
            %             ft_39 = Freeze_Thaw_2020_05degree (i,j,:); ft_39 = ft_39 (1,7:14:365);
            
            ft = [ft_22,ft_23,ft_24,ft_25,ft_26,ft_27,ft_28,ft_29,ft_30];
            ft = single (ft);
            
            % generate a freeze-thaw mask
            ft_length = length (ft (ft == 253));
            if ft_length == 234 % no freeze
                Freeze_Thaw_mask (i,j) = 1;
            else
                Freeze_Thaw_mask (i,j) = 0;
            end
            
            chl (ft == 0) = nan; % Frozen (AM and PM frozen)
            chl (ft == 2) = nan; % Transitional (AM frozen, PM thawed)
            chl (ft == 3) = nan; % Inverse Transitional (AM thawed, PM frozen)
            
            data = chl;
            data (isnan (data)) = [];
            
            chl_background = prctile(data,5);
            chl (isnan (chl)) = chl_background;
            
            chl (chl < chl_background) = chl_background;
            
            chl_15days_05degree_2003_2011_snowfilled (i,j,:) = chl;
        end
    end
end

chl_15days_05degree_2003_2011_snowfilled = single (chl_15days_05degree_2003_2011_snowfilled);
save chl_15days_05degree_2003_2011_snowfilled chl_15days_05degree_2003_2011_snowfilled
save Freeze_Thaw_mask Freeze_Thaw_mask

% convert .mat into tiff files
filepath = 'D:\decompose LAI\s13_greenness_LCC\s02_global LCC_01degree_snow_filled\geoinfo_resize.tif';
[Data, R] = geotiffread(filepath);
info = geotiffinfo(filepath);
geotiffwrite('chl_15days_05degree_2003_2011_snowfilled', chl_15days_05degree_2003_2011_snowfilled, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);