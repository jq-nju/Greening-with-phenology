
clear
clc

load('LCC_NDVIgs_2003_2011.mat')

% fill missing values (e.g., NAN)
LCC_NDVIgs_2003_2011_filled = zeros (347,720,7);

for i = 1:347
    for j = 1:720
        
        NDVIgs = LCC_NDVIgs_2003_2011 (i,j,:);
        NDVIgs = NDVIgs (1,:);
        
        NDVIgs (NDVIgs <= 0) = nan;
        NDVIgs (NDVIgs >= 30000) = nan;
        
        nan_length = length (NDVIgs (isnan (NDVIgs)));
        
        if nan_length ~= 7
            
            outlier_1 = nanmean (NDVIgs) - 3*nanstd (NDVIgs);
            outlier_2 = nanmean (NDVIgs) + 3*nanstd (NDVIgs);
            
            NDVIgs (NDVIgs < outlier_1) = nan;
            NDVIgs (NDVIgs > outlier_2) = nan;
            
            LCC_NDVIgs_2003_2011_filled (i,j,:) = fillmissing(NDVIgs,'linear','EndValues','nearest');
            
        else
            
            LCC_NDVIgs_2003_2011_filled (i,j,:) = nan;
            
        end
        
    end
end

save LCC_NDVIgs_2003_2011_filled LCC_NDVIgs_2003_2011_filled