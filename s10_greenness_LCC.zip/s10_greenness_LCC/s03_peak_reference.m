
clear
clc

% load data
load('chl_15days_05degree_2003_2011_snowfilled_sgfilter.mat')
load('mask_phenological_cycle.mat')

LCC_PKD_reference = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        
        % i = 120; j = 582;
        if mask == 1
            timeseries = chl_15days_05degree_2003_2011_snowfilled_sgfilter (i,j,:);
            timeseries = timeseries (1,:);
            
            % calculate average
            timeseries_matrix = reshape(timeseries,[26,234/26]);
            timeseries_matrix = timeseries_matrix';
            
            lcc_average = mean (timeseries_matrix);
            
            % daily interpolation
            lcc_3years = [lcc_average,lcc_average,lcc_average];
            
            xx = 1:1095;
            x_1 = 7:14:365;
            x_2 = x_1 + 365;
            x_3 = x_2 + 365;
            
            x_3years = [x_1,x_2,x_3];
            
            daily_lcc_reference = interp1 (x_3years,lcc_3years,xx,'spline');
            daily_lcc_reference = daily_lcc_reference (1,366:730);
            
            peak_date_lcc_average = find (daily_lcc_reference == max (daily_lcc_reference));
            LCC_PKD_reference (i,j) = peak_date_lcc_average (1);
            
        else
            LCC_PKD_reference (i,j) = nan;
        end
        
    end
end

save LCC_PKD_reference LCC_PKD_reference