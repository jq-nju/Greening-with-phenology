
clear
clc

load('AAA_gcc_NDVI_differential_components.mat')

%% acadia
% gcc
years = 1:length (acadia_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;acadia_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
acadia_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (acadia_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;acadia_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
acadia_NDVI_differential_APL_slope = sen;

%% bartlett
% gcc
years = 1:length (bartlett_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;bartlett_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
bartlett_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (bartlett_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;bartlett_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
bartlett_NDVI_differential_APL_slope = sen;

%% butte
% gcc
years = 1:length (butte_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;butte_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
butte_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (butte_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;butte_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
butte_NDVI_differential_APL_slope = sen;

%% canadaOBS
% gcc
years = 1:length (canadaOBS_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;canadaOBS_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
canadaOBS_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (canadaOBS_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;canadaOBS_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
canadaOBS_NDVI_differential_APL_slope = sen;

%% caryinstitute
% gcc
years = 1:length (caryinstitute_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;caryinstitute_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
caryinstitute_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (caryinstitute_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;caryinstitute_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
caryinstitute_NDVI_differential_APL_slope = sen;

%% dollysods
% gcc
years = 1:length (dollysods_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;dollysods_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
dollysods_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (dollysods_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;dollysods_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
dollysods_NDVI_differential_APL_slope = sen;

%% harvard
% gcc
years = 1:length (harvard_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvard_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvard_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (harvard_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvard_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvard_NDVI_differential_APL_slope = sen;

%% harvardbarn
% gcc
years = 1:length (harvardbarn_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvardbarn_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvardbarn_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (harvardbarn_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvardbarn_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvardbarn_NDVI_differential_APL_slope = sen;

%% harvardblo
% gcc
years = 1:length (harvardblo_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvardblo_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvardblo_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (harvardblo_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvardblo_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvardblo_NDVI_differential_APL_slope = sen;

%% harvardhemlock
% gcc
years = 1:length (harvardhemlock_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvardhemlock_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvardhemlock_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (harvardhemlock_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;harvardhemlock_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
harvardhemlock_NDVI_differential_APL_slope = sen;

%% howland1
% gcc
years = 1:length (howland1_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;howland1_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
howland1_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (howland1_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;howland1_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
howland1_NDVI_differential_APL_slope = sen;

%% lethbridge
% gcc
years = 1:length (lethbridge_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;lethbridge_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
lethbridge_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (lethbridge_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;lethbridge_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
lethbridge_NDVI_differential_APL_slope = sen;

%% mammothcave
% gcc
years = 1:length (mammothcave_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;mammothcave_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
mammothcave_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (mammothcave_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;mammothcave_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
mammothcave_NDVI_differential_APL_slope = sen;

%% monture_1000
% gcc
years = 1:length (monture_1000_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;monture_1000_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
monture_1000_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (monture_1000_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;monture_1000_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
monture_1000_NDVI_differential_APL_slope = sen;

%% monture_2000
% gcc
years = 1:length (monture_2000_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;monture_2000_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
monture_2000_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (monture_2000_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;monture_2000_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
monture_2000_NDVI_differential_APL_slope = sen;

%% morganmonroe
% gcc
years = 1:length (morganmonroe_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;morganmonroe_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
morganmonroe_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (morganmonroe_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;morganmonroe_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
morganmonroe_NDVI_differential_APL_slope = sen;

%% nationalcapital
% gcc
years = 1:length (nationalcapital_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;nationalcapital_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
nationalcapital_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (nationalcapital_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;nationalcapital_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
nationalcapital_NDVI_differential_APL_slope = sen;

%% oregon
% gcc
years = 1:length (oregon_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;oregon_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
oregon_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (oregon_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;oregon_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
oregon_NDVI_differential_APL_slope = sen;

%% pointreyes
% gcc
years = 1:length (pointreyes_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;pointreyes_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
pointreyes_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (pointreyes_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;pointreyes_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
pointreyes_NDVI_differential_APL_slope = sen;

%% proctor
% gcc
years = 1:length (proctor_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;proctor_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
proctor_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (proctor_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;proctor_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
proctor_NDVI_differential_APL_slope = sen;

%% shiningrock
% gcc
years = 1:length (shiningrock_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;shiningrock_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
shiningrock_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (shiningrock_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;shiningrock_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
shiningrock_NDVI_differential_APL_slope = sen;

%% smokylook
% gcc
years = 1:length (smokylook_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;smokylook_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
smokylook_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (smokylook_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;smokylook_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
smokylook_NDVI_differential_APL_slope = sen;

%% smokypurchase
% gcc
years = 1:length (smokypurchase_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;smokypurchase_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
smokypurchase_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (smokypurchase_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;smokypurchase_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
smokypurchase_NDVI_differential_APL_slope = sen;

%% teddy
% gcc
years = 1:length (teddy_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;teddy_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
teddy_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (teddy_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;teddy_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
teddy_NDVI_differential_APL_slope = sen;

%% tonzi
% gcc
years = 1:length (tonzi_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;tonzi_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
tonzi_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (tonzi_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;tonzi_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
tonzi_NDVI_differential_APL_slope = sen;

%% uiefmaize
% gcc
years = 1:length (uiefmaize_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefmaize_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefmaize_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (uiefmaize_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefmaize_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefmaize_NDVI_differential_APL_slope = sen;

%% uiefmiscanthus
% gcc
years = 1:length (uiefmiscanthus_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefmiscanthus_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefmiscanthus_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (uiefmiscanthus_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefmiscanthus_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefmiscanthus_NDVI_differential_APL_slope = sen;

%% uiefprairie
% gcc
years = 1:length (uiefprairie_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefprairie_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefprairie_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (uiefprairie_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefprairie_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefprairie_NDVI_differential_APL_slope = sen;

%% uiefswitchgrass
% gcc
years = 1:length (uiefswitchgrass_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefswitchgrass_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefswitchgrass_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (uiefswitchgrass_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;uiefswitchgrass_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
uiefswitchgrass_NDVI_differential_APL_slope = sen;

%% vaira
% gcc
years = 1:length (vaira_gcc_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;vaira_gcc_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
vaira_gcc_differential_APL_slope = sen;

% NDVI
years = 1:length (vaira_NDVI_differential_APL);
significance_alpha = 0.1; % significance level: 95%
wantplot = 0;

datain = [years;vaira_NDVI_differential_APL];
datain = datain';
[h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
vaira_NDVI_differential_APL_slope = sen;

%% by combined
%% gcc
gcc_differential_APL_slope_allsites = [acadia_gcc_differential_APL_slope,...
    bartlett_gcc_differential_APL_slope,...
    butte_gcc_differential_APL_slope,...
    canadaOBS_gcc_differential_APL_slope,...
    caryinstitute_gcc_differential_APL_slope,...
    dollysods_gcc_differential_APL_slope,...
    harvard_gcc_differential_APL_slope,...
    harvardbarn_gcc_differential_APL_slope,...
    harvardblo_gcc_differential_APL_slope,...
    harvardhemlock_gcc_differential_APL_slope,...
    howland1_gcc_differential_APL_slope,...
    lethbridge_gcc_differential_APL_slope,...
    mammothcave_gcc_differential_APL_slope,...
    monture_1000_gcc_differential_APL_slope,...
    monture_2000_gcc_differential_APL_slope,...
    morganmonroe_gcc_differential_APL_slope,...
    nationalcapital_gcc_differential_APL_slope,...
    oregon_gcc_differential_APL_slope,...
    pointreyes_gcc_differential_APL_slope,...
    proctor_gcc_differential_APL_slope,...
    shiningrock_gcc_differential_APL_slope,...
    smokylook_gcc_differential_APL_slope,...
    smokypurchase_gcc_differential_APL_slope,...
    teddy_gcc_differential_APL_slope,...
    tonzi_gcc_differential_APL_slope,...
    uiefmaize_gcc_differential_APL_slope,...
    uiefmiscanthus_gcc_differential_APL_slope,...
    uiefprairie_gcc_differential_APL_slope,...
    uiefswitchgrass_gcc_differential_APL_slope,...
    vaira_gcc_differential_APL_slope];

%% NDVI
NDVI_differential_APL_slope_allsites = [acadia_NDVI_differential_APL_slope,...
    bartlett_NDVI_differential_APL_slope,...
    butte_NDVI_differential_APL_slope,...
    canadaOBS_NDVI_differential_APL_slope,...
    caryinstitute_NDVI_differential_APL_slope,...
    dollysods_NDVI_differential_APL_slope,...
    harvard_NDVI_differential_APL_slope,...
    harvardbarn_NDVI_differential_APL_slope,...
    harvardblo_NDVI_differential_APL_slope,...
    harvardhemlock_NDVI_differential_APL_slope,...
    howland1_NDVI_differential_APL_slope,...
    lethbridge_NDVI_differential_APL_slope,...
    mammothcave_NDVI_differential_APL_slope,...
    monture_1000_NDVI_differential_APL_slope,...
    monture_2000_NDVI_differential_APL_slope,...
    morganmonroe_NDVI_differential_APL_slope,...
    nationalcapital_NDVI_differential_APL_slope,...
    oregon_NDVI_differential_APL_slope,...
    pointreyes_NDVI_differential_APL_slope,...
    proctor_NDVI_differential_APL_slope,...
    shiningrock_NDVI_differential_APL_slope,...
    smokylook_NDVI_differential_APL_slope,...
    smokypurchase_NDVI_differential_APL_slope,...
    teddy_NDVI_differential_APL_slope,...
    tonzi_NDVI_differential_APL_slope,...
    uiefmaize_NDVI_differential_APL_slope,...
    uiefmiscanthus_NDVI_differential_APL_slope,...
    uiefprairie_NDVI_differential_APL_slope,...
    uiefswitchgrass_NDVI_differential_APL_slope,...
    vaira_NDVI_differential_APL_slope];

save gcc_differential_APL_slope_allsites gcc_differential_APL_slope_allsites
save NDVI_differential_APL_slope_allsites NDVI_differential_APL_slope_allsites