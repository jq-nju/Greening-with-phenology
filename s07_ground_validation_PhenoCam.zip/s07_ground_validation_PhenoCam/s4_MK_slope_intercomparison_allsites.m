clear
clc

load('gcc_dgccgs_slope_allsites.mat')
load('gcc_differential_ALPHA_slope_allsites.mat')
load('gcc_differential_AMP_slope_allsites.mat')
load('gcc_differential_APL_slope_allsites.mat')
load('gcc_differential_BETA_slope_allsites.mat')
load('gcc_differential_SPL_slope_allsites.mat')

load('NDVI_dNDVIgs_slope_allsites.mat')
load('NDVI_differential_ALPHA_slope_allsites.mat')
load('NDVI_differential_AMP_slope_allsites.mat')
load('NDVI_differential_APL_slope_allsites.mat')
load('NDVI_differential_BETA_slope_allsites.mat')
load('NDVI_differential_SPL_slope_allsites.mat')

A = [gcc_dgccgs_slope_allsites;gcc_differential_ALPHA_slope_allsites;gcc_differential_BETA_slope_allsites;gcc_differential_AMP_slope_allsites;gcc_differential_SPL_slope_allsites;gcc_differential_APL_slope_allsites];
B = [NDVI_dNDVIgs_slope_allsites;NDVI_differential_ALPHA_slope_allsites;NDVI_differential_BETA_slope_allsites;NDVI_differential_AMP_slope_allsites;NDVI_differential_SPL_slope_allsites;NDVI_differential_APL_slope_allsites];

% A (:,28:end) = [];
% B (:,28:end) = [];
% A (:,[4,5,11,13,14,15,18,24,28,29,30]) = [];
% B (:,[4,5,11,13,14,15,18,24,28,29,30]) = [];
% 
% A = A';
% B = B';

% C = [dgccgs_allsites;gcc_differential_ALPHA_allsites;gcc_differential_BETA_allsites;gcc_differential_AMP_allsites;gcc_differential_SPL_allsites;gcc_differential_APL_allsites]';
% D = [dNDVIgs_allsites;NDVI_differential_ALPHA_allsites;NDVI_differential_BETA_allsites;NDVI_differential_AMP_allsites;NDVI_differential_SPL_allsites;NDVI_differential_APL_allsites]';

% C_mean = mean(C,1);
% D_mean = mean(D,1);
% 
% C_std = std(C,1);
% D_std = std(D,1);

%% violin plot
% subplot (1,3,2)
% violin(C);
% hold on
% plot ([0 7],[0 0])
% hold on
% h = boxplot(C,'symbol', '');
% set(h,'LineWidth',1.1);
% 
% subplot (1,3,3)
% violin(D);
% hold on
% plot ([0 7],[0 0])
% hold on
% h = boxplot(D,'symbol', '');
% set(h,'LineWidth',1.1);