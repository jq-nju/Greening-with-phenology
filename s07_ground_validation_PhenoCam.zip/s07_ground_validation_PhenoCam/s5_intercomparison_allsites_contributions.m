clear
clc

load('dgccgs_allsites.mat')
load('dNDVIgs_allsites.mat')
load('gcc_differential_ALPHA_allsites.mat')
load('gcc_differential_AMP_allsites.mat')
load('gcc_differential_APL_allsites.mat')
load('gcc_differential_BETA_allsites.mat')
load('gcc_differential_SPL_allsites.mat')
load('NDVI_differential_ALPHA_allsites.mat')
load('NDVI_differential_AMP_allsites.mat')
load('NDVI_differential_APL_allsites.mat')
load('NDVI_differential_BETA_allsites.mat')
load('NDVI_differential_SPL_allsites.mat')

%% gcc
gcc_total = gcc_differential_ALPHA_allsites + gcc_differential_AMP_allsites + gcc_differential_APL_allsites + gcc_differential_BETA_allsites + gcc_differential_SPL_allsites;

gcc_ALPHA_contribution = gcc_differential_ALPHA_allsites./gcc_total;
gcc_BETA_contribution = gcc_differential_BETA_allsites./gcc_total;
gcc_AMP_contribution = gcc_differential_AMP_allsites./gcc_total;
gcc_SPL_contribution = gcc_differential_SPL_allsites./gcc_total;
gcc_APL_contribution = gcc_differential_APL_allsites./gcc_total;

% ALPHA_outlier1 = mean (gcc_ALPHA_contribution (:)) + 2 * std (gcc_ALPHA_contribution (:));
% ALPHA_outlier2 = mean (gcc_ALPHA_contribution (:)) - 2 * std (gcc_ALPHA_contribution (:));
% gcc_ALPHA_contribution (gcc_ALPHA_contribution >= ALPHA_outlier1) = nan;
% gcc_ALPHA_contribution (gcc_ALPHA_contribution <= ALPHA_outlier2) = nan;
% 
% BETA_outlier1 = mean (gcc_BETA_contribution (:)) + 2 * std (gcc_BETA_contribution (:));
% BETA_outlier2 = mean (gcc_BETA_contribution (:)) - 2 * std (gcc_BETA_contribution (:));
% gcc_BETA_contribution (gcc_BETA_contribution >= BETA_outlier1) = nan;
% gcc_BETA_contribution (gcc_BETA_contribution <= BETA_outlier2) = nan;
% 
% AMP_outlier1 = mean (gcc_AMP_contribution (:)) + 2 * std (gcc_AMP_contribution (:));
% AMP_outlier2 = mean (gcc_AMP_contribution (:)) - 2 * std (gcc_AMP_contribution (:));
% gcc_AMP_contribution (gcc_AMP_contribution >= AMP_outlier1) = nan;
% gcc_AMP_contribution (gcc_AMP_contribution <= AMP_outlier2) = nan;
% 
% SPL_outlier1 = mean (gcc_SPL_contribution (:)) + 2 * std (gcc_SPL_contribution (:));
% SPL_outlier2 = mean (gcc_SPL_contribution (:)) - 2 * std (gcc_SPL_contribution (:));
% gcc_SPL_contribution (gcc_SPL_contribution >= SPL_outlier1) = nan;
% gcc_SPL_contribution (gcc_SPL_contribution <= SPL_outlier2) = nan;
% 
% APL_outlier1 = mean (gcc_APL_contribution (:)) + 2 * std (gcc_APL_contribution (:));
% APL_outlier2 = mean (gcc_APL_contribution (:)) - 2 * std (gcc_APL_contribution (:));
% gcc_APL_contribution (gcc_APL_contribution >= APL_outlier1) = nan;
% gcc_APL_contribution (gcc_APL_contribution <= APL_outlier2) = nan;

gcc_contribution = [gcc_ALPHA_contribution;gcc_BETA_contribution;gcc_AMP_contribution;gcc_SPL_contribution;gcc_APL_contribution]';

Q1 = quantile(gcc_contribution(:), 0.25); 
Q3 = quantile(gcc_contribution(:), 0.75);  
IQR = Q3 - Q1;              

lower_bound = Q1 - 3 * IQR;
upper_bound = Q3 + 3 * IQR;

gcc_contribution (gcc_contribution >= upper_bound) = nan;
gcc_contribution (gcc_contribution <= lower_bound) = nan;

gcc_contribution_median = nanmedian (gcc_contribution,1);
gcc_contribution_mean = nanmean (gcc_contribution,1);
gcc_contribution_std = nanstd (gcc_contribution,1);

%% NDVI
NDVI_total = NDVI_differential_ALPHA_allsites + NDVI_differential_AMP_allsites + NDVI_differential_APL_allsites + NDVI_differential_BETA_allsites + NDVI_differential_SPL_allsites;

NDVI_ALPHA_contribution = NDVI_differential_ALPHA_allsites./NDVI_total;
NDVI_BETA_contribution = NDVI_differential_BETA_allsites./NDVI_total;
NDVI_AMP_contribution = NDVI_differential_AMP_allsites./NDVI_total;
NDVI_SPL_contribution = NDVI_differential_SPL_allsites./NDVI_total;
NDVI_APL_contribution = NDVI_differential_APL_allsites./NDVI_total;

% ALPHA_outlier1 = mean (NDVI_ALPHA_contribution (:)) + 2 * std (NDVI_ALPHA_contribution (:));
% ALPHA_outlier2 = mean (NDVI_ALPHA_contribution (:)) - 2 * std (NDVI_ALPHA_contribution (:));
% NDVI_ALPHA_contribution (NDVI_ALPHA_contribution >= ALPHA_outlier1) = nan;
% NDVI_ALPHA_contribution (NDVI_ALPHA_contribution <= ALPHA_outlier2) = nan;
% 
% BETA_outlier1 = mean (NDVI_BETA_contribution (:)) + 2 * std (NDVI_BETA_contribution (:));
% BETA_outlier2 = mean (NDVI_BETA_contribution (:)) - 2 * std (NDVI_BETA_contribution (:));
% NDVI_BETA_contribution (NDVI_BETA_contribution >= BETA_outlier1) = nan;
% NDVI_BETA_contribution (NDVI_BETA_contribution <= BETA_outlier2) = nan;
% 
% AMP_outlier1 = mean (NDVI_AMP_contribution (:)) + 2 * std (NDVI_AMP_contribution (:));
% AMP_outlier2 = mean (NDVI_AMP_contribution (:)) - 2 * std (NDVI_AMP_contribution (:));
% NDVI_AMP_contribution (NDVI_AMP_contribution >= AMP_outlier1) = nan;
% NDVI_AMP_contribution (NDVI_AMP_contribution <= AMP_outlier2) = nan;
% 
% SPL_outlier1 = mean (NDVI_SPL_contribution (:)) + 2 * std (NDVI_SPL_contribution (:));
% SPL_outlier2 = mean (NDVI_SPL_contribution (:)) - 2 * std (NDVI_SPL_contribution (:));
% NDVI_SPL_contribution (NDVI_SPL_contribution >= SPL_outlier1) = nan;
% NDVI_SPL_contribution (NDVI_SPL_contribution <= SPL_outlier2) = nan;
% 
% APL_outlier1 = mean (NDVI_APL_contribution (:)) + 2 * std (NDVI_APL_contribution (:));
% APL_outlier2 = mean (NDVI_APL_contribution (:)) - 2 * std (NDVI_APL_contribution (:));
% NDVI_APL_contribution (NDVI_APL_contribution >= APL_outlier1) = nan;
% NDVI_APL_contribution (NDVI_APL_contribution <= APL_outlier2) = nan;

NDVI_contribution = [NDVI_ALPHA_contribution;NDVI_BETA_contribution;NDVI_AMP_contribution;NDVI_SPL_contribution;NDVI_APL_contribution]';

Q1 = quantile(NDVI_contribution(:), 0.25); 
Q3 = quantile(NDVI_contribution(:), 0.75);  
IQR = Q3 - Q1;              

lower_bound = Q1 - 3 * IQR;
upper_bound = Q3 + 3 * IQR;

NDVI_contribution (NDVI_contribution >= upper_bound) = nan;
NDVI_contribution (NDVI_contribution <= lower_bound) = nan;

NDVI_contribution_median = nanmedian (NDVI_contribution,1);
NDVI_contribution_mean = nanmean (NDVI_contribution,1);
NDVI_contribution_std = nanstd (NDVI_contribution,1);

%% figures
subplot (1,2,1)
bar(gcc_contribution_median)
hold on
errorbar(gcc_contribution_median,gcc_contribution_std)
hold on
plot(gcc_contribution_mean,'o')

subplot (1,2,2)
bar(NDVI_contribution_median)
hold on
errorbar(NDVI_contribution_median,NDVI_contribution_std)
hold on
plot(NDVI_contribution_mean,'o')