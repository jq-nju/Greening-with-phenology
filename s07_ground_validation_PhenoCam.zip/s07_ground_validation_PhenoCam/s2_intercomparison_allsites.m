clear
clc

load('dgccgs_allsites.mat')
load('dNDVIgs_allsites.mat')
load('gcc_differential_ALPHA_allsites.mat')
load('gcc_differential_AMP_allsites.mat')
load('gcc_differential_APL_allsites.mat')
load('gcc_differential_BETA_allsites.mat')
load('gcc_differential_SPL_allsites.mat')
load('NDVI_differential_ALPHA_allsites.mat')
load('NDVI_differential_AMP_allsites.mat')
load('NDVI_differential_APL_allsites.mat')
load('NDVI_differential_BETA_allsites.mat')
load('NDVI_differential_SPL_allsites.mat')

C = [dgccgs_allsites;gcc_differential_ALPHA_allsites;gcc_differential_BETA_allsites;gcc_differential_AMP_allsites;gcc_differential_SPL_allsites;gcc_differential_APL_allsites]';
D = [dNDVIgs_allsites;NDVI_differential_ALPHA_allsites;NDVI_differential_BETA_allsites;NDVI_differential_AMP_allsites;NDVI_differential_SPL_allsites;NDVI_differential_APL_allsites]';

% C_mean = mean(C,1);
% D_mean = mean(D,1);
% 
% C_std = std(C,1);
% D_std = std(D,1);

%% violin plot
subplot (1,3,2)
violin(C);
hold on
plot ([0 7],[0 0])
hold on
h = boxplot(C,'symbol', '');
set(h,'LineWidth',1.1);

subplot (1,3,3)
violin(D);
hold on
plot ([0 7],[0 0])
hold on
h = boxplot(D,'symbol', '');
set(h,'LineWidth',1.1);