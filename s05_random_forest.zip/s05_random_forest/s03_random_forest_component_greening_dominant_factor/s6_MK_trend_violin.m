clear
clc

load('slope_MK_2000_2020.mat')

%% violin plot
obs = reshape (observed_APL_slope, [1,347*720]);
co2 = reshape (predicted_APL_co2_slope, [1,347*720]);
cc  = reshape (predicted_APL_cc_slope, [1,347*720]);
lcc = reshape (predicted_APL_lcc_slope, [1,347*720]);
% others = reshape (predicted_APL_others_slope, [1,347*720]);

data = [obs;co2;cc;lcc];
data = data';
violin(data);
hold on
plot ([0 5],[0 0])
hold on
h = boxplot(data,'symbol', '');
set(h,'LineWidth',1.1);