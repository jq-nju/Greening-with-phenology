clear
clc

load('slope_MK_2000_2020.mat')
load('mask_greening_pixels.mat')

load('NDVIgs_slope_2000_2020.mat')
load('NDVIgs_sig_2000_2020.mat')

% NDVIgs_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;

% h = imagesc (NDVI_slope);
% set(h,'alphadata',~isnan(NDVI_slope))
% set(gca, 'color', 'k');
% set(gca,'xtick',[],'xticklabel',[])
% set(gca,'ytick',[],'yticklabel',[])

% ALPHA_slope (ALPHA_sig > 0.05) = nan;
% BETA_slope (BETA_sig > 0.05) = nan;
% AMP_slope (AMP_sig > 0.05) = nan;
% SPL_slope (SPL_sig > 0.05) = nan;
% APL_slope (APL_sig > 0.05) = nan;

%% dominant factors: ALPHA, BETA, max, SPL or APL
for i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        NDVI = NDVIgs_slope_2000_2020 (i,j);
        
        ALPHA = observed_ALPHA_slope (i,j);
        BETA  = observed_BETA_slope (i,j);
        AMP   = observed_AMP_slope (i,j);
        SPL   = observed_SPL_slope (i,j);
        APL   = observed_APL_slope (i,j);
        
        var = [ALPHA,BETA,AMP,SPL,APL];
        
        if mask == 1 && NDVI > 0
            var_max = find (var == max (var));
            greening_dominant_component (i,j) = var_max (1);
            %         elseif mask == 1 && NDVI < 0
            %             greening_dominant_component (i,j) = -find (var == min (var));
        else
            greening_dominant_component (i,j) = nan;
        end
    end
end

save greening_dominant_component greening_dominant_component
% greening_dominant_component (greening_dominant_component == -1) = 6;
% greening_dominant_component (greening_dominant_component == -2) = 7;
% greening_dominant_component (greening_dominant_component == -3) = 8;
% greening_dominant_component (greening_dominant_component == -4) = 9;
% greening_dominant_component (greening_dominant_component == -5) = 10;

% % plot spatial patterns
% subplot (2,2,1)
% h = imagesc (var_decomposition);
% set(h,'alphadata',~isnan(var_decomposition))
% set(gca, 'color', 'k');
% set(gca,'xtick',[],'xticklabel',[])
% set(gca,'ytick',[],'yticklabel',[])
%
% subplot (2,2,2)
% h = imagesc (min_s1_decomposition);
% set(h,'alphadata',~isnan(min_s1_decomposition))
% set(gca, 'color', 'k');
% set(gca,'xtick',[],'xticklabel',[])
% set(gca,'ytick',[],'yticklabel',[])
%
% subplot (2,2,3)
% var_decomposition = reshape (var_decomposition,[1,347*720]);
% var_decomposition (isnan (var_decomposition)) = [];
%
% a = length (var_decomposition(var_decomposition == 1));
% b = length (var_decomposition(var_decomposition == 2));
% c = length (var_decomposition(var_decomposition == 3));
% d = length (var_decomposition(var_decomposition == 4));
% e = length (var_decomposition(var_decomposition == 5));
%
% proportion = [a,b,c,d,e];
% pie (proportion)
%
% subplot (2,2,4)
% min_s1_decomposition = reshape (min_s1_decomposition,[1,347*720]);
% min_s1_decomposition (isnan (min_s1_decomposition)) = [];
%
% a = length (min_s1_decomposition(min_s1_decomposition == 1));
% b = length (min_s1_decomposition(min_s1_decomposition == 2));
% c = length (min_s1_decomposition(min_s1_decomposition == 3));
% d = length (min_s1_decomposition(min_s1_decomposition == 4));
% e = length (min_s1_decomposition(min_s1_decomposition == 5));
%
% proportion = [a,b,c,d,e];
% pie (proportion)

%% dominant factors: co2, cc, lcc or others
for i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        if mask == 1
            
            ALPHA_co2 = predicted_ALPHA_co2_slope (i,j);
            BETA_co2  = predicted_BETA_co2_slope (i,j);
            AMP_co2   = predicted_AMP_co2_slope (i,j);
            SPL_co2   = predicted_SPL_co2_slope (i,j);
            APL_co2   = predicted_APL_co2_slope (i,j);
            
            ALPHA_cc = predicted_ALPHA_cc_slope (i,j);
            BETA_cc  = predicted_BETA_cc_slope (i,j);
            AMP_cc   = predicted_AMP_cc_slope (i,j);
            SPL_cc   = predicted_SPL_cc_slope (i,j);
            APL_cc   = predicted_APL_cc_slope (i,j);
            
            ALPHA_lcc = predicted_ALPHA_lcc_slope (i,j);
            BETA_lcc  = predicted_BETA_lcc_slope (i,j);
            AMP_lcc   = predicted_AMP_lcc_slope (i,j);
            SPL_lcc   = predicted_SPL_lcc_slope (i,j);
            APL_lcc   = predicted_APL_lcc_slope (i,j);
            
            s_co2 = [ALPHA_co2,BETA_co2,AMP_co2,SPL_co2,APL_co2];
            s_cc  = [ALPHA_cc,BETA_cc,AMP_cc,SPL_cc,APL_cc];
            s_lcc = [ALPHA_lcc,BETA_lcc,AMP_lcc,SPL_lcc,APL_lcc];
            
            var = greening_dominant_component (i,j);
            
            if ~isnan (var)
                
                greening_co2 = s_co2 (var);
                greening_cc  = s_cc (var);
                greening_lcc = s_lcc (var);
                
                greening = [greening_co2,greening_cc,greening_lcc];
                greening_max = find (greening == max (greening));
                
                if greening_max == 1 % co2
                    co2_cc_lcc_dominant_factor (i,j) = 1;
                elseif greening_max == 2 % cc
                    co2_cc_lcc_dominant_factor (i,j) = 2;
                elseif greening_max == 3 % lcc
                    co2_cc_lcc_dominant_factor (i,j) = 3;
                else
                    co2_cc_lcc_dominant_factor (i,j) = nan;
                end
                
                %             elseif var >= 6 && var <= 10 % browning pixel
                %
                %                 browning_co2 = s_co2 (var - 5);
                %                 browning_cc  = s_cc (var - 5);
                %                 browning_lcc = s_lcc (var - 5);
                %
                %                 browning = [browning_co2,browning_cc,browning_lcc];
                %                 browning_min = find (browning == min (browning));
                %
                %                 if browning_min == 1 % co2
                %                     co2_cc_lcc_dominant_factor (i,j) = 4;
                %                 elseif browning_min == 2 % cc
                %                     co2_cc_lcc_dominant_factor (i,j) = 5;
                %                 elseif browning_min == 3 % lcc
                %                     co2_cc_lcc_dominant_factor (i,j) = 6;
                %                 else
                %                     co2_cc_lcc_dominant_factor (i,j) = nan;
                %                 end
                
            else
                co2_cc_lcc_dominant_factor (i,j) = nan;
            end
        else
            co2_cc_lcc_dominant_factor (i,j) = nan;
        end
    end
end

save co2_cc_lcc_dominant_factor co2_cc_lcc_dominant_factor

% convert .mat into tiff files
filepath = 'D:\decompose LAI\decompose LAI_new_test\s10_Random_Forest\version_for greening_only\s03_random_forest_component_greening_dominant_factor\geoinfo.tif';
[Data, R] = geotiffread(filepath);
info=geotiffinfo(filepath);
geotiffwrite('co2_cc_lcc_dominant_factor',co2_cc_lcc_dominant_factor,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% plot spatial patterns
h = imagesc (co2_cc_lcc_dominant_factor);
set(h,'alphadata',~isnan(co2_cc_lcc_dominant_factor))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

% ����ͼ��
% imagesc(data);
colorbar;

% �Զ�����ɫӳ��
% ������ɫ����ÿһ�д���һ����ɫ
cmap = [
    0 0 1;    % ��ɫ - ��Ӧ 1
    0 1 0;    % ��ɫ - ��Ӧ 2
    0 0.5 0;  % ����ɫ - ��Ӧ -2
    ];

% ����ͼ����ʾ�ķ�Χ��������
caxis([1 3]);

% ���� colormap
colormap(cmap);

%
% subplot (2,2,3)
% co2_cc_lcc_dominant_factor = reshape (co2_cc_lcc_dominant_factor,[1,347*720]);
% co2_cc_lcc_dominant_factor (isnan (co2_cc_lcc_dominant_factor)) = [];
%
% a = length (co2_cc_lcc_dominant_factor(co2_cc_lcc_dominant_factor == 2));
% b = length (co2_cc_lcc_dominant_factor(co2_cc_lcc_dominant_factor == 3));
% c = length (co2_cc_lcc_dominant_factor(co2_cc_lcc_dominant_factor == 4));
%
% proportion = [a,b,c];
% pie (proportion)
%
% subplot (2,2,4)
% min_s2s3s4s5_decomposition = reshape (min_s2s3s4s5_decomposition,[1,347*720]);
% min_s2s3s4s5_decomposition (isnan (min_s2s3s4s5_decomposition)) = [];
%
% a = length (min_s2s3s4s5_decomposition(min_s2s3s4s5_decomposition == 2));
% b = length (min_s2s3s4s5_decomposition(min_s2s3s4s5_decomposition == 3));
% c = length (min_s2s3s4s5_decomposition(min_s2s3s4s5_decomposition == 4));
%
% proportion = [a,b,c];
% pie (proportion)