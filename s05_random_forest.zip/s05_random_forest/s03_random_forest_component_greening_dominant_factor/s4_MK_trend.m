
clear
clc

load('differential_component_ALPHA.mat')
load('differential_component_BETA.mat')
load('differential_component_AMP.mat')
load('differential_component_SPL.mat')
load('differential_component_APL.mat')

load('component_ALPHA_cc.mat')
load('component_ALPHA_co2.mat')
load('component_ALPHA_lcc.mat')
% load('component_ALPHA_others.mat')

load('component_BETA_cc.mat')
load('component_BETA_co2.mat')
load('component_BETA_lcc.mat')
% load('component_BETA_others.mat')

load('component_AMP_cc.mat')
load('component_AMP_co2.mat')
load('component_AMP_lcc.mat')
% load('component_AMP_others.mat')

load('component_SPL_cc.mat')
load('component_SPL_co2.mat')
load('component_SPL_lcc.mat')
% load('component_SPL_others.mat')

load('component_APL_cc.mat')
load('component_APL_co2.mat')
load('component_APL_lcc.mat')
% load('component_APL_others.mat')

load('mask_greening_pixels.mat')

years = 1:19;

% i = 120; j = 582;
parfor i = 1:347
    for j = 1:720

        mask = mask_greening_pixels (i,j);

        observed_ALPHA = differential_component_ALPHA (i,j,:);
        observed_BETA  = differential_component_BETA (i,j,:);
        observed_AMP   = differential_component_AMP (i,j,:);
        observed_SPL   = differential_component_SPL (i,j,:);
        observed_APL   = differential_component_APL (i,j,:);

        observed_ALPHA  = observed_ALPHA (1,:);
        observed_BETA   = observed_BETA (1,:);
        observed_AMP    = observed_AMP (1,:);
        observed_SPL    = observed_SPL (1,:);
        observed_APL    = observed_APL (1,:);

        valid_length = length (observed_ALPHA (~isnan (observed_ALPHA)));

        if mask == 1 && valid_length == 19

            predicted_ALPHA_cc = component_ALPHA_cc (i,j,:);
            predicted_BETA_cc  = component_BETA_cc (i,j,:);
            predicted_AMP_cc  = component_AMP_cc (i,j,:);
            predicted_SPL_cc  = component_SPL_cc (i,j,:);
            predicted_APL_cc   = component_APL_cc (i,j,:);

            predicted_ALPHA_co2 = component_ALPHA_co2 (i,j,:);
            predicted_BETA_co2  = component_BETA_co2 (i,j,:);
            predicted_AMP_co2  = component_AMP_co2 (i,j,:);
            predicted_SPL_co2  = component_SPL_co2 (i,j,:);
            predicted_APL_co2   = component_APL_co2 (i,j,:);

            predicted_ALPHA_lcc = component_ALPHA_lcc (i,j,:);
            predicted_BETA_lcc  = component_BETA_lcc (i,j,:);
            predicted_AMP_lcc  = component_AMP_lcc (i,j,:);
            predicted_SPL_lcc  = component_SPL_lcc (i,j,:);
            predicted_APL_lcc   = component_APL_lcc (i,j,:);

            %             predicted_ALPHA_others = component_ALPHA_others (i,j,:);
            %             predicted_BETA_others  = component_BETA_others (i,j,:);
            %             predicted_AMP_others  = component_AMP_others (i,j,:);
            %             predicted_SPL_others  = component_SPL_others (i,j,:);
            %             predicted_APL_others   = component_APL_others (i,j,:);

            predicted_ALPHA_cc  = predicted_ALPHA_cc (1,:);
            predicted_BETA_cc   = predicted_BETA_cc (1,:);
            predicted_AMP_cc    = predicted_AMP_cc (1,:);
            predicted_SPL_cc    = predicted_SPL_cc (1,:);
            predicted_APL_cc    = predicted_APL_cc (1,:);

            predicted_ALPHA_co2  = predicted_ALPHA_co2 (1,:);
            predicted_BETA_co2   = predicted_BETA_co2 (1,:);
            predicted_AMP_co2    = predicted_AMP_co2 (1,:);
            predicted_SPL_co2    = predicted_SPL_co2 (1,:);
            predicted_APL_co2    = predicted_APL_co2 (1,:);

            predicted_ALPHA_lcc  = predicted_ALPHA_lcc (1,:);
            predicted_BETA_lcc   = predicted_BETA_lcc (1,:);
            predicted_AMP_lcc    = predicted_AMP_lcc (1,:);
            predicted_SPL_lcc    = predicted_SPL_lcc (1,:);
            predicted_APL_lcc    = predicted_APL_lcc (1,:);

            %             predicted_ALPHA_others  = predicted_ALPHA_others (1,:);
            %             predicted_BETA_others   = predicted_BETA_others (1,:);
            %             predicted_AMP_others    = predicted_AMP_others (1,:);
            %             predicted_SPL_others    = predicted_SPL_others (1,:);
            %             predicted_APL_others    = predicted_APL_others (1,:);

            % MK & Tau-b with Sen's method
            significance_alpha = 0.05; % significance level: 95%
            wantplot = 0;    % do not plot

            % observed_ALPHA
            datain = [years;observed_ALPHA];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            observed_ALPHA_slope  (i,j) = sen;
            observed_ALPHA_sig  (i,j) = sig;

            % observed_BETA
            datain = [years;observed_BETA];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            observed_BETA_slope  (i,j) = sen;
            observed_BETA_sig  (i,j) = sig;

            % observed_AMP
            datain = [years;observed_AMP];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            observed_AMP_slope  (i,j) = sen;
            observed_AMP_sig  (i,j) = sig;

            % observed_SPL
            datain = [years;observed_SPL];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            observed_SPL_slope  (i,j) = sen;
            observed_SPL_sig  (i,j) = sig;

            % observed_APL
            datain = [years;observed_APL];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            observed_APL_slope  (i,j) = sen;
            observed_APL_sig  (i,j) = sig;

            % predicted_ALPHA_cc
            datain = [years;predicted_ALPHA_cc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_ALPHA_cc_slope  (i,j) = sen;
            predicted_ALPHA_cc_sig  (i,j) = sig;

            % predicted_BETA_cc
            datain = [years;predicted_BETA_cc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_BETA_cc_slope  (i,j) = sen;
            predicted_BETA_cc_sig  (i,j) = sig;

            % predicted_AMP_cc
            datain = [years;predicted_AMP_cc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_AMP_cc_slope  (i,j) = sen;
            predicted_AMP_cc_sig  (i,j) = sig;

            % predicted_SPL_cc
            datain = [years;predicted_SPL_cc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_SPL_cc_slope  (i,j) = sen;
            predicted_SPL_cc_sig  (i,j) = sig;

            % predicted_APL_cc
            datain = [years;predicted_APL_cc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_APL_cc_slope  (i,j) = sen;
            predicted_APL_cc_sig  (i,j) = sig;

            % predicted_ALPHA_co2
            datain = [years;predicted_ALPHA_co2];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_ALPHA_co2_slope  (i,j) = sen;
            predicted_ALPHA_co2_sig  (i,j) = sig;

            % predicted_BETA_co2
            datain = [years;predicted_BETA_co2];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_BETA_co2_slope  (i,j) = sen;
            predicted_BETA_co2_sig  (i,j) = sig;

            % predicted_AMP_co2
            datain = [years;predicted_AMP_co2];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_AMP_co2_slope  (i,j) = sen;
            predicted_AMP_co2_sig  (i,j) = sig;

            % predicted_SPL_co2
            datain = [years;predicted_SPL_co2];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_SPL_co2_slope  (i,j) = sen;
            predicted_SPL_co2_sig  (i,j) = sig;

            % predicted_APL_co2
            datain = [years;predicted_APL_co2];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_APL_co2_slope  (i,j) = sen;
            predicted_APL_co2_sig  (i,j) = sig;

            % predicted_ALPHA_lcc
            datain = [years;predicted_ALPHA_lcc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_ALPHA_lcc_slope  (i,j) = sen;
            predicted_ALPHA_lcc_sig  (i,j) = sig;

            % predicted_BETA_lcc
            datain = [years;predicted_BETA_lcc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_BETA_lcc_slope  (i,j) = sen;
            predicted_BETA_lcc_sig  (i,j) = sig;

            % predicted_AMP_lcc
            datain = [years;predicted_AMP_lcc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_AMP_lcc_slope  (i,j) = sen;
            predicted_AMP_lcc_sig  (i,j) = sig;

            % predicted_SPL_lcc
            datain = [years;predicted_SPL_lcc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_SPL_lcc_slope  (i,j) = sen;
            predicted_SPL_lcc_sig  (i,j) = sig;

            % predicted_APL_lcc
            datain = [years;predicted_APL_lcc];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            predicted_APL_lcc_slope  (i,j) = sen;
            predicted_APL_lcc_sig  (i,j) = sig;

            %             % predicted_ALPHA_others
            %             datain = [years;predicted_ALPHA_others];
            %             datain = datain';
            %             [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            %             predicted_ALPHA_others_slope  (i,j) = sen;
            %             predicted_ALPHA_others_sig  (i,j) = sig;
            %
            %             % predicted_BETA_others
            %             datain = [years;predicted_BETA_others];
            %             datain = datain';
            %             [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            %             predicted_BETA_others_slope  (i,j) = sen;
            %             predicted_BETA_others_sig  (i,j) = sig;
            %
            %             % predicted_AMP_others
            %             datain = [years;predicted_AMP_others];
            %             datain = datain';
            %             [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            %             predicted_AMP_others_slope  (i,j) = sen;
            %             predicted_AMP_others_sig  (i,j) = sig;
            %
            %             % predicted_SPL_others
            %             datain = [years;predicted_SPL_others];
            %             datain = datain';
            %             [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            %             predicted_SPL_others_slope  (i,j) = sen;
            %             predicted_SPL_others_sig  (i,j) = sig;
            %
            %             % predicted_APL_others
            %             datain = [years;predicted_APL_others];
            %             datain = datain';
            %             [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            %             predicted_APL_others_slope  (i,j) = sen;
            %             predicted_APL_others_sig  (i,j) = sig;

        else

            observed_ALPHA_slope  (i,j) = nan;
            observed_ALPHA_sig  (i,j) = nan;
            observed_BETA_slope  (i,j) = nan;
            observed_BETA_sig  (i,j) = nan;
            observed_AMP_slope  (i,j) = nan;
            observed_AMP_sig  (i,j) = nan;
            observed_SPL_slope  (i,j) = nan;
            observed_SPL_sig  (i,j) = nan;
            observed_APL_slope  (i,j) = nan;
            observed_APL_sig  (i,j) = nan;

            predicted_ALPHA_cc_slope  (i,j) = nan;
            predicted_ALPHA_cc_sig  (i,j) = nan;
            predicted_BETA_cc_slope  (i,j) = nan;
            predicted_BETA_cc_sig  (i,j) = nan;
            predicted_AMP_cc_slope  (i,j) = nan;
            predicted_AMP_cc_sig  (i,j) = nan;
            predicted_SPL_cc_slope  (i,j) = nan;
            predicted_SPL_cc_sig  (i,j) = nan;
            predicted_APL_cc_slope  (i,j) = nan;
            predicted_APL_cc_sig  (i,j) = nan;

            predicted_ALPHA_co2_slope  (i,j) = nan;
            predicted_ALPHA_co2_sig  (i,j) = nan;
            predicted_BETA_co2_slope  (i,j) = nan;
            predicted_BETA_co2_sig  (i,j) = nan;
            predicted_AMP_co2_slope  (i,j) = nan;
            predicted_AMP_co2_sig  (i,j) = nan;
            predicted_SPL_co2_slope  (i,j) = nan;
            predicted_SPL_co2_sig  (i,j) = nan;
            predicted_APL_co2_slope  (i,j) = nan;
            predicted_APL_co2_sig  (i,j) = nan;

            predicted_ALPHA_lcc_slope  (i,j) = nan;
            predicted_ALPHA_lcc_sig  (i,j) = nan;
            predicted_BETA_lcc_slope  (i,j) = nan;
            predicted_BETA_lcc_sig  (i,j) = nan;
            predicted_AMP_lcc_slope  (i,j) = nan;
            predicted_AMP_lcc_sig  (i,j) = nan;
            predicted_SPL_lcc_slope  (i,j) = nan;
            predicted_SPL_lcc_sig  (i,j) = nan;
            predicted_APL_lcc_slope  (i,j) = nan;
            predicted_APL_lcc_sig  (i,j) = nan;

            %             predicted_ALPHA_others_slope  (i,j) = nan;
            %             predicted_ALPHA_others_sig  (i,j) = nan;
            %             predicted_BETA_others_slope  (i,j) = nan;
            %             predicted_BETA_others_sig  (i,j) = nan;
            %             predicted_AMP_others_slope  (i,j) = nan;
            %             predicted_AMP_others_sig  (i,j) = nan;
            %             predicted_SPL_others_slope  (i,j) = nan;
            %             predicted_SPL_others_sig  (i,j) = nan;
            %             predicted_APL_others_slope  (i,j) = nan;
            %             predicted_APL_others_sig  (i,j) = nan;

        end
    end
end