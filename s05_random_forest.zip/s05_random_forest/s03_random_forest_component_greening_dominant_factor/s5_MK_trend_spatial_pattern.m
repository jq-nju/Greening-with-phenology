clear
clc

load('slope_MK_2000_2020.mat')

subplot (5,5,1)
h = imagesc (observed_ALPHA_slope);
set(h,'alphadata',~isnan(observed_ALPHA_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,2)
h = imagesc (predicted_ALPHA_co2_slope);
set(h,'alphadata',~isnan(predicted_ALPHA_co2_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,3)
h = imagesc (predicted_ALPHA_cc_slope);
set(h,'alphadata',~isnan(predicted_ALPHA_cc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,4)
h = imagesc (predicted_ALPHA_lcc_slope);
set(h,'alphadata',~isnan(predicted_ALPHA_lcc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,5)
h = imagesc (predicted_ALPHA_others_slope);
set(h,'alphadata',~isnan(predicted_ALPHA_others_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,6)
h = imagesc (observed_BETA_slope);
set(h,'alphadata',~isnan(observed_BETA_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,7)
h = imagesc (predicted_BETA_co2_slope);
set(h,'alphadata',~isnan(predicted_BETA_co2_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,8)
h = imagesc (predicted_BETA_cc_slope);
set(h,'alphadata',~isnan(predicted_BETA_cc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,9)
h = imagesc (predicted_BETA_lcc_slope);
set(h,'alphadata',~isnan(predicted_BETA_lcc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,10)
h = imagesc (predicted_BETA_others_slope);
set(h,'alphadata',~isnan(predicted_BETA_others_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,11)
h = imagesc (observed_AMP_slope);
set(h,'alphadata',~isnan(observed_AMP_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,12)
h = imagesc (predicted_AMP_co2_slope);
set(h,'alphadata',~isnan(predicted_AMP_co2_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,13)
h = imagesc (predicted_AMP_cc_slope);
set(h,'alphadata',~isnan(predicted_AMP_cc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,14)
h = imagesc (predicted_AMP_lcc_slope);
set(h,'alphadata',~isnan(predicted_AMP_lcc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,15)
h = imagesc (predicted_AMP_others_slope);
set(h,'alphadata',~isnan(predicted_AMP_others_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,16)
h = imagesc (observed_SPL_slope);
set(h,'alphadata',~isnan(observed_SPL_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,17)
h = imagesc (predicted_SPL_co2_slope);
set(h,'alphadata',~isnan(predicted_SPL_co2_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,18)
h = imagesc (predicted_SPL_cc_slope);
set(h,'alphadata',~isnan(predicted_SPL_cc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,19)
h = imagesc (predicted_SPL_lcc_slope);
set(h,'alphadata',~isnan(predicted_SPL_lcc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,20)
h = imagesc (predicted_SPL_others_slope);
set(h,'alphadata',~isnan(predicted_SPL_others_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,21)
h = imagesc (observed_APL_slope);
set(h,'alphadata',~isnan(observed_APL_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,22)
h = imagesc (predicted_APL_co2_slope);
set(h,'alphadata',~isnan(predicted_APL_co2_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,23)
h = imagesc (predicted_APL_cc_slope);
set(h,'alphadata',~isnan(predicted_APL_cc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,24)
h = imagesc (predicted_APL_lcc_slope);
set(h,'alphadata',~isnan(predicted_APL_lcc_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (5,5,25)
h = imagesc (predicted_APL_others_slope);
set(h,'alphadata',~isnan(predicted_APL_others_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])