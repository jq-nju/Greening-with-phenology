clear
clc

%% greening
load('NDVIgs_slope_2000_2020.mat')
load('greening_dominant_component.mat')
load('co2_cc_lcc_dominant_factor.mat')

load('mask_greening_pixels.mat')

% greening_dominant_component (greening_dominant_component == 6)  = 1;
% greening_dominant_component (greening_dominant_component == 7)  = 2;
% greening_dominant_component (greening_dominant_component == 8)  = 3;
% greening_dominant_component (greening_dominant_component == 9)  = 4;
% greening_dominant_component (greening_dominant_component == 10) = 5;

% NDVIgs_slope_2000_2020 (NDVIgs_slope_2000_2020 <= 0) = nan;

% load('NDVIgs_sig.mat')
% NDVIgs_slope_2000_2020 (NDVIgs_sig > 0.1) = nan;

NDVIgs_slope_2000_2020 (isnan (mask_greening_pixels)) = nan;
NDVIgs_slope_2000_2020 (isnan (greening_dominant_component)) = nan;
NDVIgs_slope_2000_2020 (isnan (co2_cc_lcc_dominant_factor)) = nan;

greening_dominant_component (isnan (NDVIgs_slope_2000_2020)) = nan;
co2_cc_lcc_dominant_factor (isnan (NDVIgs_slope_2000_2020)) = nan;

NDVIgs_slope_2000_2020 = reshape (NDVIgs_slope_2000_2020,[1,347*720]);
greening_dominant_component = reshape (greening_dominant_component,[1,347*720]);
co2_cc_lcc_dominant_factor = reshape (co2_cc_lcc_dominant_factor,[1,347*720]);

NDVIgs_slope_2000_2020 (isnan (NDVIgs_slope_2000_2020)) = [];
greening_dominant_component (isnan (greening_dominant_component)) = [];
co2_cc_lcc_dominant_factor (isnan (co2_cc_lcc_dominant_factor)) = [];

NDVIgs_slope_2000_2020 = NDVIgs_slope_2000_2020';
greening_dominant_component = greening_dominant_component';
co2_cc_lcc_dominant_factor = co2_cc_lcc_dominant_factor';

links (:,1) = co2_cc_lcc_dominant_factor;
links (:,2) = greening_dominant_component;

%% CO2 (+) & APLHA
logical_index = (links(:, 1) == 1) & (links(:, 2) == 1);
count (1) = sum(logical_index);

%% CO2 (+) & BETA
logical_index = (links(:, 1) == 1) & (links(:, 2) == 2);
count (2) = sum(logical_index);

%% CO2 (+) & MAX
logical_index = (links(:, 1) == 1) & (links(:, 2) == 3);
count (3) = sum(logical_index);

%% CO2 (+) & SPL
logical_index = (links(:, 1) == 1) & (links(:, 2) == 4);
count (4) = sum(logical_index);

%% CO2 (+) & SPL
logical_index = (links(:, 1) == 1) & (links(:, 2) == 5);
count (5) = sum(logical_index);

%% CC (+) & APLHA
logical_index = (links(:, 1) == 2) & (links(:, 2) == 1);
count (6) = sum(logical_index);

%% CC (+) & BETA
logical_index = (links(:, 1) == 2) & (links(:, 2) == 2);
count (7) = sum(logical_index);

%% CC (+) & MAX
logical_index = (links(:, 1) == 2) & (links(:, 2) == 3);
count (8) = sum(logical_index);

%% CC (+) & SPL
logical_index = (links(:, 1) == 2) & (links(:, 2) == 4);
count (9) = sum(logical_index);

%% CC (+) & SPL
logical_index = (links(:, 1) == 2) & (links(:, 2) == 5);
count (10) = sum(logical_index);

%% LCC (+) & APLHA
logical_index = (links(:, 1) == 3) & (links(:, 2) == 1);
count (11) = sum(logical_index);

%% LCC (+) & BETA
logical_index = (links(:, 1) == 3) & (links(:, 2) == 2);
count (12) = sum(logical_index);

%% LCC (+) & MAX
logical_index = (links(:, 1) == 3) & (links(:, 2) == 3);
count (13) = sum(logical_index);

%% LCC (+) & SPL
logical_index = (links(:, 1) == 3) & (links(:, 2) == 4);
count (14) = sum(logical_index);

%% LCC (+) & SPL
logical_index = (links(:, 1) == 3) & (links(:, 2) == 5);
count (15) = sum(logical_index);

links = zeros (15,3);
links (:,1) = [1 1 1 1 1 2 2 2 2 2 3 3 3 3 3];
links (:,2) = [1 2 3 4 5 1 2 3 4 5 1 2 3 4 5];
links (:,3) = count;

links_cell = num2cell(links);
for i = 1:15
    if links_cell{i,1} == 1
        links_cell{i,1} = 'CO2';  
    elseif links_cell{i,1} == 2
        links_cell{i,1} = 'CC';
    elseif links_cell{i,1} == 3
        links_cell{i,1} = 'LCC';
    end
end
for i = 1:15
    if links_cell{i,2} == 1
        links_cell{i,2} = 'ALPHA';
    elseif links_cell{i,2} == 2
        links_cell{i,2} = 'BETA';
    elseif links_cell{i,2} == 3
        links_cell{i,2} = 'MAX';
    elseif links_cell{i,2} == 4
        links_cell{i,2} = 'SPL';
    elseif links_cell{i,2} == 5
        links_cell{i,2} = 'APL';
    end
end

SK = SSankey (links_cell(:,1), links_cell(:,2), links_cell(:,3));
SK.draw()