%% ALPHA
clear
clc

load('predicted_byRF.mat')

% predicted_component_ALPHA = reshape (predicted_component_ALPHA, [22982,19]);
% MODIS_NDVI_predicted_component_ALPHA = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_ALPHA (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_ALPHA (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_ALPHA MODIS_NDVI_predicted_component_ALPHA

predicted_component_ALPHA_cc = reshape (predicted_component_ALPHA_cc, [22982,19]);
MODIS_NDVI_predicted_component_ALPHA_cc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_ALPHA_cc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_ALPHA_cc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_ALPHA_cc MODIS_NDVI_predicted_component_ALPHA_cc

predicted_component_ALPHA_co2 = reshape (predicted_component_ALPHA_co2, [22982,19]);
MODIS_NDVI_predicted_component_ALPHA_co2 = zeros (347,720,19);

for i = 1:19
    var = predicted_component_ALPHA_co2 (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_ALPHA_co2 (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_ALPHA_co2 MODIS_NDVI_predicted_component_ALPHA_co2

predicted_component_ALPHA_lcc = reshape (predicted_component_ALPHA_lcc, [22982,19]);
MODIS_NDVI_predicted_component_ALPHA_lcc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_ALPHA_lcc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_ALPHA_lcc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_ALPHA_lcc MODIS_NDVI_predicted_component_ALPHA_lcc

% predicted_component_ALPHA_others = reshape (predicted_component_ALPHA_others, [22982,19]);
% MODIS_NDVI_predicted_component_ALPHA_others = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_ALPHA_others (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_ALPHA_others (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_ALPHA_others MODIS_NDVI_predicted_component_ALPHA_others

%% BETA
clear
clc

load('predicted_byRF.mat')

% predicted_component_BETA = reshape (predicted_component_BETA, [22982,19]);
% MODIS_NDVI_predicted_component_BETA = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_BETA (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_BETA (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_BETA MODIS_NDVI_predicted_component_BETA

predicted_component_BETA_cc = reshape (predicted_component_BETA_cc, [22982,19]);
MODIS_NDVI_predicted_component_BETA_cc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_BETA_cc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_BETA_cc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_BETA_cc MODIS_NDVI_predicted_component_BETA_cc

predicted_component_BETA_co2 = reshape (predicted_component_BETA_co2, [22982,19]);
MODIS_NDVI_predicted_component_BETA_co2 = zeros (347,720,19);

for i = 1:19
    var = predicted_component_BETA_co2 (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_BETA_co2 (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_BETA_co2 MODIS_NDVI_predicted_component_BETA_co2

predicted_component_BETA_lcc = reshape (predicted_component_BETA_lcc, [22982,19]);
MODIS_NDVI_predicted_component_BETA_lcc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_BETA_lcc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_BETA_lcc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_BETA_lcc MODIS_NDVI_predicted_component_BETA_lcc

% predicted_component_BETA_others = reshape (predicted_component_BETA_others, [22982,19]);
% MODIS_NDVI_predicted_component_BETA_others = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_BETA_others (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_BETA_others (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_BETA_others MODIS_NDVI_predicted_component_BETA_others

%% AMP
clear
clc

load('predicted_byRF.mat')

% predicted_component_AMP = reshape (predicted_component_AMP, [22982,19]);
% MODIS_NDVI_predicted_component_AMP = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_AMP (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_AMP (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_AMP MODIS_NDVI_predicted_component_AMP

predicted_component_AMP_cc = reshape (predicted_component_AMP_cc, [22982,19]);
MODIS_NDVI_predicted_component_AMP_cc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_AMP_cc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_AMP_cc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_AMP_cc MODIS_NDVI_predicted_component_AMP_cc

predicted_component_AMP_co2 = reshape (predicted_component_AMP_co2, [22982,19]);
MODIS_NDVI_predicted_component_AMP_co2 = zeros (347,720,19);

for i = 1:19
    var = predicted_component_AMP_co2 (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_AMP_co2 (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_AMP_co2 MODIS_NDVI_predicted_component_AMP_co2

predicted_component_AMP_lcc = reshape (predicted_component_AMP_lcc, [22982,19]);
MODIS_NDVI_predicted_component_AMP_lcc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_AMP_lcc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_AMP_lcc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_AMP_lcc MODIS_NDVI_predicted_component_AMP_lcc

% predicted_component_AMP_others = reshape (predicted_component_AMP_others, [22982,19]);
% MODIS_NDVI_predicted_component_AMP_others = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_AMP_others (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_AMP_others (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_AMP_others MODIS_NDVI_predicted_component_AMP_others

%% SPL
clear
clc

load('predicted_byRF.mat')

% predicted_component_SPL = reshape (predicted_component_SPL, [22982,19]);
% MODIS_NDVI_predicted_component_SPL = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_SPL (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_SPL (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_SPL MODIS_NDVI_predicted_component_SPL

predicted_component_SPL_cc = reshape (predicted_component_SPL_cc, [22982,19]);
MODIS_NDVI_predicted_component_SPL_cc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_SPL_cc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_SPL_cc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_SPL_cc MODIS_NDVI_predicted_component_SPL_cc

predicted_component_SPL_co2 = reshape (predicted_component_SPL_co2, [22982,19]);
MODIS_NDVI_predicted_component_SPL_co2 = zeros (347,720,19);

for i = 1:19
    var = predicted_component_SPL_co2 (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_SPL_co2 (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_SPL_co2 MODIS_NDVI_predicted_component_SPL_co2

predicted_component_SPL_lcc = reshape (predicted_component_SPL_lcc, [22982,19]);
MODIS_NDVI_predicted_component_SPL_lcc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_SPL_lcc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_SPL_lcc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_SPL_lcc MODIS_NDVI_predicted_component_SPL_lcc

% predicted_component_SPL_others = reshape (predicted_component_SPL_others, [22982,19]);
% MODIS_NDVI_predicted_component_SPL_others = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_SPL_others (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_SPL_others (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_SPL_others MODIS_NDVI_predicted_component_SPL_others

%% APL
clear
clc

load('predicted_byRF.mat')

% predicted_component_APL = reshape (predicted_component_APL, [22982,19]);
% MODIS_NDVI_predicted_component_APL = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_APL (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_APL (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_APL MODIS_NDVI_predicted_component_APL

predicted_component_APL_cc = reshape (predicted_component_APL_cc, [22982,19]);
MODIS_NDVI_predicted_component_APL_cc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_APL_cc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_APL_cc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_APL_cc MODIS_NDVI_predicted_component_APL_cc

predicted_component_APL_co2 = reshape (predicted_component_APL_co2, [22982,19]);
MODIS_NDVI_predicted_component_APL_co2 = zeros (347,720,19);

for i = 1:19
    var = predicted_component_APL_co2 (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_APL_co2 (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_APL_co2 MODIS_NDVI_predicted_component_APL_co2

predicted_component_APL_lcc = reshape (predicted_component_APL_lcc, [22982,19]);
MODIS_NDVI_predicted_component_APL_lcc = zeros (347,720,19);

for i = 1:19
    var = predicted_component_APL_lcc (:,i);
    
    global_var = zeros (1,347*720);
    global_var (global_var == 0) = nan;
    
    global_var (observable_phenology_position) = var;
    MODIS_NDVI_predicted_component_APL_lcc (:,:,i) = reshape (global_var, [347,720]);
end

save MODIS_NDVI_predicted_component_APL_lcc MODIS_NDVI_predicted_component_APL_lcc

% predicted_component_APL_others = reshape (predicted_component_APL_others, [22982,19]);
% MODIS_NDVI_predicted_component_APL_others = zeros (347,720,19);
% 
% for i = 1:19
%     var = predicted_component_APL_others (:,i);
%     
%     global_var = zeros (1,347*720);
%     global_var (global_var == 0) = nan;
%     
%     global_var (observable_phenology_position) = var;
%     MODIS_NDVI_predicted_component_APL_others (:,:,i) = reshape (global_var, [347,720]);
% end
% 
% save MODIS_NDVI_predicted_component_APL_others MODIS_NDVI_predicted_component_APL_others