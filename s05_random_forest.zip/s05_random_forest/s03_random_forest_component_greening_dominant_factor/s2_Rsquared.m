clear
clc

load('MCD19A3_NDVI_ALPHA_2000_2020_filled.mat')
load('MODIS_NDVI_predicted_component_ALPHA.mat')

load('mask_greening_pixels.mat')

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        var_observed = MCD19A3_NDVI_ALPHA_2000_2020_filled (i,j,:);
        var_observed = var_observed (1,:);
        
        var_modelled = MODIS_NDVI_predicted_component_ALPHA (i,j,:);
        var_modelled = var_modelled (1,:);
        
        valid_length = length (var_observed (isnan (var_observed)));
        
        if mask == 1 && valid_length ~= 19
            
            [xData, yData] = prepareCurveData(var_modelled, var_observed);
            ft = fittype('poly1');
            [fitresult, gof] = fit(xData, yData, ft);
            
            R_squared_var_ALPHA (i,j) = gof.rsquare;
            
        else
            R_squared_var_ALPHA (i,j) = nan;
            
        end
    end
end

h = imagesc (R_squared_var_ALPHA);
set(h,'alphadata',~isnan(R_squared_var_ALPHA))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

save R_squared_var_ALPHA R_squared_var_ALPHA

clear
clc

load('MCD19A3_NDVI_BETA_2000_2020_filled.mat')
load('MODIS_NDVI_predicted_component_BETA.mat')

load('mask_greening_pixels.mat')

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        var_observed = MCD19A3_NDVI_BETA_2000_2020_filled (i,j,:);
        var_observed = var_observed (1,:);
        
        var_modelled = MODIS_NDVI_predicted_component_BETA (i,j,:);
        var_modelled = var_modelled (1,:);
        
        valid_length = length (var_observed (isnan (var_observed)));
        
        if mask == 1 && valid_length ~= 19
            
            [xData, yData] = prepareCurveData(var_modelled, var_observed);
            ft = fittype('poly1');
            [fitresult, gof] = fit(xData, yData, ft);
            
            R_squared_var_BETA (i,j) = gof.rsquare;
            
        else
            R_squared_var_BETA (i,j) = nan;
            
        end
    end
end

h = imagesc (R_squared_var_BETA);
set(h,'alphadata',~isnan(R_squared_var_BETA))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

save R_squared_var_BETA R_squared_var_BETA

clear
clc

load('MCD19A3_NDVI_AMP_2000_2020_filled.mat')
load('MODIS_NDVI_predicted_component_AMP.mat')

load('mask_greening_pixels.mat')

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        var_observed = MCD19A3_NDVI_AMP_2000_2020_filled (i,j,:);
        var_observed = var_observed (1,:);
        
        var_modelled = MODIS_NDVI_predicted_component_AMP (i,j,:);
        var_modelled = var_modelled (1,:);
        
        valid_length = length (var_observed (isnan (var_observed)));
        
        if mask == 1 && valid_length ~= 19
            
            [xData, yData] = prepareCurveData(var_modelled, var_observed);
            ft = fittype('poly1');
            [fitresult, gof] = fit(xData, yData, ft);
            
            R_squared_var_AMP (i,j) = gof.rsquare;
            
        else
            R_squared_var_AMP (i,j) = nan;
            
        end
    end
end

h = imagesc (R_squared_var_AMP);
set(h,'alphadata',~isnan(R_squared_var_AMP))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

save R_squared_var_AMP R_squared_var_AMP

clear
clc

load('MCD19A3_NDVI_SPL_2000_2020_filled.mat')
load('MODIS_NDVI_predicted_component_SPL.mat')

load('mask_greening_pixels.mat')

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        var_observed = MCD19A3_NDVI_SPL_2000_2020_filled (i,j,:);
        var_observed = var_observed (1,:);
        
        var_modelled = MODIS_NDVI_predicted_component_SPL (i,j,:);
        var_modelled = var_modelled (1,:);
        
        valid_length = length (var_observed (isnan (var_observed)));
        
        if mask == 1 && valid_length ~= 19
            
            [xData, yData] = prepareCurveData(var_modelled, var_observed);
            ft = fittype('poly1');
            [fitresult, gof] = fit(xData, yData, ft);
            
            R_squared_var_SPL (i,j) = gof.rsquare;
            
        else
            R_squared_var_SPL (i,j) = nan;
            
        end
    end
end

h = imagesc (R_squared_var_SPL);
set(h,'alphadata',~isnan(R_squared_var_SPL))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

save R_squared_var_SPL R_squared_var_SPL

clear
clc

load('MCD19A3_NDVI_APL_2000_2020_filled.mat')
load('MODIS_NDVI_predicted_component_APL.mat')

load('mask_greening_pixels.mat')

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        var_observed = MCD19A3_NDVI_APL_2000_2020_filled (i,j,:);
        var_observed = var_observed (1,:);
        
        var_modelled = MODIS_NDVI_predicted_component_APL (i,j,:);
        var_modelled = var_modelled (1,:);
        
        valid_length = length (var_observed (isnan (var_observed)));
        
        if mask == 1 && valid_length ~= 19
            
            [xData, yData] = prepareCurveData(var_modelled, var_observed);
            ft = fittype('poly1');
            [fitresult, gof] = fit(xData, yData, ft);
            
            R_squared_var_APL (i,j) = gof.rsquare;
            
        else
            R_squared_var_APL (i,j) = nan;
            
        end
    end
end

h = imagesc (R_squared_var_APL);
set(h,'alphadata',~isnan(R_squared_var_APL))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

save R_squared_var_APL R_squared_var_APL

%%
load('R_squared_var_ALPHA.mat')
load('R_squared_var_AMP.mat')
load('R_squared_var_APL.mat')
load('R_squared_var_BETA.mat')
load('R_squared_var_SPL.mat')

h1 = histogram(R_squared_var_ALPHA);
hold on
h2 = histogram(R_squared_var_BETA);
hold on
h3 = histogram(R_squared_var_AMP);
hold on
h4 = histogram(R_squared_var_SPL);
hold on
h5 = histogram(R_squared_var_APL);

h1.Normalization = 'probability';
h1.BinWidth = 0.01;
h2.Normalization = 'probability';
h2.BinWidth = 0.01;
h3.Normalization = 'probability';
h3.BinWidth = 0.01;
h4.Normalization = 'probability';
h4.BinWidth = 0.01;
h5.Normalization = 'probability';
h5.BinWidth = 0.01;