
clear
clc

load('predicted_byRF_global.mat')
load('mask_greening_pixels.mat')

years = 1:19;

%% cc
% i = 120; j = 582;
component_ALPHA_cc  = zeros (347,720,19);
component_BETA_cc   = zeros (347,720,19);
component_AMP_cc    = zeros (347,720,19);
component_APL_cc    = zeros (347,720,19);
component_SPL_cc    = zeros (347,720,19);

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        ALPHA = MODIS_NDVI_predicted_component_ALPHA_cc (i,j,:);
        BETA  = MODIS_NDVI_predicted_component_BETA_cc (i,j,:);
        AMP   = MODIS_NDVI_predicted_component_AMP_cc (i,j,:);
        SPL   = MODIS_NDVI_predicted_component_SPL_cc (i,j,:);
        APL   = MODIS_NDVI_predicted_component_APL_cc (i,j,:);
        
        ALPHA = ALPHA (1,:);
        BETA  = BETA (1,:);
        AMP   = AMP (1,:);
        SPL   = SPL (1,:);
        APL   = APL (1,:);
        
        %         nan_ALPHA = length (ALPHA (~isnan (ALPHA)));
        %         nan_BETA  = length (BETA (~isnan (BETA)));
        %         nan_AMP   = length (AMP (~isnan (AMP)));
        %         nan_SPL   = length (SPL (~isnan (SPL)));
        %         nan_APL   = length (APL (~isnan (APL)));
        
        if mask == 1
            
            d_ALPHA = ALPHA - mean (ALPHA);
            d_BETA  = BETA - mean (BETA);
            d_AMP   = AMP - mean (AMP);
            d_SPL   = SPL - mean (SPL);
            d_APL   = APL - mean (APL);
            
            component_ALPHA_cc (i,j,:)   = SPL .* AMP .* d_ALPHA;
            component_BETA_cc (i,j,:)    = APL .* AMP .* d_BETA;
            component_AMP_cc (i,j,:)     = (ALPHA .* SPL + BETA .* APL) .* d_AMP;
            component_SPL_cc  (i,j,:)    = ALPHA .* AMP .* d_SPL;
            component_APL_cc (i,j,:)     = BETA .* AMP .* d_APL;
            
        else
            
            component_ALPHA_cc (i,j,:)   = nan;
            component_BETA_cc (i,j,:)    = nan;
            component_AMP_cc (i,j,:)     = nan;
            component_SPL_cc  (i,j,:)    = nan;
            component_APL_cc (i,j,:)     = nan;
            
        end
    end
end

save component_ALPHA_cc component_ALPHA_cc
save component_BETA_cc component_BETA_cc
save component_AMP_cc component_AMP_cc
save component_SPL_cc component_SPL_cc
save component_APL_cc component_APL_cc

%% co2
% i = 120; j = 582;
component_ALPHA_co2  = zeros (347,720,19);
component_BETA_co2   = zeros (347,720,19);
component_AMP_co2    = zeros (347,720,19);
component_APL_co2    = zeros (347,720,19);
component_SPL_co2    = zeros (347,720,19);

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        ALPHA = MODIS_NDVI_predicted_component_ALPHA_co2 (i,j,:);
        BETA  = MODIS_NDVI_predicted_component_BETA_co2 (i,j,:);
        AMP   = MODIS_NDVI_predicted_component_AMP_co2 (i,j,:);
        SPL   = MODIS_NDVI_predicted_component_SPL_co2 (i,j,:);
        APL   = MODIS_NDVI_predicted_component_APL_co2 (i,j,:);
        
        ALPHA = ALPHA (1,:);
        BETA  = BETA (1,:);
        AMP   = AMP (1,:);
        SPL   = SPL (1,:);
        APL   = APL (1,:);
        
        %         nan_ALPHA = length (ALPHA (~isnan (ALPHA)));
        %         nan_BETA  = length (BETA (~isnan (BETA)));
        %         nan_AMP   = length (AMP (~isnan (AMP)));
        %         nan_SPL   = length (SPL (~isnan (SPL)));
        %         nan_APL   = length (APL (~isnan (APL)));
        
        if mask == 1
            
            d_ALPHA = ALPHA - mean (ALPHA);
            d_BETA  = BETA - mean (BETA);
            d_AMP   = AMP - mean (AMP);
            d_SPL   = SPL - mean (SPL);
            d_APL   = APL - mean (APL);
            
            component_ALPHA_co2 (i,j,:)   = SPL .* AMP .* d_ALPHA;
            component_BETA_co2 (i,j,:)    = APL .* AMP .* d_BETA;
            component_AMP_co2 (i,j,:)     = (ALPHA .* SPL + BETA .* APL) .* d_AMP;
            component_SPL_co2  (i,j,:)    = ALPHA .* AMP .* d_SPL;
            component_APL_co2 (i,j,:)     = BETA .* AMP .* d_APL;
            
        else
            
            component_ALPHA_co2 (i,j,:)   = nan;
            component_BETA_co2 (i,j,:)    = nan;
            component_AMP_co2 (i,j,:)     = nan;
            component_SPL_co2  (i,j,:)    = nan;
            component_APL_co2 (i,j,:)     = nan;
            
        end
    end
end

save component_ALPHA_co2 component_ALPHA_co2
save component_BETA_co2 component_BETA_co2
save component_AMP_co2 component_AMP_co2
save component_SPL_co2 component_SPL_co2
save component_APL_co2 component_APL_co2

%% lcc
% i = 120; j = 582;
component_ALPHA_lcc  = zeros (347,720,19);
component_BETA_lcc   = zeros (347,720,19);
component_AMP_lcc    = zeros (347,720,19);
component_APL_lcc    = zeros (347,720,19);
component_SPL_lcc    = zeros (347,720,19);

parfor i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        ALPHA = MODIS_NDVI_predicted_component_ALPHA_lcc (i,j,:);
        BETA  = MODIS_NDVI_predicted_component_BETA_lcc (i,j,:);
        AMP   = MODIS_NDVI_predicted_component_AMP_lcc (i,j,:);
        SPL   = MODIS_NDVI_predicted_component_SPL_lcc (i,j,:);
        APL   = MODIS_NDVI_predicted_component_APL_lcc (i,j,:);
        
        ALPHA = ALPHA (1,:);
        BETA  = BETA (1,:);
        AMP   = AMP (1,:);
        SPL   = SPL (1,:);
        APL   = APL (1,:);
        
        %         nan_ALPHA = length (ALPHA (~isnan (ALPHA)));
        %         nan_BETA  = length (BETA (~isnan (BETA)));
        %         nan_AMP   = length (AMP (~isnan (AMP)));
        %         nan_SPL   = length (SPL (~isnan (SPL)));
        %         nan_APL   = length (APL (~isnan (APL)));
        
        if mask == 1
            
            d_ALPHA = ALPHA - mean (ALPHA);
            d_BETA  = BETA - mean (BETA);
            d_AMP   = AMP - mean (AMP);
            d_SPL   = SPL - mean (SPL);
            d_APL   = APL - mean (APL);
            
            component_ALPHA_lcc (i,j,:)   = SPL .* AMP .* d_ALPHA;
            component_BETA_lcc (i,j,:)    = APL .* AMP .* d_BETA;
            component_AMP_lcc (i,j,:)     = (ALPHA .* SPL + BETA .* APL) .* d_AMP;
            component_SPL_lcc  (i,j,:)    = ALPHA .* AMP .* d_SPL;
            component_APL_lcc (i,j,:)     = BETA .* AMP .* d_APL;
            
        else
            
            component_ALPHA_lcc (i,j,:)   = nan;
            component_BETA_lcc (i,j,:)    = nan;
            component_AMP_lcc (i,j,:)     = nan;
            component_SPL_lcc  (i,j,:)    = nan;
            component_APL_lcc (i,j,:)     = nan;
            
        end
    end
end

save component_ALPHA_lcc component_ALPHA_lcc
save component_BETA_lcc component_BETA_lcc
save component_AMP_lcc component_AMP_lcc
save component_SPL_lcc component_SPL_lcc
save component_APL_lcc component_APL_lcc

% %% others
% % i = 120; j = 582;
% component_ALPHA_others  = zeros (347,720,19);
% component_BETA_others   = zeros (347,720,19);
% component_AMP_others    = zeros (347,720,19);
% component_APL_others    = zeros (347,720,19);
% component_SPL_others    = zeros (347,720,19);
% 
% parfor i = 1:347
%     for j = 1:720
%         
%         mask = mask_greening_pixels (i,j);
%         
%         ALPHA = MODIS_NDVI_predicted_component_ALPHA_others (i,j,:);
%         BETA  = MODIS_NDVI_predicted_component_BETA_others (i,j,:);
%         AMP   = MODIS_NDVI_predicted_component_AMP_others (i,j,:);
%         SPL   = MODIS_NDVI_predicted_component_SPL_others (i,j,:);
%         APL   = MODIS_NDVI_predicted_component_APL_others (i,j,:);
%         
%         ALPHA = ALPHA (1,:);
%         BETA  = BETA (1,:);
%         AMP   = AMP (1,:);
%         SPL   = SPL (1,:);
%         APL   = APL (1,:);
%         
%         %         nan_ALPHA = length (ALPHA (~isnan (ALPHA)));
%         %         nan_BETA  = length (BETA (~isnan (BETA)));
%         %         nan_AMP   = length (AMP (~isnan (AMP)));
%         %         nan_SPL   = length (SPL (~isnan (SPL)));
%         %         nan_APL   = length (APL (~isnan (APL)));
%         
%         if mask == 1
%             
%             d_ALPHA = ALPHA - mean (ALPHA);
%             d_BETA  = BETA - mean (BETA);
%             d_AMP   = AMP - mean (AMP);
%             d_SPL   = SPL - mean (SPL);
%             d_APL   = APL - mean (APL);
%             
%             component_ALPHA_others (i,j,:)   = SPL .* AMP .* d_ALPHA;
%             component_BETA_others (i,j,:)    = APL .* AMP .* d_BETA;
%             component_AMP_others (i,j,:)     = (ALPHA .* SPL + BETA .* APL) .* d_AMP;
%             component_SPL_others  (i,j,:)    = ALPHA .* AMP .* d_SPL;
%             component_APL_others (i,j,:)     = BETA .* AMP .* d_APL;
%             
%         else
%             
%             component_ALPHA_others (i,j,:)   = nan;
%             component_BETA_others (i,j,:)    = nan;
%             component_AMP_others (i,j,:)     = nan;
%             component_SPL_others  (i,j,:)    = nan;
%             component_APL_others (i,j,:)     = nan;
%             
%         end
%     end
% end
% 
% save component_ALPHA_others component_ALPHA_others
% save component_BETA_others component_BETA_others
% save component_AMP_others component_AMP_others
% save component_SPL_others component_SPL_others
% save component_APL_others component_APL_others