clear
clc

load('dominant_type_2020.mat')
load('co2_cc_lcc_dominant_factor.mat')

dominant_type_2020 (dominant_type_2020 == 2)  = 1; % BDF
dominant_type_2020 (dominant_type_2020 == 3)  = 1; % BEF
dominant_type_2020 (dominant_type_2020 == 7)  = 1; % NDF
dominant_type_2020 (dominant_type_2020 == 8)  = 1; % NEF

dominant_type_2020 (dominant_type_2020 == 5)  = 2; % CROPS
dominant_type_2020 (dominant_type_2020 == 6)  = 2; % GRASS
dominant_type_2020 (dominant_type_2020 == 10) = 2; % SHRUBS

dominant_type_2020 (dominant_type_2020 ~= 1 & dominant_type_2020 ~= 2) = nan;

for i = 1:347
    
    type = dominant_type_2020 (i,:);
    factor = co2_cc_lcc_dominant_factor (i,:);
    
    %% co2
    condition = (type == 1) & (factor == 1);
    co2_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 1);
    co2_nonforest (i) = sum(condition);
    
    %% cc
    condition = (type == 1) & (factor == 2);
    cc_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 2);
    cc_nonforest (i) = sum(condition);
    
    %% lcc
    condition = (type == 1) & (factor == 3);
    lcc_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 3);
    lcc_nonforest (i) = sum(condition);
    
end

% subplot (1,3,3)
% number = [ALPHA_greening;BETA_greening;AMP_greening;SPL_greening;APL_greening];
% bar(number,'stacked')

subplot (1,2,1)
plot(co2_forest,'LineWidth', 3)
hold on
plot(cc_forest,'LineWidth', 3)
hold on
plot(lcc_forest,'LineWidth', 3)
hold on
subplot (1,2,2)
plot(co2_nonforest,'LineWidth', 3)
hold on
plot(cc_nonforest,'LineWidth', 3)
hold on
plot(lcc_nonforest,'LineWidth', 3)
