clear
clc

info = geotiffinfo('geoinfo.tif');

% ��ȡ����㾭γ��
for i = 1:347
    for j = 1:720
        
        [x,y] = pix2map(info.RefMatrix, i, j);
        lat(i,j) = y;
        lon(i,j) = x;
        
    end
end

save lat lat
save lon lon