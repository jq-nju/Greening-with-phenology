clear
clc

load('MCD19A3_NDVI_APL_2000_2020_filled.mat')
load('slope_MK_2000_2020.mat', 'NDVIgs_slope_2000_2020')
load('slope_MK_2000_2020.mat', 'NDVIgs_sig_2000_2020')

% greening pixels
% NDVIgs_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;
load('mask_phenological_cycle_yearly_valid.mat')
NDVIgs_slope_2000_2020 (isnan (mask_phenological_cycle_yearly_valid)) = nan;
NDVIgs_slope_2000_2020 (NDVIgs_slope_2000_2020 <= 0) = nan;
NDVIgs_slope_2000_2020 (~isnan (NDVIgs_slope_2000_2020)) = 1;
mask_greening_pixels = NDVIgs_slope_2000_2020;
save mask_greening_pixels mask_greening_pixels

load('esacci_2000_2020.mat', 'esacci_BDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_BEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_CROP_2000_2020')
load('esacci_2000_2020.mat', 'esacci_GRASS_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_SHRUBS_2000_2020')

esacci_BDF = esacci_BDF_2000_2020 (:,:,2:20);
esacci_BEF = esacci_BEF_2000_2020 (:,:,2:20);
esacci_CRO = esacci_CROP_2000_2020 (:,:,2:20);
esacci_GRA = esacci_GRASS_2000_2020 (:,:,2:20);
esacci_NDF = esacci_NDF_2000_2020 (:,:,2:20);
esacci_NEF = esacci_NEF_2000_2020 (:,:,2:20);
esacci_SHR = esacci_SHRUBS_2000_2020 (:,:,2:20);

clear esacci_BDF_2000_2020 esacci_BDF_2000_2020
clear esacci_BEF_2000_2020 esacci_BEF_2000_2020
clear esacci_CROP_2000_2020 esacci_CROP_2000_2020
clear esacci_GRASS_2000_2020 esacci_GRASS_2000_2020
clear esacci_NDF_2000_2020 esacci_NDF_2000_2020
clear esacci_NEF_2000_2020 esacci_NEF_2000_2020
clear esacci_SHRUBS_2000_2020 esacci_SHRUBS_2000_2020

load('yearly_temperature_growing_2000_2020_filled.mat')
load('yearly_precipitation_growing_2000_2020_filled.mat')
load('yearly_co2_growing_2000_2020_filled.mat')

load('yearly_radiation_growing_2000_2020_filled.mat')
load('yearly_wind_speed_growing_2000_2020_filled.mat')
load('yearly_vpd_growing_2000_2020_filled.mat')

load('yearly_temperature_max_growing_2000_2020_filled.mat')
load('yearly_temperature_min_growing_2000_2020_filled.mat')

load('lat.mat')
load('lon.mat')

MCD19A3_NDVI_APL_2000_2020_filled = nanmean (MCD19A3_NDVI_APL_2000_2020_filled,3);
yearly_temperature_growing_2000_2020_filled = nanmean (yearly_temperature_growing_2000_2020_filled,3);
yearly_precipitation_growing_2000_2020_filled = nanmean (yearly_precipitation_growing_2000_2020_filled,3);
yearly_co2_growing_2000_2020_filled = nanmean (yearly_co2_growing_2000_2020_filled,3);
yearly_radiation_growing_2000_2020_filled = nanmean (yearly_radiation_growing_2000_2020_filled,3);
yearly_wind_speed_growing_2000_2020_filled = nanmean (yearly_wind_speed_growing_2000_2020_filled,3);
yearly_vpd_growing_2000_2020_filled = nanmean (yearly_vpd_growing_2000_2020_filled,3);
yearly_temperature_max_growing_2000_2020_filled = nanmean (yearly_temperature_max_growing_2000_2020_filled,3);
yearly_temperature_min_growing_2000_2020_filled = nanmean (yearly_temperature_min_growing_2000_2020_filled,3);
esacci_BDF = nanmean (esacci_BDF,3);
esacci_BEF = nanmean (esacci_BEF,3);
esacci_CRO = nanmean (esacci_CRO,3);
esacci_GRA = nanmean (esacci_GRA,3);
esacci_NDF = nanmean (esacci_NDF,3);
esacci_NEF = nanmean (esacci_NEF,3);
esacci_SHR = nanmean (esacci_SHR,3);

mask = reshape (mask_greening_pixels,[347*720,1]);
y = reshape (MCD19A3_NDVI_APL_2000_2020_filled,[347*720,1]);
mask (isnan (y)) = nan;

x_tmp_growing = reshape (yearly_temperature_growing_2000_2020_filled,[347*720,1]);
x_pre_growing = reshape (yearly_precipitation_growing_2000_2020_filled,[347*720,1]);
x_co2_growing = reshape (yearly_co2_growing_2000_2020_filled,[347*720,1]);

x_rad_growing = reshape (yearly_radiation_growing_2000_2020_filled,[347*720,1]);
x_wsp_growing = reshape (yearly_wind_speed_growing_2000_2020_filled,[347*720,1]);
x_vpd_growing = reshape (yearly_vpd_growing_2000_2020_filled,[347*720,1]);

x_tmp_max_growing = reshape (yearly_temperature_max_growing_2000_2020_filled,[347*720,1]);
x_tmp_min_growing = reshape (yearly_temperature_min_growing_2000_2020_filled,[347*720,1]);

x_BDF = reshape (esacci_BDF,[347*720,1]);
x_BEF = reshape (esacci_BEF,[347*720,1]);
x_CRO = reshape (esacci_CRO,[347*720,1]);
x_GRA = reshape (esacci_GRA,[347*720,1]);
x_NDF = reshape (esacci_NDF,[347*720,1]);
x_NEF = reshape (esacci_NEF,[347*720,1]);
x_SHR = reshape (esacci_SHR,[347*720,1]);
% x_NON = 100 - (x_BDF + x_BEF + x_CRO + x_GRA + x_NDF + x_NEF + x_SHR);

x_lat = reshape (lat,[347*720,1]);
x_lon = reshape (lon,[347*720,1]);

observable_phenology_position = find (mask == 1);
save observable_phenology_position observable_phenology_position

y (mask ~= 1) = [];

x_tmp_growing (mask ~= 1) = [];
x_pre_growing (mask ~= 1) = [];
x_co2_growing (mask ~= 1) = [];

x_rad_growing (mask ~= 1) = [];
x_wsp_growing (mask ~= 1) = [];
x_vpd_growing (mask ~= 1) = [];

x_tmp_max_growing (mask ~= 1) = [];
x_tmp_min_growing (mask ~= 1) = [];

x_BDF (mask ~= 1) = [];
x_BEF (mask ~= 1) = [];
x_CRO (mask ~= 1) = [];
x_GRA (mask ~= 1) = [];
x_NDF (mask ~= 1) = [];
x_NEF (mask ~= 1) = [];
% x_NON (mask ~= 1) = [];
x_SHR (mask ~= 1) = [];

x_lat (mask ~= 1) = [];
x_lon (mask ~= 1) = [];

clear MCD19A3_NDVI_APL_2000_2020_filled MCD19A3_NDVI_APL_2000_2020_filled

clear esacci_BDF esacci_BDF
clear esacci_BEF esacci_BEF
clear esacci_CRO esacci_CRO
clear esacci_GRA esacci_GRA
clear esacci_NDF esacci_NDF
clear esacci_NEF esacci_NEF
clear esacci_NON esacci_NON
clear esacci_SHR esacci_SHR

clear yearly_temperature_growing_2000_2020_filled yearly_temperature_growing_2000_2020_filled
clear yearly_precipitation_growing_2000_2020_filled yearly_precipitation_growing_2000_2020_filled
clear yearly_co2_growing_2000_2020_filled yearly_co2_growing_2000_2020_filled

clear yearly_radiation_growing_2000_2020_filled yearly_radiation_growing_2000_2020_filled
clear yearly_wind_speed_growing_2000_2020_filled yearly_wind_speed_growing_2000_2020_filled
clear yearly_vpd_growing_2000_2020_filled yearly_vpd_growing_2000_2020_filled

clear yearly_temperature_max_growing_2000_2020_filled yearly_temperature_max_growing_2000_2020_filled
clear yearly_temperature_min_growing_2000_2020_filled yearly_temperature_min_growing_2000_2020_filled

%% random forest
data_matrix_APL = [x_tmp_growing, x_tmp_max_growing, x_tmp_min_growing, x_pre_growing, x_co2_growing, x_rad_growing, x_vpd_growing, x_wsp_growing, x_BDF, x_BEF, x_CRO, x_GRA, x_NDF, x_NEF, x_SHR, x_lat, x_lon, y];
%% 80% trainging data
%% 20% validating data
rng(42);
n = size(data_matrix_APL, 1);
indices = randperm(n);
n_train = round (n * 0.8);

train_indices = indices(1:n_train);
% validate_indices = indices(n_train+1:end);

data_matrix_APL_train = data_matrix_APL (train_indices,:);
% data_matrix_APL_validate = data_matrix_APL (validate_indices,:);

% data_matrix_APL = data_matrix_APL (1:1000,:);

% ��������������Ա������ظ�
rng(1);

% ��Ѳ�����ѡ��ʹ�þ�ֵ�õ�
% ��������ŵĲ�����Χ
numTrees_range = [50, 100, 200, 300];  % ��������
mTry_range = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];  % ÿ�������ѡ��ı�������

best_mse = Inf;  % ��ʼ����Ѿ������
best_params = struct();  % ������Ѳ����Ľṹ��

% ��������
xx = data_matrix_APL_train (:, 1:end-1);
yy = data_matrix_APL_train (:, end);

for i = 1:length(numTrees_range)
    for j = 1:length(mTry_range)
        numTrees = numTrees_range(i);
        mTry = mTry_range(j);
        
        % �������ɭ��ģ��
        rf_model = TreeBagger(numTrees, xx, yy, 'Method', 'regression','NumPredictorsToSample', mTry);
        
        % Ԥ���µĹ۲�ֵ
        predicted_y = single (predict(rf_model, xx));
        
        % ���������MSE��
        observed_y = yy;
        mse = immse(observed_y, predicted_y);
        
        % ������Ѳ�������Ѿ������
        if mse < best_mse
            best_mse = mse;
            best_params.numTrees = numTrees;
            best_params.mTry = mTry;
        end
        
        disp (i)
        disp (j)
    end
end

% �����Ѳ����Ͷ�Ӧ����Ѿ������
% disp(['Best numTrees: ', num2str(best_params.numTrees)]);
% disp(['Best mTry: ', num2str(best_params.mTry)]);
% disp(['Best MSE: ', num2str(best_mse)]);

% �趨���ɭ�ֵĲ���
numTrees_APL = best_params.numTrees; % ��������
mTry_APL = best_params.mTry;       % ÿ�������ѡ��ı�������

save numTrees_APL numTrees_APL
save mTry_APL mTry_APL

%% �ҵ���ѵĲ���������ɭ��

clear
clc

load('numTrees_APL.mat')
load('mTry_APL.mat')
load('MCD19A3_NDVI_APL_2000_2020_filled.mat')
load('mask_greening_pixels.mat')

load('esacci_2000_2020.mat', 'esacci_BDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_BEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_CROP_2000_2020')
load('esacci_2000_2020.mat', 'esacci_GRASS_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_SHRUBS_2000_2020')

esacci_BDF = esacci_BDF_2000_2020 (:,:,2:20);
esacci_BEF = esacci_BEF_2000_2020 (:,:,2:20);
esacci_CRO = esacci_CROP_2000_2020 (:,:,2:20);
esacci_GRA = esacci_GRASS_2000_2020 (:,:,2:20);
esacci_NDF = esacci_NDF_2000_2020 (:,:,2:20);
esacci_NEF = esacci_NEF_2000_2020 (:,:,2:20);
esacci_SHR = esacci_SHRUBS_2000_2020 (:,:,2:20);

clear esacci_BDF_2000_2020 esacci_BDF_2000_2020
clear esacci_BEF_2000_2020 esacci_BEF_2000_2020
clear esacci_CROP_2000_2020 esacci_CROP_2000_2020
clear esacci_GRASS_2000_2020 esacci_GRASS_2000_2020
clear esacci_NDF_2000_2020 esacci_NDF_2000_2020
clear esacci_NEF_2000_2020 esacci_NEF_2000_2020
clear esacci_SHRUBS_2000_2020 esacci_SHRUBS_2000_2020

load('yearly_temperature_growing_2000_2020_filled.mat')
load('yearly_precipitation_growing_2000_2020_filled.mat')
load('yearly_co2_growing_2000_2020_filled.mat')

load('yearly_radiation_growing_2000_2020_filled.mat')
load('yearly_wind_speed_growing_2000_2020_filled.mat')
load('yearly_vpd_growing_2000_2020_filled.mat')

load('yearly_temperature_max_growing_2000_2020_filled.mat')
load('yearly_temperature_min_growing_2000_2020_filled.mat')

load('lat.mat')
load('lon.mat')

for i = 1:19
    mask_19years (:,:,i) = mask_greening_pixels;
    x_lat (:,:,i) = lat;
    x_lon (:,:,i) = lon;
end

mask = reshape (mask_19years,[347*720*19,1]);
y = reshape (MCD19A3_NDVI_APL_2000_2020_filled,[347*720*19,1]);
mask (isnan (y)) = nan;

x_tmp_growing = reshape (yearly_temperature_growing_2000_2020_filled,[347*720*19,1]);
x_pre_growing = reshape (yearly_precipitation_growing_2000_2020_filled,[347*720*19,1]);
x_co2_growing = reshape (yearly_co2_growing_2000_2020_filled,[347*720*19,1]);

x_rad_growing = reshape (yearly_radiation_growing_2000_2020_filled,[347*720*19,1]);
x_wsp_growing = reshape (yearly_wind_speed_growing_2000_2020_filled,[347*720*19,1]);
x_vpd_growing = reshape (yearly_vpd_growing_2000_2020_filled,[347*720*19,1]);

x_tmp_max_growing = reshape (yearly_temperature_max_growing_2000_2020_filled,[347*720*19,1]);
x_tmp_min_growing = reshape (yearly_temperature_min_growing_2000_2020_filled,[347*720*19,1]);

x_BDF = reshape (esacci_BDF,[347*720*19,1]);
x_BEF = reshape (esacci_BEF,[347*720*19,1]);
x_CRO = reshape (esacci_CRO,[347*720*19,1]);
x_GRA = reshape (esacci_GRA,[347*720*19,1]);
x_NDF = reshape (esacci_NDF,[347*720*19,1]);
x_NEF = reshape (esacci_NEF,[347*720*19,1]);
x_SHR = reshape (esacci_SHR,[347*720*19,1]);
% x_NON = 100 - (x_BDF + x_BEF + x_CRO + x_GRA + x_NDF + x_NEF + x_SHR);

x_lat = reshape (x_lat,[347*720*19,1]);
x_lon = reshape (x_lon,[347*720*19,1]);

% observable_phenology_position = find (mask (mask == 1));
% save observable_phenology_position observable_phenology_position

y (mask ~= 1) = [];

x_tmp_growing (mask ~= 1) = [];
x_pre_growing (mask ~= 1) = [];
x_co2_growing (mask ~= 1) = [];

x_rad_growing (mask ~= 1) = [];
x_wsp_growing (mask ~= 1) = [];
x_vpd_growing (mask ~= 1) = [];

x_tmp_max_growing (mask ~= 1) = [];
x_tmp_min_growing (mask ~= 1) = [];

x_BDF (mask ~= 1) = [];
x_BEF (mask ~= 1) = [];
x_CRO (mask ~= 1) = [];
x_GRA (mask ~= 1) = [];
x_NDF (mask ~= 1) = [];
x_NEF (mask ~= 1) = [];
% x_NON (mask ~= 1) = [];
x_SHR (mask ~= 1) = [];

x_lat (mask ~= 1) = [];
x_lon (mask ~= 1) = [];

clear MCD19A3_NDVI_APL_2000_2020_filled MCD19A3_NDVI_APL_2000_2020_filled

clear esacci_BDF esacci_BDF
clear esacci_BEF esacci_BEF
clear esacci_CRO esacci_CRO
clear esacci_GRA esacci_GRA
clear esacci_NDF esacci_NDF
clear esacci_NEF esacci_NEF
clear esacci_NON esacci_NON
clear esacci_SHR esacci_SHR

clear yearly_temperature_growing_2000_2020_filled yearly_temperature_growing_2000_2020_filled
clear yearly_precipitation_growing_2000_2020_filled yearly_precipitation_growing_2000_2020_filled
clear yearly_co2_growing_2000_2020_filled yearly_co2_growing_2000_2020_filled

clear yearly_radiation_growing_2000_2020_filled yearly_radiation_growing_2000_2020_filled
clear yearly_wind_speed_growing_2000_2020_filled yearly_wind_speed_growing_2000_2020_filled
clear yearly_vpd_growing_2000_2020_filled yearly_vpd_growing_2000_2020_filled

clear yearly_temperature_max_growing_2000_2020_filled yearly_temperature_max_growing_2000_2020_filled
clear yearly_temperature_min_growing_2000_2020_filled yearly_temperature_min_growing_2000_2020_filled

%% random forest
data_matrix_APL = [x_tmp_growing, x_tmp_max_growing, x_tmp_min_growing, x_pre_growing, x_co2_growing, x_rad_growing, x_vpd_growing, x_wsp_growing, x_BDF, x_BEF, x_CRO, x_GRA, x_NDF, x_NEF, x_SHR, x_lat, x_lon, y];
%% 80% trainging data
%% 20% validating data
rng(42);
n = size(data_matrix_APL, 1);
indices = randperm(n);
n_train = round (n * 0.8);

train_indices = indices(1:n_train);
validate_indices = indices(n_train+1:end);

data_matrix_APL_train = data_matrix_APL (train_indices,:);
data_matrix_APL_validate = data_matrix_APL (validate_indices,:);

% data_matrix_APL = data_matrix_APL (1:1000,:);

xx = data_matrix_APL_train (:, 1:end-1);
yy = data_matrix_APL_train (:, end);

% ��������Ǿ�����ʽ
rf_model_APL = TreeBagger(numTrees_APL, xx, yy, 'Method', 'regression', 'NumPredictorsToSample', mTry_APL);
% save rf_model_APL rf_model_APL

% �������ҪԤ���µĹ۲�ֵ������ʹ�� predict ����
% �������µĹ۲�ֵ inputX

%% y_predicted
inputX = data_matrix_APL_validate (:,1:17);
predicted_component_APL = predict(rf_model_APL, inputX);
observed_component_APL = data_matrix_APL_validate(:, end);
save predicted_component_APL predicted_component_APL
save observed_component_APL observed_component_APL

% %% y_others
% predicted_component_APL_others = observed_component_APL - predicted_component_APL;
% save predicted_component_APL_others predicted_component_APL_others

%% y_co2

clearvars -except rf_model_APL
clc

load('MCD19A3_NDVI_APL_2000_2020_filled.mat')
load('mask_greening_pixels.mat')

load('esacci_2000_2020.mat', 'esacci_BDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_BEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_CROP_2000_2020')
load('esacci_2000_2020.mat', 'esacci_GRASS_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_SHRUBS_2000_2020')

esacci_BDF = esacci_BDF_2000_2020 (:,:,2:20);
esacci_BEF = esacci_BEF_2000_2020 (:,:,2:20);
esacci_CRO = esacci_CROP_2000_2020 (:,:,2:20);
esacci_GRA = esacci_GRASS_2000_2020 (:,:,2:20);
esacci_NDF = esacci_NDF_2000_2020 (:,:,2:20);
esacci_NEF = esacci_NEF_2000_2020 (:,:,2:20);
esacci_SHR = esacci_SHRUBS_2000_2020 (:,:,2:20);

clear esacci_BDF_2000_2020 esacci_BDF_2000_2020
clear esacci_BEF_2000_2020 esacci_BEF_2000_2020
clear esacci_CROP_2000_2020 esacci_CROP_2000_2020
clear esacci_GRASS_2000_2020 esacci_GRASS_2000_2020
clear esacci_NDF_2000_2020 esacci_NDF_2000_2020
clear esacci_NEF_2000_2020 esacci_NEF_2000_2020
clear esacci_SHRUBS_2000_2020 esacci_SHRUBS_2000_2020

load('yearly_temperature_growing_2000_2020_filled.mat')
load('yearly_precipitation_growing_2000_2020_filled.mat')
load('yearly_co2_growing_2000_2020_filled.mat')

load('yearly_radiation_growing_2000_2020_filled.mat')
load('yearly_wind_speed_growing_2000_2020_filled.mat')
load('yearly_vpd_growing_2000_2020_filled.mat')

load('yearly_temperature_max_growing_2000_2020_filled.mat')
load('yearly_temperature_min_growing_2000_2020_filled.mat')

load('lat.mat')
load('lon.mat')

for i = 1:19
    mask_19years (:,:,i) = mask_greening_pixels;
    
    esacci_BDF (:,:,i) = esacci_BDF (:,:,1);
    esacci_BEF (:,:,i) = esacci_BEF (:,:,1);
    esacci_CRO (:,:,i) = esacci_CRO (:,:,1);
    esacci_GRA (:,:,i) = esacci_GRA (:,:,1);
    esacci_NDF (:,:,i) = esacci_NDF (:,:,1);
    esacci_NEF (:,:,i) = esacci_NEF (:,:,1);
    esacci_SHR (:,:,i) = esacci_SHR (:,:,1);
    
    yearly_temperature_growing_2000_2020_filled (:,:,i) = yearly_temperature_growing_2000_2020_filled (:,:,1);
    yearly_precipitation_growing_2000_2020_filled (:,:,i) = yearly_precipitation_growing_2000_2020_filled (:,:,1);
    yearly_radiation_growing_2000_2020_filled (:,:,i) = yearly_radiation_growing_2000_2020_filled (:,:,1);
    yearly_vpd_growing_2000_2020_filled (:,:,i) = yearly_vpd_growing_2000_2020_filled (:,:,1);
    yearly_wind_speed_growing_2000_2020_filled (:,:,i) = yearly_wind_speed_growing_2000_2020_filled (:,:,1);
    
    yearly_temperature_max_growing_2000_2020_filled (:,:,i) = yearly_temperature_max_growing_2000_2020_filled (:,:,1);
    yearly_temperature_min_growing_2000_2020_filled (:,:,i) = yearly_temperature_min_growing_2000_2020_filled (:,:,1);
    
    x_lat (:,:,i) = lat;
    x_lon (:,:,i) = lon;
end

mask = reshape (mask_19years,[347*720*19,1]);
y = reshape (MCD19A3_NDVI_APL_2000_2020_filled,[347*720*19,1]);
mask (isnan (y)) = nan;

x_tmp_growing = reshape (yearly_temperature_growing_2000_2020_filled,[347*720*19,1]);
x_pre_growing = reshape (yearly_precipitation_growing_2000_2020_filled,[347*720*19,1]);
x_co2_growing = reshape (yearly_co2_growing_2000_2020_filled,[347*720*19,1]);

x_rad_growing = reshape (yearly_radiation_growing_2000_2020_filled,[347*720*19,1]);
x_wsp_growing = reshape (yearly_wind_speed_growing_2000_2020_filled,[347*720*19,1]);
x_vpd_growing = reshape (yearly_vpd_growing_2000_2020_filled,[347*720*19,1]);

x_tmp_max_growing = reshape (yearly_temperature_max_growing_2000_2020_filled,[347*720*19,1]);
x_tmp_min_growing = reshape (yearly_temperature_min_growing_2000_2020_filled,[347*720*19,1]);

x_BDF = reshape (esacci_BDF,[347*720*19,1]);
x_BEF = reshape (esacci_BEF,[347*720*19,1]);
x_CRO = reshape (esacci_CRO,[347*720*19,1]);
x_GRA = reshape (esacci_GRA,[347*720*19,1]);
x_NDF = reshape (esacci_NDF,[347*720*19,1]);
x_NEF = reshape (esacci_NEF,[347*720*19,1]);
x_SHR = reshape (esacci_SHR,[347*720*19,1]);
% x_NON = 100 - (x_BDF + x_BEF + x_CRO + x_GRA + x_NDF + x_NEF + x_SHR);

x_lat = reshape (x_lat,[347*720*19,1]);
x_lon = reshape (x_lon,[347*720*19,1]);

% observable_phenology_position = find (mask (mask == 1));
% save observable_phenology_position observable_phenology_position

y (mask ~= 1) = [];

x_tmp_growing (mask ~= 1) = [];
x_pre_growing (mask ~= 1) = [];
x_co2_growing (mask ~= 1) = [];

x_rad_growing (mask ~= 1) = [];
x_wsp_growing (mask ~= 1) = [];
x_vpd_growing (mask ~= 1) = [];

x_tmp_max_growing (mask ~= 1) = [];
x_tmp_min_growing (mask ~= 1) = [];

x_BDF (mask ~= 1) = [];
x_BEF (mask ~= 1) = [];
x_CRO (mask ~= 1) = [];
x_GRA (mask ~= 1) = [];
x_NDF (mask ~= 1) = [];
x_NEF (mask ~= 1) = [];
% x_NON (mask ~= 1) = [];
x_SHR (mask ~= 1) = [];

x_lat (mask ~= 1) = [];
x_lon (mask ~= 1) = [];

clear MCD19A3_NDVI_APL_2000_2020_filled MCD19A3_NDVI_APL_2000_2020_filled

clear esacci_BDF esacci_BDF
clear esacci_BEF esacci_BEF
clear esacci_CRO esacci_CRO
clear esacci_GRA esacci_GRA
clear esacci_NDF esacci_NDF
clear esacci_NEF esacci_NEF
clear esacci_NON esacci_NON
clear esacci_SHR esacci_SHR

clear yearly_temperature_growing_2000_2020_filled yearly_temperature_growing_2000_2020_filled
clear yearly_precipitation_growing_2000_2020_filled yearly_precipitation_growing_2000_2020_filled
clear yearly_co2_growing_2000_2020_filled yearly_co2_growing_2000_2020_filled

clear yearly_radiation_growing_2000_2020_filled yearly_radiation_growing_2000_2020_filled
clear yearly_wind_speed_growing_2000_2020_filled yearly_wind_speed_growing_2000_2020_filled
clear yearly_vpd_growing_2000_2020_filled yearly_vpd_growing_2000_2020_filled

clear yearly_temperature_max_growing_2000_2020_filled yearly_temperature_max_growing_2000_2020_filled
clear yearly_temperature_min_growing_2000_2020_filled yearly_temperature_min_growing_2000_2020_filled

%% random forest
data_matrix_APL = [x_tmp_growing, x_tmp_max_growing, x_tmp_min_growing, x_pre_growing, x_co2_growing, x_rad_growing, x_vpd_growing, x_wsp_growing, x_BDF, x_BEF, x_CRO, x_GRA, x_NDF, x_NEF, x_SHR, x_lat, x_lon, y];
% data_matrix_APL = data_matrix_APL (1:1000,:);

load('observed_component_APL.mat')
inputX = data_matrix_APL (:,1:17);
predicted_component_APL_co2 = predict(rf_model_APL, inputX);
save predicted_component_APL_co2 predicted_component_APL_co2

%% y_cc

clearvars -except rf_model_APL
clc

load('MCD19A3_NDVI_APL_2000_2020_filled.mat')
load('mask_greening_pixels.mat')

load('esacci_2000_2020.mat', 'esacci_BDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_BEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_CROP_2000_2020')
load('esacci_2000_2020.mat', 'esacci_GRASS_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_SHRUBS_2000_2020')

esacci_BDF = esacci_BDF_2000_2020 (:,:,2:20);
esacci_BEF = esacci_BEF_2000_2020 (:,:,2:20);
esacci_CRO = esacci_CROP_2000_2020 (:,:,2:20);
esacci_GRA = esacci_GRASS_2000_2020 (:,:,2:20);
esacci_NDF = esacci_NDF_2000_2020 (:,:,2:20);
esacci_NEF = esacci_NEF_2000_2020 (:,:,2:20);
esacci_SHR = esacci_SHRUBS_2000_2020 (:,:,2:20);

clear esacci_BDF_2000_2020 esacci_BDF_2000_2020
clear esacci_BEF_2000_2020 esacci_BEF_2000_2020
clear esacci_CROP_2000_2020 esacci_CROP_2000_2020
clear esacci_GRASS_2000_2020 esacci_GRASS_2000_2020
clear esacci_NDF_2000_2020 esacci_NDF_2000_2020
clear esacci_NEF_2000_2020 esacci_NEF_2000_2020
clear esacci_SHRUBS_2000_2020 esacci_SHRUBS_2000_2020

load('yearly_temperature_growing_2000_2020_filled.mat')
load('yearly_precipitation_growing_2000_2020_filled.mat')
load('yearly_co2_growing_2000_2020_filled.mat')

load('yearly_radiation_growing_2000_2020_filled.mat')
load('yearly_wind_speed_growing_2000_2020_filled.mat')
load('yearly_vpd_growing_2000_2020_filled.mat')

load('yearly_temperature_max_growing_2000_2020_filled.mat')
load('yearly_temperature_min_growing_2000_2020_filled.mat')

load('lat.mat')
load('lon.mat')

for i = 1:19
    mask_19years (:,:,i) = mask_greening_pixels;
    
    esacci_BDF (:,:,i) = esacci_BDF (:,:,1);
    esacci_BEF (:,:,i) = esacci_BEF (:,:,1);
    esacci_CRO (:,:,i) = esacci_CRO (:,:,1);
    esacci_GRA (:,:,i) = esacci_GRA (:,:,1);
    esacci_NDF (:,:,i) = esacci_NDF (:,:,1);
    esacci_NEF (:,:,i) = esacci_NEF (:,:,1);
    esacci_SHR (:,:,i) = esacci_SHR (:,:,1);
    
    yearly_co2_growing_2000_2020_filled (:,:,i) = yearly_co2_growing_2000_2020_filled (:,:,1);
    
    x_lat (:,:,i) = lat;
    x_lon (:,:,i) = lon;
end

mask = reshape (mask_19years,[347*720*19,1]);
y = reshape (MCD19A3_NDVI_APL_2000_2020_filled,[347*720*19,1]);
mask (isnan (y)) = nan;

x_tmp_growing = reshape (yearly_temperature_growing_2000_2020_filled,[347*720*19,1]);
x_pre_growing = reshape (yearly_precipitation_growing_2000_2020_filled,[347*720*19,1]);
x_co2_growing = reshape (yearly_co2_growing_2000_2020_filled,[347*720*19,1]);

x_rad_growing = reshape (yearly_radiation_growing_2000_2020_filled,[347*720*19,1]);
x_wsp_growing = reshape (yearly_wind_speed_growing_2000_2020_filled,[347*720*19,1]);
x_vpd_growing = reshape (yearly_vpd_growing_2000_2020_filled,[347*720*19,1]);

x_tmp_max_growing = reshape (yearly_temperature_max_growing_2000_2020_filled,[347*720*19,1]);
x_tmp_min_growing = reshape (yearly_temperature_min_growing_2000_2020_filled,[347*720*19,1]);

x_BDF = reshape (esacci_BDF,[347*720*19,1]);
x_BEF = reshape (esacci_BEF,[347*720*19,1]);
x_CRO = reshape (esacci_CRO,[347*720*19,1]);
x_GRA = reshape (esacci_GRA,[347*720*19,1]);
x_NDF = reshape (esacci_NDF,[347*720*19,1]);
x_NEF = reshape (esacci_NEF,[347*720*19,1]);
x_SHR = reshape (esacci_SHR,[347*720*19,1]);
% x_NON = 100 - (x_BDF + x_BEF + x_CRO + x_GRA + x_NDF + x_NEF + x_SHR);

x_lat = reshape (x_lat,[347*720*19,1]);
x_lon = reshape (x_lon,[347*720*19,1]);

% observable_phenology_position = find (mask (mask == 1));
% save observable_phenology_position observable_phenology_position

y (mask ~= 1) = [];

x_tmp_growing (mask ~= 1) = [];
x_pre_growing (mask ~= 1) = [];
x_co2_growing (mask ~= 1) = [];

x_rad_growing (mask ~= 1) = [];
x_wsp_growing (mask ~= 1) = [];
x_vpd_growing (mask ~= 1) = [];

x_tmp_max_growing (mask ~= 1) = [];
x_tmp_min_growing (mask ~= 1) = [];

x_BDF (mask ~= 1) = [];
x_BEF (mask ~= 1) = [];
x_CRO (mask ~= 1) = [];
x_GRA (mask ~= 1) = [];
x_NDF (mask ~= 1) = [];
x_NEF (mask ~= 1) = [];
% x_NON (mask ~= 1) = [];
x_SHR (mask ~= 1) = [];

x_lat (mask ~= 1) = [];
x_lon (mask ~= 1) = [];

clear MCD19A3_NDVI_APL_2000_2020_filled MCD19A3_NDVI_APL_2000_2020_filled

clear esacci_BDF esacci_BDF
clear esacci_BEF esacci_BEF
clear esacci_CRO esacci_CRO
clear esacci_GRA esacci_GRA
clear esacci_NDF esacci_NDF
clear esacci_NEF esacci_NEF
clear esacci_NON esacci_NON
clear esacci_SHR esacci_SHR

clear yearly_temperature_growing_2000_2020_filled yearly_temperature_growing_2000_2020_filled
clear yearly_precipitation_growing_2000_2020_filled yearly_precipitation_growing_2000_2020_filled
clear yearly_co2_growing_2000_2020_filled yearly_co2_growing_2000_2020_filled

clear yearly_radiation_growing_2000_2020_filled yearly_radiation_growing_2000_2020_filled
clear yearly_wind_speed_growing_2000_2020_filled yearly_wind_speed_growing_2000_2020_filled
clear yearly_vpd_growing_2000_2020_filled yearly_vpd_growing_2000_2020_filled

clear yearly_temperature_max_growing_2000_2020_filled yearly_temperature_max_growing_2000_2020_filled
clear yearly_temperature_min_growing_2000_2020_filled yearly_temperature_min_growing_2000_2020_filled

%% random forest
data_matrix_APL = [x_tmp_growing, x_tmp_max_growing, x_tmp_min_growing, x_pre_growing, x_co2_growing, x_rad_growing, x_vpd_growing, x_wsp_growing, x_BDF, x_BEF, x_CRO, x_GRA, x_NDF, x_NEF, x_SHR, x_lat, x_lon, y];
% data_matrix_APL = data_matrix_APL (1:1000,:);

load('observed_component_APL.mat')
inputX = data_matrix_APL (:,1:17);
predicted_component_APL_cc = predict(rf_model_APL, inputX);
save predicted_component_APL_cc predicted_component_APL_cc

%% y_lcc

clearvars -except rf_model_APL
clc

load('MCD19A3_NDVI_APL_2000_2020_filled.mat')
load('mask_greening_pixels.mat')

load('esacci_2000_2020.mat', 'esacci_BDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_BEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_CROP_2000_2020')
load('esacci_2000_2020.mat', 'esacci_GRASS_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NDF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_NEF_2000_2020')
load('esacci_2000_2020.mat', 'esacci_SHRUBS_2000_2020')

esacci_BDF = esacci_BDF_2000_2020 (:,:,2:20);
esacci_BEF = esacci_BEF_2000_2020 (:,:,2:20);
esacci_CRO = esacci_CROP_2000_2020 (:,:,2:20);
esacci_GRA = esacci_GRASS_2000_2020 (:,:,2:20);
esacci_NDF = esacci_NDF_2000_2020 (:,:,2:20);
esacci_NEF = esacci_NEF_2000_2020 (:,:,2:20);
esacci_SHR = esacci_SHRUBS_2000_2020 (:,:,2:20);

clear esacci_BDF_2000_2020 esacci_BDF_2000_2020
clear esacci_BEF_2000_2020 esacci_BEF_2000_2020
clear esacci_CROP_2000_2020 esacci_CROP_2000_2020
clear esacci_GRASS_2000_2020 esacci_GRASS_2000_2020
clear esacci_NDF_2000_2020 esacci_NDF_2000_2020
clear esacci_NEF_2000_2020 esacci_NEF_2000_2020
clear esacci_SHRUBS_2000_2020 esacci_SHRUBS_2000_2020

load('yearly_temperature_growing_2000_2020_filled.mat')
load('yearly_precipitation_growing_2000_2020_filled.mat')
load('yearly_co2_growing_2000_2020_filled.mat')

load('yearly_radiation_growing_2000_2020_filled.mat')
load('yearly_wind_speed_growing_2000_2020_filled.mat')
load('yearly_vpd_growing_2000_2020_filled.mat')

load('yearly_temperature_max_growing_2000_2020_filled.mat')
load('yearly_temperature_min_growing_2000_2020_filled.mat')

load('lat.mat')
load('lon.mat')

for i = 1:19
    mask_19years (:,:,i) = mask_greening_pixels;
    
    yearly_temperature_growing_2000_2020_filled (:,:,i) = yearly_temperature_growing_2000_2020_filled (:,:,1);
    yearly_precipitation_growing_2000_2020_filled (:,:,i) = yearly_precipitation_growing_2000_2020_filled (:,:,1);
    yearly_co2_growing_2000_2020_filled (:,:,i) = yearly_co2_growing_2000_2020_filled (:,:,1);
    
    yearly_radiation_growing_2000_2020_filled (:,:,i) = yearly_radiation_growing_2000_2020_filled (:,:,1);
    yearly_vpd_growing_2000_2020_filled (:,:,i) = yearly_vpd_growing_2000_2020_filled (:,:,1);
    yearly_wind_speed_growing_2000_2020_filled (:,:,i) = yearly_wind_speed_growing_2000_2020_filled (:,:,1);
    
    yearly_temperature_max_growing_2000_2020_filled (:,:,i) = yearly_temperature_max_growing_2000_2020_filled (:,:,1);
    yearly_temperature_min_growing_2000_2020_filled (:,:,i) = yearly_temperature_min_growing_2000_2020_filled (:,:,1);
    
    x_lat (:,:,i) = lat;
    x_lon (:,:,i) = lon;
end

mask = reshape (mask_19years,[347*720*19,1]);
y = reshape (MCD19A3_NDVI_APL_2000_2020_filled,[347*720*19,1]);
mask (isnan (y)) = nan;

x_tmp_growing = reshape (yearly_temperature_growing_2000_2020_filled,[347*720*19,1]);
x_pre_growing = reshape (yearly_precipitation_growing_2000_2020_filled,[347*720*19,1]);
x_co2_growing = reshape (yearly_co2_growing_2000_2020_filled,[347*720*19,1]);

x_rad_growing = reshape (yearly_radiation_growing_2000_2020_filled,[347*720*19,1]);
x_wsp_growing = reshape (yearly_wind_speed_growing_2000_2020_filled,[347*720*19,1]);
x_vpd_growing = reshape (yearly_vpd_growing_2000_2020_filled,[347*720*19,1]);

x_tmp_max_growing = reshape (yearly_temperature_max_growing_2000_2020_filled,[347*720*19,1]);
x_tmp_min_growing = reshape (yearly_temperature_min_growing_2000_2020_filled,[347*720*19,1]);

x_BDF = reshape (esacci_BDF,[347*720*19,1]);
x_BEF = reshape (esacci_BEF,[347*720*19,1]);
x_CRO = reshape (esacci_CRO,[347*720*19,1]);
x_GRA = reshape (esacci_GRA,[347*720*19,1]);
x_NDF = reshape (esacci_NDF,[347*720*19,1]);
x_NEF = reshape (esacci_NEF,[347*720*19,1]);
x_SHR = reshape (esacci_SHR,[347*720*19,1]);
% x_NON = 100 - (x_BDF + x_BEF + x_CRO + x_GRA + x_NDF + x_NEF + x_SHR);

x_lat = reshape (x_lat,[347*720*19,1]);
x_lon = reshape (x_lon,[347*720*19,1]);

% observable_phenology_position = find (mask (mask == 1));
% save observable_phenology_position observable_phenology_position

y (mask ~= 1) = [];

x_tmp_growing (mask ~= 1) = [];
x_pre_growing (mask ~= 1) = [];
x_co2_growing (mask ~= 1) = [];

x_rad_growing (mask ~= 1) = [];
x_wsp_growing (mask ~= 1) = [];
x_vpd_growing (mask ~= 1) = [];

x_tmp_max_growing (mask ~= 1) = [];
x_tmp_min_growing (mask ~= 1) = [];

x_BDF (mask ~= 1) = [];
x_BEF (mask ~= 1) = [];
x_CRO (mask ~= 1) = [];
x_GRA (mask ~= 1) = [];
x_NDF (mask ~= 1) = [];
x_NEF (mask ~= 1) = [];
% x_NON (mask ~= 1) = [];
x_SHR (mask ~= 1) = [];

x_lat (mask ~= 1) = [];
x_lon (mask ~= 1) = [];

clear MCD19A3_NDVI_APL_2000_2020_filled MCD19A3_NDVI_APL_2000_2020_filled

clear esacci_BDF esacci_BDF
clear esacci_BEF esacci_BEF
clear esacci_CRO esacci_CRO
clear esacci_GRA esacci_GRA
clear esacci_NDF esacci_NDF
clear esacci_NEF esacci_NEF
clear esacci_NON esacci_NON
clear esacci_SHR esacci_SHR

clear yearly_temperature_growing_2000_2020_filled yearly_temperature_growing_2000_2020_filled
clear yearly_precipitation_growing_2000_2020_filled yearly_precipitation_growing_2000_2020_filled
clear yearly_co2_growing_2000_2020_filled yearly_co2_growing_2000_2020_filled

clear yearly_radiation_growing_2000_2020_filled yearly_radiation_growing_2000_2020_filled
clear yearly_wind_speed_growing_2000_2020_filled yearly_wind_speed_growing_2000_2020_filled
clear yearly_vpd_growing_2000_2020_filled yearly_vpd_growing_2000_2020_filled

clear yearly_temperature_max_growing_2000_2020_filled yearly_temperature_max_growing_2000_2020_filled
clear yearly_temperature_min_growing_2000_2020_filled yearly_temperature_min_growing_2000_2020_filled

%% random forest
data_matrix_APL = [x_tmp_growing, x_tmp_max_growing, x_tmp_min_growing, x_pre_growing, x_co2_growing, x_rad_growing, x_vpd_growing, x_wsp_growing, x_BDF, x_BEF, x_CRO, x_GRA, x_NDF, x_NEF, x_SHR, x_lat, x_lon, y];
% data_matrix_APL = data_matrix_APL (1:1000,:);

load('observed_component_APL.mat')
inputX = data_matrix_APL (:,1:17);
predicted_component_APL_lcc = predict(rf_model_APL, inputX);
save predicted_component_APL_lcc predicted_component_APL_lcc