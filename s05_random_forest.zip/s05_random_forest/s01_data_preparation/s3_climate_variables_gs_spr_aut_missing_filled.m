
clear
clc

load('yearly_temperature_growing_2000_2020.mat')
load('yearly_precipitation_growing_2000_2020.mat')
load('yearly_co2_growing_2000_2020.mat')

load('yearly_radiation_growing_2000_2020.mat')
load('yearly_vpd_growing_2000_2020.mat')
load('yearly_wind_speed_growing_2000_2020.mat')

load('yearly_temperature_max_growing_2000_2020.mat')
load('yearly_temperature_min_growing_2000_2020.mat')

load('mask_phenological_cycle.mat')

yearly_temperature_growing_2000_2020_filled = zeros (347,720,19);
yearly_precipitation_growing_2000_2020_filled = zeros (347,720,19);
yearly_co2_growing_2000_2020_filled = zeros (347,720,19);
yearly_radiation_growing_2000_2020_filled = zeros (347,720,19);
yearly_vpd_growing_2000_2020_filled = zeros (347,720,19);
yearly_wind_speed_growing_2000_2020_filled = zeros (347,720,19);
yearly_temperature_max_growing_2000_2020_filled = zeros (347,720,19);
yearly_temperature_min_growing_2000_2020_filled = zeros (347,720,19);

% fill missing values (e.g., NAN)
for i = 1:347
    for j = 1:720
        
        temperature_growing = yearly_temperature_growing_2000_2020 (i,j,:);
        temperature_growing = temperature_growing (1,:);
        tem_nan_length = length (temperature_growing (isnan (temperature_growing)));
        
        precipitation_growing = yearly_precipitation_growing_2000_2020 (i,j,:);
        precipitation_growing = precipitation_growing (1,:);
        pre_nan_length = length (precipitation_growing (isnan (precipitation_growing)));
        
        co2_growing = yearly_co2_growing_2000_2020 (i,j,:);
        co2_growing = co2_growing (1,:);
        co2_nan_length = length (co2_growing (isnan (co2_growing)));
        
        radiation_growing = yearly_radiation_growing_2000_2020 (i,j,:);
        radiation_growing = radiation_growing (1,:);
        rad_nan_length = length (radiation_growing (isnan (radiation_growing)));
        
        vpd_growing = yearly_vpd_growing_2000_2020 (i,j,:);
        vpd_growing = vpd_growing (1,:);
        vpd_nan_length = length (vpd_growing (isnan (vpd_growing)));
        
        wind_speed_growing = yearly_wind_speed_growing_2000_2020 (i,j,:);
        wind_speed_growing = wind_speed_growing (1,:);
        wsp_nan_length = length (wind_speed_growing (isnan (wind_speed_growing)));
        
        temperature_max_growing = yearly_temperature_max_growing_2000_2020 (i,j,:);
        temperature_max_growing = temperature_max_growing (1,:);
        tem_max_nan_length = length (temperature_max_growing (isnan (temperature_max_growing)));
        
        temperature_min_growing = yearly_temperature_min_growing_2000_2020 (i,j,:);
        temperature_min_growing = temperature_min_growing (1,:);
        tem_min_nan_length = length (temperature_min_growing (isnan (temperature_min_growing)));
        
        if tem_nan_length == 19 || pre_nan_length == 19 || co2_nan_length == 19 || rad_nan_length == 19 || vpd_nan_length == 19 || wsp_nan_length == 19 || tem_max_nan_length == 19 || tem_min_nan_length == 19
            
            yearly_temperature_growing_2000_2020_filled (i,j,:) = nan;
            yearly_precipitation_growing_2000_2020_filled (i,j,:) = nan;
            yearly_co2_growing_2000_2020_filled (i,j,:) = nan;
            yearly_radiation_growing_2000_2020_filled (i,j,:) = nan;
            yearly_vpd_growing_2000_2020_filled (i,j,:) = nan;
            yearly_wind_speed_growing_2000_2020_filled (i,j,:) = nan;
            yearly_temperature_max_growing_2000_2020_filled (i,j,:) = nan;
            yearly_temperature_min_growing_2000_2020_filled (i,j,:) = nan;
            mask_phenological_cycle_yearly_valid (i,j) = nan;
            
        else
            
            %             outlier_1 = nanmean (co2_growing) - 3*nanstd (co2_growing);
            %             outlier_2 = nanmean (co2_growing) + 3*nanstd (co2_growing);
            %
            %             co2_growing (co2_growing < outlier_1) = nan;
            %             co2_growing (co2_growing > outlier_2) = nan;
            
            yearly_temperature_growing_2000_2020_filled (i,j,:) = fillmissing(temperature_growing,'linear','EndValues','nearest');
            yearly_precipitation_growing_2000_2020_filled (i,j,:) = fillmissing(precipitation_growing,'linear','EndValues','nearest');
            yearly_co2_growing_2000_2020_filled (i,j,:) = fillmissing(co2_growing,'linear','EndValues','nearest');
            yearly_radiation_growing_2000_2020_filled (i,j,:) = fillmissing(radiation_growing,'linear','EndValues','nearest');
            yearly_vpd_growing_2000_2020_filled (i,j,:) = fillmissing(vpd_growing,'linear','EndValues','nearest');
            yearly_wind_speed_growing_2000_2020_filled (i,j,:) = fillmissing(wind_speed_growing,'linear','EndValues','nearest');
            yearly_temperature_max_growing_2000_2020_filled (i,j,:) = fillmissing(temperature_max_growing,'linear','EndValues','nearest');
            yearly_temperature_min_growing_2000_2020_filled (i,j,:) = fillmissing(temperature_min_growing,'linear','EndValues','nearest');
            mask_phenological_cycle_yearly_valid (i,j) = mask_phenological_cycle (i,j);
            
        end
    end
end

save yearly_temperature_growing_2000_2020_filled yearly_temperature_growing_2000_2020_filled
save yearly_precipitation_growing_2000_2020_filled yearly_precipitation_growing_2000_2020_filled
save yearly_co2_growing_2000_2020_filled yearly_co2_growing_2000_2020_filled
save yearly_wind_speed_growing_2000_2020_filled yearly_wind_speed_growing_2000_2020_filled
save yearly_vpd_growing_2000_2020_filled yearly_vpd_growing_2000_2020_filled
save yearly_radiation_growing_2000_2020_filled yearly_radiation_growing_2000_2020_filled
save yearly_temperature_max_growing_2000_2020_filled yearly_temperature_max_growing_2000_2020_filled
save yearly_temperature_min_growing_2000_2020_filled yearly_temperature_min_growing_2000_2020_filled
save mask_phenological_cycle_yearly_valid mask_phenological_cycle_yearly_valid