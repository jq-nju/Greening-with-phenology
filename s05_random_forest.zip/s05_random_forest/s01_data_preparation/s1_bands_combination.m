% clear
% clc
% 
% load('wind_speed_15days_1992.mat')
% load('wind_speed_15days_1993.mat')
% load('wind_speed_15days_1994.mat')
% load('wind_speed_15days_1995.mat')
% load('wind_speed_15days_1996.mat')
% load('wind_speed_15days_1997.mat')
% load('wind_speed_15days_1998.mat')
% load('wind_speed_15days_1999.mat')
% load('wind_speed_15days_2000.mat')
% load('wind_speed_15days_2001.mat')
% load('wind_speed_15days_2002.mat')
% load('wind_speed_15days_2003.mat')
% load('wind_speed_15days_2004.mat')
% load('wind_speed_15days_2005.mat')
% load('wind_speed_15days_2006.mat')
% load('wind_speed_15days_2007.mat')
% load('wind_speed_15days_2008.mat')
% load('wind_speed_15days_2009.mat')
% load('wind_speed_15days_2010.mat')
% load('wind_speed_15days_2011.mat')
% load('wind_speed_15days_2012.mat')
% load('wind_speed_15days_2013.mat')
% load('wind_speed_15days_2014.mat')
% load('wind_speed_15days_2015.mat')
% load('wind_speed_15days_2016.mat')
% load('wind_speed_15days_2017.mat')
% load('wind_speed_15days_2018.mat')
% load('wind_speed_15days_2019.mat')
% load('wind_speed_15days_2020.mat')
% 
% wind_speed_15days_1992_2020 = zeros (347,720,696);
% wind_speed_15days_1992_2020 (:,:,1:24)    = wind_speed_15days_1992;
% wind_speed_15days_1992_2020 (:,:,25:48)   = wind_speed_15days_1993;
% wind_speed_15days_1992_2020 (:,:,49:72)   = wind_speed_15days_1994;
% wind_speed_15days_1992_2020 (:,:,73:96)   = wind_speed_15days_1995;
% wind_speed_15days_1992_2020 (:,:,97:120)  = wind_speed_15days_1996;
% wind_speed_15days_1992_2020 (:,:,121:144) = wind_speed_15days_1997;
% wind_speed_15days_1992_2020 (:,:,145:168) = wind_speed_15days_1998;
% wind_speed_15days_1992_2020 (:,:,169:192) = wind_speed_15days_1999;
% wind_speed_15days_1992_2020 (:,:,193:216) = wind_speed_15days_2000;
% wind_speed_15days_1992_2020 (:,:,217:240) = wind_speed_15days_2001;
% wind_speed_15days_1992_2020 (:,:,241:264) = wind_speed_15days_2002;
% wind_speed_15days_1992_2020 (:,:,265:288) = wind_speed_15days_2003;
% wind_speed_15days_1992_2020 (:,:,289:312) = wind_speed_15days_2004;
% wind_speed_15days_1992_2020 (:,:,313:336) = wind_speed_15days_2005;
% wind_speed_15days_1992_2020 (:,:,337:360) = wind_speed_15days_2006;
% wind_speed_15days_1992_2020 (:,:,361:384) = wind_speed_15days_2007;
% wind_speed_15days_1992_2020 (:,:,385:408) = wind_speed_15days_2008;
% wind_speed_15days_1992_2020 (:,:,409:432) = wind_speed_15days_2009;
% wind_speed_15days_1992_2020 (:,:,433:456) = wind_speed_15days_2010;
% wind_speed_15days_1992_2020 (:,:,457:480) = wind_speed_15days_2011;
% wind_speed_15days_1992_2020 (:,:,481:504) = wind_speed_15days_2012;
% wind_speed_15days_1992_2020 (:,:,505:528) = wind_speed_15days_2013;
% wind_speed_15days_1992_2020 (:,:,529:552) = wind_speed_15days_2014;
% wind_speed_15days_1992_2020 (:,:,553:576) = wind_speed_15days_2015;
% wind_speed_15days_1992_2020 (:,:,577:600) = wind_speed_15days_2016;
% wind_speed_15days_1992_2020 (:,:,601:624) = wind_speed_15days_2017;
% wind_speed_15days_1992_2020 (:,:,625:648) = wind_speed_15days_2018;
% wind_speed_15days_1992_2020 (:,:,649:672) = wind_speed_15days_2019;
% wind_speed_15days_1992_2020 (:,:,673:696) = wind_speed_15days_2020;
% 
% save wind_speed_15days_1992_2020 wind_speed_15days_1992_2020



clear
clc

load('temperature_15days_1992_2020.mat')
load('precipitation_15days_1992_2020.mat')
load('co2_15days_1992_2020.mat')

load('radiation_15days_1992_2020.mat')
load('VPD_15days_1992_2020.mat')
load('wind_speed_15days_1992_2020.mat')

load('temperature_min_15days_1992_2020.mat')
load('temperature_max_15days_1992_2020.mat')

temperature_15days_2000_2020 = temperature_15days_1992_2020 (:,:,193:end);
precipitation_15days_2000_2020 = precipitation_15days_1992_2020 (:,:,193:end);
co2_15days_2000_2020 = co2_15days_1992_2020 (:,:,193:end);

radiation_15days_2000_2020 = radiation_15days_1992_2020 (:,:,193:end);
VPD_15days_2000_2020 = VPD_15days_1992_2020 (:,:,193:end);
wind_speed_15days_2000_2020 = wind_speed_15days_1992_2020 (:,:,193:end);

temperature_min_15days_2000_2020 = temperature_min_15days_1992_2020 (:,:,193:end);
temperature_max_15days_2000_2020 = temperature_max_15days_1992_2020 (:,:,193:end);

save temperature_15days_2000_2020 temperature_15days_2000_2020
save precipitation_15days_2000_2020 precipitation_15days_2000_2020
save co2_15days_2000_2020 co2_15days_2000_2020
save radiation_15days_2000_2020 radiation_15days_2000_2020
save VPD_15days_2000_2020 VPD_15days_2000_2020
save wind_speed_15days_2000_2020 wind_speed_15days_2000_2020
save temperature_min_15days_2000_2020 temperature_min_15days_2000_2020
save temperature_max_15days_2000_2020 temperature_max_15days_2000_2020