
clear
clc

load('MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled_sgfilter.mat')
load('MCD19A3_NDVI_PKD_reference.mat')

load('mask_phenological_cycle.mat')

load('temperature_15days_2000_2020.mat')
load('precipitation_15days_2000_2020.mat')
load('co2_15days_2000_2020.mat')

load('radiation_15days_2000_2020.mat')
load('wind_speed_15days_2000_2020.mat')
load('VPD_15days_2000_2020.mat')

load('temperature_max_15days_2000_2020.mat')
load('temperature_min_15days_2000_2020.mat')

% using a 3-year moving window to divide time-series data
DOY = 8:15:365;
DOY_3years = [DOY, DOY + 365, DOY + 2 * 365];
DOY_3years_daily = 1:1095;
moving_window = 1:24:433;

yearly_temperature_growing_2000_2020 = zeros (347,720,19);
yearly_precipitation_growing_2000_2020 = zeros (347,720,19);
yearly_co2_growing_2000_2020 = zeros (347,720,19);
yearly_radiation_growing_2000_2020 = zeros (347,720,19);
yearly_vpd_growing_2000_2020 = zeros (347,720,19);
yearly_wind_speed_growing_2000_2020 = zeros (347,720,19);
yearly_temperature_max_growing_2000_2020 = zeros (347,720,19);
yearly_temperature_min_growing_2000_2020 = zeros (347,720,19);

yearly_temperature_spring_2000_2020 = zeros (347,720,19);
yearly_precipitation_spring_2000_2020 = zeros (347,720,19);
yearly_co2_spring_2000_2020 = zeros (347,720,19);
yearly_radiation_spring_2000_2020 = zeros (347,720,19);
yearly_vpd_spring_2000_2020 = zeros (347,720,19);
yearly_wind_speed_spring_2000_2020 = zeros (347,720,19);
yearly_temperature_max_spring_2000_2020 = zeros (347,720,19);
yearly_temperature_min_spring_2000_2020 = zeros (347,720,19);

for N_year = 1:19
    window_num = moving_window (N_year);
    
    % i = 79; j = 610;
    parfor i = 1:347
        for j = 1:720
            
            mask = mask_phenological_cycle (i,j);
            
            if mask == 1 % extract by threshold
                
                pkd_vi_average = MCD19A3_NDVI_PKD_reference (i,j);
                pkd_vi_average = double (pkd_vi_average);
                
                vi = MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled_sgfilter (i,j,:);
                vi = vi (1,:);
                vi = double (vi);
                
                tmp = temperature_15days_2000_2020 (i,j,:);
                tmp = tmp (1,:);
                tmp = double (tmp);
                
                pre = precipitation_15days_2000_2020 (i,j,:);
                pre = pre (1,:);
                pre = double (pre);
                
                co2 = co2_15days_2000_2020 (i,j,:);
                co2 = co2 (1,:);
                co2 = double (co2);
                
                rad = radiation_15days_2000_2020 (i,j,:);
                rad = rad (1,:)/3600; % unit: s
                rad = double (rad);
                
                vpd = VPD_15days_2000_2020 (i,j,:);
                vpd = vpd (1,:);
                vpd = double (vpd);
                
                wsp = wind_speed_15days_2000_2020 (i,j,:);
                wsp = wsp (1,:);
                wsp = double (wsp);
                
                tmp_min = temperature_min_15days_2000_2020 (i,j,:);
                tmp_min = tmp_min (1,:);
                tmp_min = double (tmp_min);
                
                tmp_max = temperature_max_15days_2000_2020 (i,j,:);
                tmp_max = tmp_max (1,:);
                tmp_max = double (tmp_max);
                
                % phenology extraction
                vi_3years = vi (window_num : window_num + 71);
                
                tmp_3years = tmp (window_num : window_num + 71);
                pre_3years = pre (window_num : window_num + 71);
                co2_3years = co2 (window_num : window_num + 71);
                rad_3years = rad (window_num : window_num + 71);
                vpd_3years = vpd (window_num : window_num + 71);
                wsp_3years = wsp (window_num : window_num + 71);
                tmp_min_3years = tmp_min (window_num : window_num + 71);
                tmp_max_3years = tmp_max (window_num : window_num + 71);
                
                % daily interpolation
                vi_3years_daily = interp1 (DOY_3years,vi_3years,DOY_3years_daily,'spline');
                
                tmp_3years_daily = interp1 (DOY_3years,tmp_3years,DOY_3years_daily,'linear');
                pre_3years_daily = interp1 (DOY_3years,pre_3years,DOY_3years_daily,'linear');
                co2_3years_daily = interp1 (DOY_3years,co2_3years,DOY_3years_daily,'linear');
                rad_3years_daily = interp1 (DOY_3years,rad_3years,DOY_3years_daily,'linear');
                vpd_3years_daily = interp1 (DOY_3years,vpd_3years,DOY_3years_daily,'linear');
                wsp_3years_daily = interp1 (DOY_3years,wsp_3years,DOY_3years_daily,'linear');
                tmp_min_3years_daily = interp1 (DOY_3years,tmp_min_3years,DOY_3years_daily,'linear');
                tmp_max_3years_daily = interp1 (DOY_3years,tmp_max_3years,DOY_3years_daily,'linear');
                
                % find 3-cycle peaks
                % find peaks using function: "findpeaks" rather than find maximum
                
                cycle1 = vi_3years_daily (1 : 365);
                cycle2 = vi_3years_daily (366 : 730);
                cycle3 = vi_3years_daily (731 : end);
                
                % to avoid worng recognition, we used the steps below:
                % (1) using "peak date" derived from average 32-year NDVI as a reference
                % (2) defining a valid range of "peak date" (threshold: -60, +60)
                % (3) detecting "peak" and "maxmimum" at the same time
                % (4) and then, to select that one closest to the "peak date" reference
                
                t1 = pkd_vi_average - 60;
                t2 = pkd_vi_average + 60;
                
                if t1 < 1
                    t1 = 1;
                end
                
                if t2 > 365
                    t2 = 365;
                end
                
                % screening the values out of valid range
                cycle1 (1:t1)   = -999;
                cycle1 (t2:end) = -999;
                
                cycle2 (1:t1)   = -999;
                cycle2 (t2:end) = -999;
                
                cycle3 (1:t1)   = -999;
                cycle3 (t2:end) = -999;
                
                [valuePeak_1,positionPeak_1] = findpeaks (cycle1);
                [valueMax_1,positionMax_1]   = find (cycle1 == max (cycle1));
                if isempty (positionPeak_1) % no-peak
                    peak_cycle1 = pkd_vi_average;
                else
                    position_1  = [positionPeak_1,positionMax_1];
                    [~,Index]   = min (abs (position_1 - pkd_vi_average));
                    peak_cycle1 = position_1 (Index);
                end
                
                [valuePeak_2,positionPeak_2] = findpeaks (cycle2);
                [valueMax_2,positionMax_2]   = find (cycle2 == max (cycle2));
                if isempty (positionPeak_2) % no-peak
                    peak_cycle2 = pkd_vi_average + 365;
                else
                    position_2  = [positionPeak_2,positionMax_2];
                    [~,Index]   = min (abs (position_2 - pkd_vi_average));
                    peak_cycle2 = position_2 (Index) + 365;
                end
                
                [valuePeak_3,positionPeak_3] = findpeaks (cycle3);
                [valueMax_3,positionMax_3]   = find (cycle3 == max (cycle3));
                if isempty (positionPeak_3) % no-peak
                    peak_cycle3 = pkd_vi_average + 2 * 365;
                else
                    position_3  = [positionPeak_3,positionMax_3];
                    [~,Index]   = min (abs (position_3 - pkd_vi_average));
                    peak_cycle3 = position_3 (Index) + 2 * 365;
                end
                
                % find target-cycle (cycle2) bottoms
                left_cycle  = vi_3years_daily (peak_cycle1:peak_cycle2);
                right_cycle = vi_3years_daily (peak_cycle2:peak_cycle3);
                
                left_bottom  = find (left_cycle == min (left_cycle)) + peak_cycle1 - 1;
                left_bottom  = left_bottom (1);
                
                right_bottom = find (right_cycle == min (right_cycle)) + peak_cycle2 - 1;
                right_bottom = right_bottom (1);
                
                vi_used = vi_3years_daily (left_bottom:right_bottom);
                
                % extract phenological metrics
                % divide greening and senescence timeseries
                peak = find (vi_used == max (vi_used));
                peak = peak (1);
                
                vi_greening   = vi_used (1:peak);
                vi_senescence = vi_used (peak:end);
                
                % find max and min
                peak_value = max (vi_used);
                min_greening   = min (vi_greening);
                min_senescence = min (vi_senescence);
                
                % define SOS and EOS using threshold: 15%
                amp_greening   = peak_value - min_greening;
                amp_senescence = peak_value - min_senescence;
                
                vi_greening_ratio   = (vi_greening - min_greening)/amp_greening;
                vi_senescence_ratio = (vi_senescence - min_senescence)/amp_senescence;
                
                % values lower than 0: phenology oocurs in the previous year
                % values larger than 365: phenology oocurs in the next year
                
                sos = find (vi_greening_ratio >= 0.15);
                eos = find (vi_senescence_ratio >= 0.15);
                
                if ~isempty (sos) && ~isempty (eos)
                    
                    sos_vi_used = sos (1);
                    sos = sos (1) + left_bottom;
                    
                    eos_vi_used = eos (end) + peak - 1;
                    eos = eos (end) + peak - 1 + left_bottom;
                    
                    pos = peak_cycle2;
                    
                    tmp_growing = nanmean (tmp_3years_daily (sos:eos));
                    pre_growing = nanmean (pre_3years_daily (sos:eos));
                    co2_growing = nanmean (co2_3years_daily (sos:eos));
                    rad_growing = nanmean (rad_3years_daily (sos:eos));
                    vpd_growing = nanmean (vpd_3years_daily (sos:eos));
                    wsp_growing = nanmean (wsp_3years_daily (sos:eos));
                    tmp_min_growing = nanmean (tmp_min_3years_daily (sos:eos));
                    tmp_max_growing = nanmean (tmp_max_3years_daily (sos:eos));
                    
                    tmp_spring = nanmean (tmp_3years_daily (left_bottom:pos));
                    pre_spring = nanmean (pre_3years_daily (left_bottom:pos));
                    co2_spring = nanmean (co2_3years_daily (left_bottom:pos));
                    rad_spring = nanmean (rad_3years_daily (left_bottom:pos));
                    vpd_spring = nanmean (vpd_3years_daily (left_bottom:pos));
                    wsp_spring = nanmean (wsp_3years_daily (left_bottom:pos));
                    tmp_min_spring = nanmean (tmp_min_3years_daily (left_bottom:pos));
                    tmp_max_spring = nanmean (tmp_max_3years_daily (left_bottom:pos));
                    
                    yearly_temperature_growing_2000_2020 (i,j,N_year) = tmp_growing;
                    yearly_precipitation_growing_2000_2020 (i,j,N_year) = pre_growing;
                    yearly_co2_growing_2000_2020 (i,j,N_year) = co2_growing;
                    yearly_radiation_growing_2000_2020 (i,j,N_year) = rad_growing;
                    yearly_vpd_growing_2000_2020 (i,j,N_year) = vpd_growing;
                    yearly_wind_speed_growing_2000_2020 (i,j,N_year) = wsp_growing;
                    yearly_temperature_min_growing_2000_2020 (i,j,N_year) = tmp_min_growing;
                    yearly_temperature_max_growing_2000_2020 (i,j,N_year) = tmp_max_growing;
                    
                    yearly_temperature_spring_2000_2020 (i,j,N_year) = tmp_spring;
                    yearly_precipitation_spring_2000_2020 (i,j,N_year) = pre_spring;
                    yearly_co2_spring_2000_2020 (i,j,N_year) = co2_spring;
                    yearly_radiation_spring_2000_2020 (i,j,N_year) = rad_spring;
                    yearly_vpd_spring_2000_2020 (i,j,N_year) = vpd_spring;
                    yearly_wind_speed_spring_2000_2020 (i,j,N_year) = wsp_spring;
                    yearly_temperature_min_spring_2000_2020 (i,j,N_year) = tmp_min_spring;
                    yearly_temperature_max_spring_2000_2020 (i,j,N_year) = tmp_max_spring;
                    
                else
                    
                    yearly_temperature_growing_2000_2020 (i,j,N_year) = nan;
                    yearly_precipitation_growing_2000_2020 (i,j,N_year) = nan;
                    yearly_co2_growing_2000_2020 (i,j,N_year) = nan;
                    yearly_radiation_growing_2000_2020 (i,j,N_year) = nan;
                    yearly_vpd_growing_2000_2020 (i,j,N_year) = nan;
                    yearly_wind_speed_growing_2000_2020 (i,j,N_year) = nan;
                    yearly_temperature_min_growing_2000_2020 (i,j,N_year) = nan;
                    yearly_temperature_max_growing_2000_2020 (i,j,N_year) = nan;
                    
                    yearly_temperature_spring_2000_2020 (i,j,N_year) = nan;
                    yearly_precipitation_spring_2000_2020 (i,j,N_year) = nan;
                    yearly_co2_spring_2000_2020 (i,j,N_year) = nan;
                    yearly_radiation_spring_2000_2020 (i,j,N_year) = nan;
                    yearly_vpd_spring_2000_2020 (i,j,N_year) = nan;
                    yearly_wind_speed_spring_2000_2020 (i,j,N_year) = nan;
                    yearly_temperature_min_spring_2000_2020 (i,j,N_year) = nan;
                    yearly_temperature_max_spring_2000_2020 (i,j,N_year) = nan;
                    
                end
                
            else
                
                yearly_temperature_growing_2000_2020 (i,j,N_year) = nan;
                yearly_precipitation_growing_2000_2020 (i,j,N_year) = nan;
                yearly_co2_growing_2000_2020 (i,j,N_year) = nan;
                yearly_radiation_growing_2000_2020 (i,j,N_year) = nan;
                yearly_vpd_growing_2000_2020 (i,j,N_year) = nan;
                yearly_wind_speed_growing_2000_2020 (i,j,N_year) = nan;
                yearly_temperature_min_growing_2000_2020 (i,j,N_year) = nan;
                yearly_temperature_max_growing_2000_2020 (i,j,N_year) = nan;
                
                yearly_temperature_spring_2000_2020 (i,j,N_year) = nan;
                yearly_precipitation_spring_2000_2020 (i,j,N_year) = nan;
                yearly_co2_spring_2000_2020 (i,j,N_year) = nan;
                yearly_radiation_spring_2000_2020 (i,j,N_year) = nan;
                yearly_vpd_spring_2000_2020 (i,j,N_year) = nan;
                yearly_wind_speed_spring_2000_2020 (i,j,N_year) = nan;
                yearly_temperature_min_spring_2000_2020 (i,j,N_year) = nan;
                yearly_temperature_max_spring_2000_2020 (i,j,N_year) = nan;
                
            end
        end
    end
    
    disp(N_year)
    
end

save yearly_temperature_growing_2000_2020 yearly_temperature_growing_2000_2020
save yearly_precipitation_growing_2000_2020 yearly_precipitation_growing_2000_2020
save yearly_co2_growing_2000_2020 yearly_co2_growing_2000_2020
save yearly_radiation_growing_2000_2020 yearly_radiation_growing_2000_2020
save yearly_vpd_growing_2000_2020 yearly_vpd_growing_2000_2020
save yearly_wind_speed_growing_2000_2020 yearly_wind_speed_growing_2000_2020
save yearly_temperature_min_growing_2000_2020 yearly_temperature_min_growing_2000_2020
save yearly_temperature_max_growing_2000_2020 yearly_temperature_max_growing_2000_2020

save yearly_temperature_spring_2000_2020 yearly_temperature_spring_2000_2020
save yearly_precipitation_spring_2000_2020 yearly_precipitation_spring_2000_2020
save yearly_co2_spring_2000_2020 yearly_co2_spring_2000_2020
save yearly_radiation_spring_2000_2020 yearly_radiation_spring_2000_2020
save yearly_vpd_spring_2000_2020 yearly_vpd_spring_2000_2020
save yearly_wind_speed_spring_2000_2020 yearly_wind_speed_spring_2000_2020
save yearly_temperature_min_spring_2000_2020 yearly_temperature_min_spring_2000_2020
save yearly_temperature_max_spring_2000_2020 yearly_temperature_max_spring_2000_2020