%% snow pixels filled by 5th percentile

clear
clc

load('MCD19A3_NDVI_05degree_15days_2000_2020.mat')
load('Freeze_Thaw_2000_2020_05degree.mat')

MCD19A3_NDVI_05degree_15days_2000_2020 = MCD19A3_NDVI_05degree_15days_2000_2020 (7:353,:,:);
MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled = zeros (347,720,504);
Freeze_Thaw_mask = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        % i = 120; j = 582;
        ndvi = MCD19A3_NDVI_05degree_15days_2000_2020 (i,j,:);
        ndvi = ndvi (1,:);
        
        ndvi (ndvi < 0) = nan;
        ndvi (isnan (ndvi)) = 0;
        
        nan_length = length (ndvi (ndvi == 0));
        
        if nan_length == 504 % background pixels
            
            MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled (i,j,:) = 0;
            
        else
            
            %             ft_01 = Freeze_Thaw_1982_05degree (i,j,:); ft_01 = ft_01 (1,8:15:365);
            %             ft_02 = Freeze_Thaw_1983_05degree (i,j,:); ft_02 = ft_02 (1,8:15:365);
            %             ft_03 = Freeze_Thaw_1984_05degree (i,j,:); ft_03 = ft_03 (1,8:15:365);
            %             ft_04 = Freeze_Thaw_1985_05degree (i,j,:); ft_04 = ft_04 (1,8:15:365);
            %             ft_05 = Freeze_Thaw_1986_05degree (i,j,:); ft_05 = ft_05 (1,8:15:365);
            %             ft_06 = Freeze_Thaw_1987_05degree (i,j,:); ft_06 = ft_06 (1,8:15:365);
            %             ft_07 = Freeze_Thaw_1988_05degree (i,j,:); ft_07 = ft_07 (1,8:15:365);
            %             ft_08 = Freeze_Thaw_1989_05degree (i,j,:); ft_08 = ft_08 (1,8:15:365);
            %             ft_09 = Freeze_Thaw_1990_05degree (i,j,:); ft_09 = ft_09 (1,8:15:365);
            %             ft_10 = Freeze_Thaw_1991_05degree (i,j,:); ft_10 = ft_10 (1,8:15:365);
            %             ft_11 = Freeze_Thaw_1992_05degree (i,j,:); ft_11 = ft_11 (1,8:15:365);
            %             ft_12 = Freeze_Thaw_1993_05degree (i,j,:); ft_12 = ft_12 (1,8:15:365);
            %             ft_13 = Freeze_Thaw_1994_05degree (i,j,:); ft_13 = ft_13 (1,8:15:365);
            %             ft_14 = Freeze_Thaw_1995_05degree (i,j,:); ft_14 = ft_14 (1,8:15:365);
            %             ft_15 = Freeze_Thaw_1996_05degree (i,j,:); ft_15 = ft_15 (1,8:15:365);
            %             ft_16 = Freeze_Thaw_1997_05degree (i,j,:); ft_16 = ft_16 (1,8:15:365);
            %             ft_17 = Freeze_Thaw_1998_05degree (i,j,:); ft_17 = ft_17 (1,8:15:365);
            %             ft_18 = Freeze_Thaw_1999_05degree (i,j,:); ft_18 = ft_18 (1,8:15:365);
            ft_19 = Freeze_Thaw_2000_05degree (i,j,:); ft_19 = ft_19 (1,8:15:365);
            ft_20 = Freeze_Thaw_2001_05degree (i,j,:); ft_20 = ft_20 (1,8:15:365);
            ft_21 = Freeze_Thaw_2002_05degree (i,j,:); ft_21 = ft_21 (1,8:15:365);
            ft_22 = Freeze_Thaw_2003_05degree (i,j,:); ft_22 = ft_22 (1,8:15:365);
            ft_23 = Freeze_Thaw_2004_05degree (i,j,:); ft_23 = ft_23 (1,8:15:365);
            ft_24 = Freeze_Thaw_2005_05degree (i,j,:); ft_24 = ft_24 (1,8:15:365);
            ft_25 = Freeze_Thaw_2006_05degree (i,j,:); ft_25 = ft_25 (1,8:15:365);
            ft_26 = Freeze_Thaw_2007_05degree (i,j,:); ft_26 = ft_26 (1,8:15:365);
            ft_27 = Freeze_Thaw_2008_05degree (i,j,:); ft_27 = ft_27 (1,8:15:365);
            ft_28 = Freeze_Thaw_2009_05degree (i,j,:); ft_28 = ft_28 (1,8:15:365);
            ft_29 = Freeze_Thaw_2010_05degree (i,j,:); ft_29 = ft_29 (1,8:15:365);
            ft_30 = Freeze_Thaw_2011_05degree (i,j,:); ft_30 = ft_30 (1,8:15:365);
            ft_31 = Freeze_Thaw_2012_05degree (i,j,:); ft_31 = ft_31 (1,8:15:365);
            ft_32 = Freeze_Thaw_2013_05degree (i,j,:); ft_32 = ft_32 (1,8:15:365);
            ft_33 = Freeze_Thaw_2014_05degree (i,j,:); ft_33 = ft_33 (1,8:15:365);
            ft_34 = Freeze_Thaw_2015_05degree (i,j,:); ft_34 = ft_34 (1,8:15:365);
            ft_35 = Freeze_Thaw_2016_05degree (i,j,:); ft_35 = ft_35 (1,8:15:365);
            ft_36 = Freeze_Thaw_2017_05degree (i,j,:); ft_36 = ft_36 (1,8:15:365);
            ft_37 = Freeze_Thaw_2018_05degree (i,j,:); ft_37 = ft_37 (1,8:15:365);
            ft_38 = Freeze_Thaw_2019_05degree (i,j,:); ft_38 = ft_38 (1,8:15:365);
            ft_39 = Freeze_Thaw_2020_05degree (i,j,:); ft_39 = ft_39 (1,8:15:365);
            
            ft = [ft_19,ft_20,ft_21,ft_22,ft_23,ft_24,ft_25,ft_26,ft_27,ft_28,ft_29,ft_30,ft_31,ft_32,ft_33,ft_34,ft_35,ft_36,ft_37,ft_38,ft_39];
            ft = single (ft);
            
            % generate a freeze-thaw mask
            ft_length = length (ft (ft == 253));
            if ft_length == 504 % no freeze
                Freeze_Thaw_mask (i,j) = 1;
            else
                Freeze_Thaw_mask (i,j) = 0;
            end
            
            ndvi (ft == 0) = nan; % Frozen (AM and PM frozen)
            ndvi (ft == 2) = nan; % Transitional (AM frozen, PM thawed)
            ndvi (ft == 3) = nan; % Inverse Transitional (AM thawed, PM frozen)
            
            data = ndvi;
            data (isnan (data)) = [];
            
            ndvi_background = prctile(data,5);
            ndvi (isnan (ndvi)) = ndvi_background;
            
            ndvi (ndvi < ndvi_background) = ndvi_background;
            
            MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled (i,j,:) = ndvi;
        end
    end
end

MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled = single (MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled);
save MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled
save Freeze_Thaw_mask Freeze_Thaw_mask

% convert .mat into tiff files
filepath = 'D:\decompose LAI\s03_MCD19A3_NDVI_snow_filled\geoinfo_05degree_resize.tif';
[Data, R] = geotiffread(filepath);
info = geotiffinfo(filepath);
geotiffwrite('MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled', MCD19A3_NDVI_05degree_15days_2000_2020_snowfilled, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);