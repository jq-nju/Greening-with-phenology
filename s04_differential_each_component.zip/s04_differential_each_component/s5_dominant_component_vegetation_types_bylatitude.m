clear
clc

load('dominant_type_2020.mat')
load('greening_dominant_component_2001_2019.mat')
load('browning_dominant_component_2001_2019.mat')

dominant_type_2020 (dominant_type_2020 == 2)  = 1; % BDF
dominant_type_2020 (dominant_type_2020 == 3)  = 1; % BEF
dominant_type_2020 (dominant_type_2020 == 7)  = 1; % NDF
dominant_type_2020 (dominant_type_2020 == 8)  = 1; % NEF

dominant_type_2020 (dominant_type_2020 == 5)  = 2; % CROPS
dominant_type_2020 (dominant_type_2020 == 6)  = 2; % GRASS
dominant_type_2020 (dominant_type_2020 == 10) = 2; % SHRUBS

dominant_type_2020 (dominant_type_2020 ~= 1 & dominant_type_2020 ~= 2) = nan;

%% for greening pixels
for i = 1:347
    
    type = dominant_type_2020 (i,:);
    factor = greening_dominant_component_2001_2019 (i,:);
    
    %% ALPHA
    condition = (type == 1) & (factor == 1);
    ALPHA_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 1);
    ALPHA_nonforest (i) = sum(condition);
    
    %% BETA
    condition = (type == 1) & (factor == 2);
    BETA_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 2);
    BETA_nonforest (i) = sum(condition);
    
    %% AMP
    condition = (type == 1) & (factor == 3);
    AMP_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 3);
    AMP_nonforest (i) = sum(condition);
    
    %% SPL
    condition = (type == 1) & (factor == 4);
    SPL_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 4);
    SPL_nonforest (i) = sum(condition);
    
    %% APL
    condition = (type == 1) & (factor == 5);
    APL_forest (i) = sum(condition);
    
    condition = (type == 2) & (factor == 5);
    APL_nonforest (i) = sum(condition);

end

% subplot (1,3,3)
% number = [ALPHA_greening;BETA_greening;AMP_greening;SPL_greening;APL_greening];
% bar(number,'stacked')

subplot (1,2,1)
plot(ALPHA_forest,'LineWidth', 3)
hold on
plot(BETA_forest,'LineWidth', 3)
hold on
plot(AMP_forest,'LineWidth', 3)
hold on
plot(SPL_forest,'LineWidth', 3)
hold on
plot(APL_forest,'LineWidth', 3)

subplot (1,2,2)
plot(ALPHA_nonforest,'LineWidth', 3)
hold on
plot(BETA_nonforest,'LineWidth', 3)
hold on
plot(AMP_nonforest,'LineWidth', 3)
hold on
plot(SPL_nonforest,'LineWidth', 3)
hold on
plot(APL_nonforest,'LineWidth', 3)

% %% for browning pixels
% for i = 1:347
%     
%     type = dominant_type_2020 (i,:);
%     factor = browning_dominant_component_2001_2019 (i,:);
%     
%     %% ALPHA
%     condition = (type == 1) & (factor == 1);
%     ALPHA_forest (i) = sum(condition);
%     
%     condition = (type == 2) & (factor == 1);
%     ALPHA_nonforest (i) = sum(condition);
%     
%     %% BETA
%     condition = (type == 1) & (factor == 2);
%     BETA_forest (i) = sum(condition);
%     
%     condition = (type == 2) & (factor == 2);
%     BETA_nonforest (i) = sum(condition);
%     
%     %% AMP
%     condition = (type == 1) & (factor == 3);
%     AMP_forest (i) = sum(condition);
%     
%     condition = (type == 2) & (factor == 3);
%     AMP_nonforest (i) = sum(condition);
%     
%     %% SPL
%     condition = (type == 1) & (factor == 4);
%     SPL_forest (i) = sum(condition);
%     
%     condition = (type == 2) & (factor == 4);
%     SPL_nonforest (i) = sum(condition);
%     
%     %% APL
%     condition = (type == 1) & (factor == 5);
%     APL_forest (i) = sum(condition);
%     
%     condition = (type == 2) & (factor == 5);
%     APL_nonforest (i) = sum(condition);
% 
% end
% 
% % subplot (1,3,3)
% % number = [ALPHA_browning;BETA_browning;AMP_browning;SPL_browning;APL_browning];
% % bar(number,'stacked')
% 
% subplot (1,2,1)
% plot(ALPHA_forest,'LineWidth', 3)
% hold on
% plot(BETA_forest,'LineWidth', 3)
% hold on
% plot(AMP_forest,'LineWidth', 3)
% hold on
% plot(SPL_forest,'LineWidth', 3)
% hold on
% plot(APL_forest,'LineWidth', 3)
% 
% subplot (1,2,2)
% plot(ALPHA_nonforest,'LineWidth', 3)
% hold on
% plot(BETA_nonforest,'LineWidth', 3)
% hold on
% plot(AMP_nonforest,'LineWidth', 3)
% hold on
% plot(SPL_nonforest,'LineWidth', 3)
% hold on
% plot(APL_nonforest,'LineWidth', 3)