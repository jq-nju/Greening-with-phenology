
clear
clc

load('mask_phenological_cycle.mat')
load('dNDVIgs.mat')

years = 1:19;

%% NDVIgs slope
NDVIgs_fitted_2000_2020 = zeros (347,720,19);

parfor i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        NDVIgs = dNDVIgs (i,j,:);
        NDVIgs = NDVIgs (1,:);
        
        valid_length = length (NDVIgs (~isnan (NDVIgs)));
        
        if ~isnan (mask) && valid_length == 19
            
            significance_alpha = 0.05; % significance level: 95%
            wantplot = 0;    % do not plot
            
            datain = [years;NDVIgs];
            datain = datain';
            [h, sig, sen, slope] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            NDVIgs_slope_2000_2020  (i,j) = sen;
            NDVIgs_sig_2000_2020  (i,j) = sig;
            NDVIgs_fitted_2000_2020  (i,j,:) = slope;
            
        else
            
            NDVIgs_slope_2000_2020  (i,j) = nan;
            NDVIgs_sig_2000_2020  (i,j) = nan;
            NDVIgs_fitted_2000_2020  (i,j,:) = nan;
            
        end
    end
end

%% differential_components slope

load('differential_component_ALPHA.mat')
load('differential_component_BETA.mat')
load('differential_component_AMP.mat')
load('differential_component_SPL.mat')
load('differential_component_APL.mat')

parfor i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        
        ALPHA = differential_component_ALPHA (i,j,:);
        BETA  = differential_component_BETA (i,j,:);
        AMP   = differential_component_AMP (i,j,:);
        SPL   = differential_component_SPL (i,j,:);
        APL   = differential_component_APL (i,j,:);
        
        ALPHA = ALPHA (1,:);
        BETA  = BETA (1,:);
        AMP   = AMP (1,:);
        SPL   = SPL (1,:);
        APL   = APL (1,:);
        
        nan_ALPHA = length (ALPHA (~isnan (ALPHA)));
        nan_BETA  = length (BETA (~isnan (BETA)));
        nan_AMP   = length (AMP (~isnan (AMP)));
        nan_SPL   = length (SPL (~isnan (SPL)));
        nan_APL   = length (APL (~isnan (APL)));
        
        significance_alpha = 0.05; % significance level: 95%
        wantplot = 0;    % do not plot
        
        if mask == 1 && nan_ALPHA == 19 && nan_BETA == 19 && nan_AMP == 19 && nan_SPL == 19 && nan_APL == 19
            
            % ALPHA
            datain = [years;ALPHA];
            datain = datain';
            [h, sig, sen, slope] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            ALPHA_slope_2000_2020  (i,j) = sen;
            ALPHA_sig_2000_2020  (i,j) = sig;
            
            % BETA
            datain = [years;BETA];
            datain = datain';
            [h, sig, sen, slope] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            BETA_slope_2000_2020  (i,j) = sen;
            BETA_sig_2000_2020  (i,j) = sig;
            
            % AMP
            datain = [years;AMP];
            datain = datain';
            [h, sig, sen, slope] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            AMP_slope_2000_2020  (i,j) = sen;
            AMP_sig_2000_2020  (i,j) = sig;
            
            % SPL
            datain = [years;SPL];
            datain = datain';
            [h, sig, sen, slope] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            SPL_slope_2000_2020  (i,j) = sen;
            SPL_sig_2000_2020  (i,j) = sig;
            
            % APL
            datain = [years;APL];
            datain = datain';
            [h, sig, sen, slope] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            APL_slope_2000_2020  (i,j) = sen;
            APL_sig_2000_2020  (i,j) = sig;
            
        else
            
            ALPHA_slope_2000_2020  (i,j) = nan;
            ALPHA_sig_2000_2020  (i,j) = nan;
            
            BETA_slope_2000_2020  (i,j) = nan;
            BETA_sig_2000_2020  (i,j) = nan;
            
            AMP_slope_2000_2020  (i,j) = nan;
            AMP_sig_2000_2020  (i,j) = nan;
            
            SPL_slope_2000_2020  (i,j) = nan;
            SPL_sig_2000_2020  (i,j) = nan;
            
            APL_slope_2000_2020  (i,j) = nan;
            APL_sig_2000_2020  (i,j) = nan;
            
        end
    end
end

%% violin plot
subplot (1,3,1)
% load('slope_MK_2000_2020.mat')
ALPHA = reshape (ALPHA_slope_2000_2020, [1,347*720]);
BETA  = reshape (BETA_slope_2000_2020, [1,347*720]);
AMP   = reshape (AMP_slope_2000_2020, [1,347*720]);
SPL   = reshape (SPL_slope_2000_2020, [1,347*720]);
APL   = reshape (APL_slope_2000_2020, [1,347*720]);
NDVIgs = reshape (NDVIgs_slope_2000_2020, [1,347*720]);

data = [NDVIgs;ALPHA;BETA;AMP;SPL;APL];
data = data';
violin(data);
hold on
plot ([0 7],[0 0])
hold on
h = boxplot(data,'symbol', '');
set(h,'LineWidth',1.1);

% subplot (1,2,2)
% % load('slope_MK_2000_2020.mat')
% ALPHA_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;
% BETA_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;
% AMP_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;
% SPL_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;
% APL_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;
% 
% ALPHA = reshape (ALPHA_slope_2000_2020, [1,347*720]);
% BETA  = reshape (BETA_slope_2000_2020, [1,347*720]);
% AMP   = reshape (AMP_slope_2000_2020, [1,347*720]);
% SPL   = reshape (SPL_slope_2000_2020, [1,347*720]);
% APL   = reshape (APL_slope_2000_2020, [1,347*720]);
% NDVIgs = reshape (NDVIgs_slope_2000_2020, [1,347*720]);
% 
% data = [NDVIgs;ALPHA;BETA;AMP;SPL;APL];
% data = data';
% violin(data);
% hold on
% plot ([0 7],[0 0])
% hold on
% h = boxplot(data,'symbol', '');
% set(h,'LineWidth',1.1);

% h1 = histogram(ALPHA_slope_2000_2020);
% hold on
% h2 = histogram(BETA_slope_2000_2020);
% hold on
% h3 = histogram(AMP_slope_2000_2020);
% hold on
% h4 = histogram(SPL_slope_2000_2020);
% hold on
% h5 = histogram(APL_slope_2000_2020);
% hold on
% h6 = histogram(NDVIgs_slope_2000_2020);
% 
% h1.Normalization = 'probability';
% h1.BinWidth = 0.03;
% h2.Normalization = 'probability';
% h2.BinWidth = 0.03;
% h3.Normalization = 'probability';
% h3.BinWidth = 0.03;
% h4.Normalization = 'probability';
% h4.BinWidth = 0.03;
% h5.Normalization = 'probability';
% h5.BinWidth = 0.03;
% h6.Normalization = 'probability';
% h6.BinWidth = 0.03;

% global_mean (1) = nanmean (ALPHA_slope_2000_2020 (:));
% global_mean (2) = nanmean (BETA_slope_2000_2020 (:));
% global_mean (3) = nanmean (AMP_slope_2000_2020 (:));
% global_mean (4) = nanmean (SPL_slope_2000_2020 (:));
% global_mean (5) = nanmean (APL_slope_2000_2020 (:));
% global_mean (6) = nanmean (NDVIgs_slope_2000_2020 (:));
% 
% global_std (1) = nanstd (ALPHA_slope_2000_2020 (:));
% global_std (2) = nanstd (BETA_slope_2000_2020 (:));
% global_std (3) = nanstd (AMP_slope_2000_2020 (:));
% global_std (4) = nanstd (SPL_slope_2000_2020 (:));
% global_std (5) = nanstd (APL_slope_2000_2020 (:));
% global_std (6) = nanstd (NDVIgs_slope_2000_2020 (:));

% subplot (2,3,5)
% load('slope_MK_2000_2020.mat')
% 
% h = imagesc (relative_contribution_APL);
% set(h,'alphadata',~isnan(relative_contribution_APL))
% set(gca, 'color', 'k');
% set(gca,'xtick',[],'xticklabel',[])
% set(gca,'ytick',[],'yticklabel',[])

% % convert .mat into tiff files
% filepath = 'C:\Users\田家旗\Desktop\decompose NDVI\s5_define_each_differential_component\geoinfo_37years.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('GIMMS_NDVI4g_SPL_1992_2020',GIMMS_NDVI4g_SPL_1992_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('GIMMS_NDVI4g_APL_1992_2020',GIMMS_NDVI4g_APL_1992_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('GIMMS_NDVI4g_ALPHA_1992_2020',GIMMS_NDVI4g_ALPHA_1992_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('GIMMS_NDVI4g_BETA_1992_2020',GIMMS_NDVI4g_BETA_1992_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('GIMMS_NDVI4g_MAX_1992_2020',GIMMS_NDVI4g_MAX_1992_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('GIMMS_NDVI4g_NDVI_1992_2020',GIMMS_NDVI4g_NDVI_1992_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);