clear
clc

load('slope_MK_2000_2020.mat')
load('mask_phenological_cycle.mat')

% NDVIgs_slope_2000_2020 (NDVIgs_sig_2000_2020 > 0.1) = nan;

% h = imagesc (NDVI_slope_2000_2020);
% set(h,'ALPHAdata',~isnan(NDVI_slope_2000_2020))
% set(gca, 'color', 'k');
% set(gca,'xtick',[],'xticklabel',[])
% set(gca,'ytick',[],'yticklabel',[])

% ALPHA_slope_2000_2020 (ALPHA_sig > 0.05) = nan;
% BETA_slope_2000_2020 (BETA_sig > 0.05) = nan;
% AMP_slope_2000_2020 (AMP_sig > 0.05) = nan;
% SPL_slope_2000_2020 (SPL_sig > 0.05) = nan;
% APL_slope_2000_2020 (APL_sig > 0.05) = nan;

%% dominant factors: ALPHA, BETA, max, SPL or APL
for i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        NDVI = NDVIgs_slope_2000_2020 (i,j);
        
        ALPHA = ALPHA_slope_2000_2020 (i,j);
        BETA  = BETA_slope_2000_2020 (i,j);
        AMP   = AMP_slope_2000_2020 (i,j);
        SPL   = SPL_slope_2000_2020 (i,j);
        APL   = APL_slope_2000_2020 (i,j);
        
        var = [ALPHA,BETA,AMP,SPL,APL];
        
        if mask == 1 && NDVI > 0
            greening_dominant_component_2001_2019 (i,j) = find (var == max (var));
            browning_dominant_component_2001_2019 (i,j) = nan;
        elseif mask == 1 && NDVI < 0
            greening_dominant_component_2001_2019 (i,j) = nan;
            browning_dominant_component_2001_2019 (i,j) = find (var == min (var));
        else
            greening_dominant_component_2001_2019 (i,j) = nan;
            browning_dominant_component_2001_2019 (i,j) = nan;
        end
    end
end

subplot (1,2,1)
greening_dominant_component_2001_2019 (mask_phenological_cycle ~= 1) = nan;
h = imagesc (greening_dominant_component_2001_2019);
set(h,'alphadata',~isnan(greening_dominant_component_2001_2019))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

colorbar;
cmap = [
    0 0 0.5;  % ����ɫ - ��Ӧ -1
    0 1 0;    % ��ɫ - ��Ӧ 2
    1 0 0;    % ��ɫ - ��Ӧ 3
    1 0.5 0;  % ��ɫ - ��Ӧ 4
    0.5 0.25 0; % ���ɫ - ��Ӧ -4
];

caxis([1 5]);
colormap(cmap);

subplot (1,2,2)
browning_dominant_component_2001_2019 (mask_phenological_cycle ~= 1) = nan;
h = imagesc (browning_dominant_component_2001_2019);
set(h,'alphadata',~isnan(browning_dominant_component_2001_2019))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

colorbar;
cmap = [
    0 0 0.5;  % ����ɫ - ��Ӧ -1
    0 1 0;    % ��ɫ - ��Ӧ 2
    1 0 0;    % ��ɫ - ��Ӧ 3
    1 0.5 0;  % ��ɫ - ��Ӧ 4
    0.5 0.25 0; % ���ɫ - ��Ӧ -4
];

caxis([1 5]);
colormap(cmap);

%             nan_length = length (var (isnan (var)));
%
%             if nan_length ~= 5
%
%                 if NDVI > 0 % greening pixels
%                     greening_dominant_component_2001_2019 (i,j) = find (var == max (var));
%                     browning_dominant_component_2001_2019 (i,j) = nan;
%                 elseif NDVI < 0 % browning pixels
%                     browning_dominant_component_2001_2019 (i,j) = find (var == min (var));
%                     greening_dominant_component_2001_2019 (i,j) = nan;
%                 end
%             else
%                 greening_dominant_component_2001_2019 (i,j) = nan;
%                 browning_dominant_component_2001_2019 (i,j) = nan;
%             end
%
%         else
%             greening_dominant_component_2001_2019 (i,j) = nan;
%             browning_dominant_component_2001_2019 (i,j) = nan;
%         end

save greening_dominant_component_2001_2019 greening_dominant_component_2001_2019
save browning_dominant_component_2001_2019 browning_dominant_component_2001_2019

% convert .mat into tiff files
filepath = 'D:\decompose LAI\decompose LAI_new_test\s09_differential_each_component\geoinfo.tif';
[Data, R] = geotiffread(filepath);
info=geotiffinfo(filepath);
geotiffwrite('greening_dominant_component_2001_2019',greening_dominant_component_2001_2019,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
geotiffwrite('browning_dominant_component_2001_2019',browning_dominant_component_2001_2019,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);