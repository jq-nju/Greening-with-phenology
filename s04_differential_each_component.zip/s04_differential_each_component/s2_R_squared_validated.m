
clear
clc

load('MCD19A3_NDVI_components.mat')
load('mask_phenological_cycle.mat')

years = 1:19;

% i = 120; j = 582;
differential_component_ALPHA   = zeros (347,720,19);
differential_component_BETA    = zeros (347,720,19);
differential_component_AMP     = zeros (347,720,19);
differential_component_APL     = zeros (347,720,19);
differential_component_SPL     = zeros (347,720,19);
differential_component_NDVIgs  = zeros (347,720,19);
differential_component_NDVIgs_validation = zeros (347,720,19);

R_squared_validated = zeros (347,720);

parfor i = 1:347
    for j = 1:720

        mask = mask_phenological_cycle (i,j);

        ALPHA = MCD19A3_NDVI_ALPHA_2000_2020 (i,j,:);
        BETA  = MCD19A3_NDVI_BETA_2000_2020 (i,j,:);
        AMP   = MCD19A3_NDVI_AMP_2000_2020 (i,j,:);
        SPL   = MCD19A3_NDVI_SPL_2000_2020 (i,j,:);
        APL   = MCD19A3_NDVI_APL_2000_2020 (i,j,:);
        NDVIgs = MCD19A3_NDVI_NDVIgs_2000_2020 (i,j,:);

        ALPHA = ALPHA (1,:);
        BETA  = BETA (1,:);
        AMP   = AMP (1,:);
        SPL   = SPL (1,:);
        APL   = APL (1,:);
        NDVIgs = NDVIgs (1,:);

        nan_ALPHA = length (ALPHA (~isnan (ALPHA)));
        nan_BETA  = length (BETA (~isnan (BETA)));
        nan_AMP   = length (AMP (~isnan (AMP)));
        nan_SPL   = length (SPL (~isnan (SPL)));
        nan_APL   = length (APL (~isnan (APL)));
        nan_NDVIgs = length (APL (~isnan (NDVIgs)));

        if mask == 1 && nan_ALPHA == 19 && nan_BETA == 19 && nan_AMP == 19 && nan_SPL == 19 && nan_APL == 19 && nan_NDVIgs == 19 % decomposition

            d_ALPHA = ALPHA - mean (ALPHA);
            d_BETA  = BETA - mean (BETA);
            d_AMP   = AMP - mean (AMP);
            d_SPL   = SPL - mean (SPL);
            d_APL   = APL - mean (APL);
            d_NDVIgs = NDVIgs - mean (NDVIgs);

            differential_component_ALPHA (i,j,:)   = SPL .* AMP .* d_ALPHA;
            differential_component_BETA (i,j,:)    = APL .* AMP .* d_BETA;
            differential_component_AMP (i,j,:)     = (ALPHA .* SPL + BETA .* APL) .* d_AMP;
            differential_component_SPL  (i,j,:)    = ALPHA .* AMP .* d_SPL;
            differential_component_APL (i,j,:)     = BETA .* AMP .* d_APL;
            differential_component_NDVImean (i,j,:) = nan;
            differential_component_NDVIgs (i,j,:)   = d_NDVIgs;
            differential_component_NDVIgs_validation (i,j,:) = SPL .* AMP .* d_ALPHA + APL .* AMP .* d_BETA + (ALPHA .* SPL + BETA .* APL) .* d_AMP + ALPHA .* AMP .* d_SPL + BETA .* AMP .* d_APL;

            A = d_NDVIgs;
            B = SPL .* AMP .* d_ALPHA + APL .* AMP .* d_BETA + (ALPHA .* SPL + BETA .* APL) .* d_AMP + ALPHA .* AMP .* d_SPL + BETA .* AMP .* d_APL;

            [xData, yData] = prepareCurveData(A,B);
            ft = fittype('poly1');
            [fitresult, gof] = fit(xData, yData, ft);

            R_squared_validated (i,j) = gof.rsquare;

        else

            differential_component_ALPHA (i,j,:)   = nan;
            differential_component_BETA (i,j,:)    = nan;
            differential_component_AMP (i,j,:)     = nan;
            differential_component_SPL  (i,j,:)    = nan;
            differential_component_APL (i,j,:)     = nan;
            differential_component_NDVIgs (i,j,:)   = nan;
            differential_component_NDVIgs_validation (i,j,:) = nan;

            R_squared_validated (i,j) = nan;

        end
    end
end

save R_squared_validated R_squared_validated

% % convert .mat into tiff files
% filepath = 'D:\decompose LAI\s09_differential_each_differential_component\geoinfo.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('differential_component_ALPHA',differential_component_ALPHA,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('differential_component_BETA',differential_component_BETA,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('differential_component_AMP',differential_component_AMP,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('differential_component_SPL',differential_component_SPL,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('differential_component_APL',differential_component_APL,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('differential_component_NDVImean',differential_component_NDVImean,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('differential_component_NDVIgs',differential_component_NDVIgs,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('differential_component_NDVIgs_validation',differential_component_NDVIgs_validation,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);