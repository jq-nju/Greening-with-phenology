
clear
clc

load('MCD19A3_NDVI_SOS_2000_2020_filled.mat')
load('MCD19A3_NDVI_EOS_2000_2020_filled.mat')
load('MCD19A3_NDVI_POS_2000_2020_filled.mat')
load('MCD19A3_NDVI_SPL_2000_2020_filled.mat')
load('MCD19A3_NDVI_APL_2000_2020_filled.mat')
load('mask_pixels.mat')
load('NDVIgs_slope_2000_2020.mat')

mask_pixels (NDVIgs_slope_2000_2020 <= 0) = nan;

parfor i = 1:347
    for j = 1:720
        
        mask = mask_pixels (i,j);
        if mask == 1
            
            SOS = MCD19A3_NDVI_SOS_2000_2020_filled (i,j,:);
            EOS = MCD19A3_NDVI_EOS_2000_2020_filled (i,j,:);
            POS = MCD19A3_NDVI_POS_2000_2020_filled (i,j,:);
            SPL = MCD19A3_NDVI_SPL_2000_2020_filled (i,j,:);
            APL = MCD19A3_NDVI_APL_2000_2020_filled (i,j,:);
            
            SOS = SOS (1,:);
            EOS = EOS (1,:);
            POS = POS (1,:);
            SPL = SPL (1,:);
            APL = APL (1,:);
            
            years = 1:19;
            significance_alpha = 0.1; % significance level: 95%
            wantplot = 0;    % do not plot
            
            % SOS
            datain = [years;SOS];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            SOS_slope  (i,j) = sen;
            SOS_sig  (i,j) = sig;
            
            % EOS
            datain = [years;EOS];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            EOS_slope  (i,j) = sen;
            EOS_sig  (i,j) = sig;
            
            % POS
            datain = [years;POS];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            POS_slope  (i,j) = sen;
            POS_sig  (i,j) = sig;
            
            % SPL
            datain = [years;SPL];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            SPL_slope  (i,j) = sen;
            SPL_sig  (i,j) = sig;
            
            % APL
            datain = [years;APL];
            datain = datain';
            [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
            APL_slope  (i,j) = sen;
            APL_sig  (i,j) = sig;
            
        else
            
            SOS_slope  (i,j) = nan;
            SOS_sig  (i,j) = nan;
            
            EOS_slope  (i,j) = nan;
            EOS_sig  (i,j) = nan;
            
            POS_slope  (i,j) = nan;
            POS_sig  (i,j) = nan;
            
            SPL_slope  (i,j) = nan;
            SPL_sig  (i,j) = nan;
            
            APL_slope  (i,j) = nan;
            APL_sig  (i,j) = nan;
            
        end
    end
end