
clear
clc

load('MCD19A3_NDVI_SOS_2000_2020.mat')
load('MCD19A3_NDVI_EOS_2000_2020.mat')
load('MCD19A3_NDVI_POS_2000_2020.mat')
load('MCD19A3_NDVI_SPL_2000_2020.mat')
load('MCD19A3_NDVI_APL_2000_2020.mat')

% fill missing values (e.g., NAN)
MCD19A3_NDVI_SOS_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        SOS = MCD19A3_NDVI_SOS_2000_2020 (i,j,:);
        SOS = SOS (1,:);

        % SOS (SOS >= 365) = nan;
        % SOS (SOS <= 0) = nan;

        nan_length = length (SOS (isnan (SOS)));

        if nan_length ~= 19

            outlier_1 = nanmean (SOS) - 3*nanstd (SOS);
            outlier_2 = nanmean (SOS) + 3*nanstd (SOS);

            SOS (SOS < outlier_1) = nan;
            SOS (SOS > outlier_2) = nan;

            MCD19A3_NDVI_SOS_2000_2020_filled (i,j,:) = fillmissing(SOS,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_SOS_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_SOS_2000_2020_filled MCD19A3_NDVI_SOS_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_EOS_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        EOS = MCD19A3_NDVI_EOS_2000_2020 (i,j,:);
        EOS = EOS (1,:);

        % EOS (EOS >= 365) = nan;
        % EOS (EOS <= 0) = nan;

        nan_length = length (EOS (isnan (EOS)));

        if nan_length ~= 19

            outlier_1 = nanmean (EOS) - 3*nanstd (EOS);
            outlier_2 = nanmean (EOS) + 3*nanstd (EOS);

            EOS (EOS < outlier_1) = nan;
            EOS (EOS > outlier_2) = nan;

            MCD19A3_NDVI_EOS_2000_2020_filled (i,j,:) = fillmissing(EOS,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_EOS_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_EOS_2000_2020_filled MCD19A3_NDVI_EOS_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_POS_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        POS = MCD19A3_NDVI_POS_2000_2020 (i,j,:);
        POS = POS (1,:);

        % POS (POS >= 365) = nan;
        % POS (POS <= 0) = nan;

        nan_length = length (POS (isnan (POS)));

        if nan_length ~= 19

            outlier_1 = nanmean (POS) - 3*nanstd (POS);
            outlier_2 = nanmean (POS) + 3*nanstd (POS);

            POS (POS < outlier_1) = nan;
            POS (POS > outlier_2) = nan;

            MCD19A3_NDVI_POS_2000_2020_filled (i,j,:) = fillmissing(POS,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_POS_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_POS_2000_2020_filled MCD19A3_NDVI_POS_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_SPL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        spl = MCD19A3_NDVI_SPL_2000_2020 (i,j,:);
        spl = spl (1,:);

        spl (spl >= 365) = nan;
        spl (spl <= 0) = nan;

        nan_length = length (spl (isnan (spl)));

        if nan_length ~= 19

            outlier_1 = nanmean (spl) - 3*nanstd (spl);
            outlier_2 = nanmean (spl) + 3*nanstd (spl);

            spl (spl < outlier_1) = nan;
            spl (spl > outlier_2) = nan;

            MCD19A3_NDVI_SPL_2000_2020_filled (i,j,:) = fillmissing(spl,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_SPL_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_SPL_2000_2020_filled MCD19A3_NDVI_SPL_2000_2020_filled

% fill missing values (e.g., NAN)
MCD19A3_NDVI_APL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720

        APL = MCD19A3_NDVI_APL_2000_2020 (i,j,:);
        APL = APL (1,:);

        APL (APL >= 365) = nan;
        APL (APL <= 0) = nan;

        nan_length = length (APL (isnan (APL)));

        if nan_length ~= 19

            outlier_1 = nanmean (APL) - 3*nanstd (APL);
            outlier_2 = nanmean (APL) + 3*nanstd (APL);

            APL (APL < outlier_1) = nan;
            APL (APL > outlier_2) = nan;

            MCD19A3_NDVI_APL_2000_2020_filled (i,j,:) = fillmissing(APL,'linear','EndValues','nearest');

        else

            MCD19A3_NDVI_APL_2000_2020_filled (i,j,:) = nan;

        end

    end
end

save MCD19A3_NDVI_APL_2000_2020_filled MCD19A3_NDVI_APL_2000_2020_filled