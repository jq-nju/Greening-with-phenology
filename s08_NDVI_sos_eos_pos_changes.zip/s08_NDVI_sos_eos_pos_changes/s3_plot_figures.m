clear
clc
 
load('phenological_changes_slope.mat')

% s2_MK_slope

% h1 = histogram(SOS_slope);
% hold on
% h2 = histogram(EOS_slope);
% hold on
% h3 = histogram(POS_slope);
% hold on
% h4 = histogram(SPL_slope);
% hold on
% h5 = histogram(APL_slope);
% 
% h1.Normalization = 'probability';
% h1.BinWidth = 0.1;
% h2.Normalization = 'probability';
% h2.BinWidth = 0.1;
% h3.Normalization = 'probability';
% h3.BinWidth = 0.1;
% h4.Normalization = 'probability';
% h4.BinWidth = 0.1;
% h5.Normalization = 'probability';
% h5.BinWidth = 0.1;

% global_mean (1) = nanmean (SOS_slope (:));
% global_mean (2) = nanmean (EOS_slope (:));
% global_mean (3) = nanmean (POS_slope (:));
% global_mean (4) = nanmean (SPL_slope (:));
% global_mean (5) = nanmean (APL_slope (:));

subplot (2,3,1)
h = imagesc (SOS_slope);
set(h,'alphadata',~isnan(SOS_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (2,3,2)
h = imagesc (EOS_slope);
set(h,'alphadata',~isnan(EOS_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (2,3,3)
h = imagesc (POS_slope);
set(h,'alphadata',~isnan(POS_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (2,3,4)
h = imagesc (SPL_slope);
set(h,'alphadata',~isnan(SPL_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

subplot (2,3,5)
h = imagesc (APL_slope);
set(h,'alphadata',~isnan(APL_slope))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

%%
subplot (2,3,6)
SOS_slope = reshape (SOS_slope, [1,347*720]);
EOS_slope = reshape (EOS_slope, [1,347*720]);
POS_slope = reshape (POS_slope, [1,347*720]);
SPL_slope = reshape (SPL_slope, [1,347*720]);
APL_slope = reshape (APL_slope, [1,347*720]);

data = [SOS_slope;EOS_slope;POS_slope;SPL_slope;APL_slope];
data = data';
violin(data);
hold on
plot ([0 6],[0 0])
hold on
h = boxplot(data,'symbol', '');
set(h,'LineWidth',1.1);