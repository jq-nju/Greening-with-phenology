clear
clc

load('slope_MK_2000_2020_MMEM_s3.mat')
load('mask_phenological_cycle.mat')

% mask_phenological_cycle (lai_slope <= 0) = nan;

% laigs_slope (laigs_sig > 0.1) = nan;

% h = imagesc (lai_slope);
% set(h,'alphadata',~isnan(lai_slope))
% set(gca, 'color', 'k');
% set(gca,'xtick',[],'xticklabel',[])
% set(gca,'ytick',[],'yticklabel',[])

% alpha_slope (alpha_sig > 0.05) = nan;
% beta_slope (beta_sig > 0.05) = nan;
% amp_slope (amp_sig > 0.05) = nan;
% spl_slope (spl_sig > 0.05) = nan;
% apl_slope (apl_sig > 0.05) = nan;

%% dominant factors: alpha, beta, max, spl or apl
for i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        lai = lai_slope (i,j);
        
        alpha = alpha_slope (i,j);
        beta  = beta_slope (i,j);
        amp   = amp_slope (i,j);
        spl   = spl_slope (i,j);
        apl   = apl_slope (i,j);
        
        var = [alpha,beta,amp,spl,apl];
        
        if mask == 1 && lai > 0
            var_max = find (var == max (var));
            greening_dominant_component_2001_2019 (i,j) = var_max (1);
            browning_dominant_component_2001_2019 (i,j) = nan;
        elseif mask == 1 && lai < 0
            greening_dominant_component_2001_2019 (i,j) = nan;
            var_min = find (var == min (var));
            browning_dominant_component_2001_2019 (i,j) = var_min (1);
        else
            greening_dominant_component_2001_2019 (i,j) = nan;
            browning_dominant_component_2001_2019 (i,j) = nan;
        end
    end
end

save greening_dominant_component_2001_2019 greening_dominant_component_2001_2019
save browning_dominant_component_2001_2019 browning_dominant_component_2001_2019

subplot (1,2,1)
greening_dominant_component_2001_2019 (mask_phenological_cycle ~= 1) = nan;
h = imagesc (greening_dominant_component_2001_2019);
set(h,'alphadata',~isnan(greening_dominant_component_2001_2019))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

colorbar;
cmap = [
    0 0 0.5;  % 深蓝色 - 对应 -1
    0 1 0;    % 绿色 - 对应 2
    1 0 0;    % 红色 - 对应 3
    1 0.5 0;  % 橙色 - 对应 4
    0.5 0.25 0; % 深橙色 - 对应 -4
];

caxis([1 5]);
colormap(cmap);

subplot (1,2,2)
browning_dominant_component_2001_2019 (mask_phenological_cycle ~= 1) = nan;
h = imagesc (browning_dominant_component_2001_2019);
set(h,'alphadata',~isnan(browning_dominant_component_2001_2019))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

colorbar;
cmap = [
    0 0 0.5;  % 深蓝色 - 对应 -1
    0 1 0;    % 绿色 - 对应 2
    1 0 0;    % 红色 - 对应 3
    1 0.5 0;  % 橙色 - 对应 4
    0.5 0.25 0; % 深橙色 - 对应 -4
];

caxis([1 5]);
colormap(cmap);

% subplot (1,2,2)
% browning_dominant_component_2001_2019 (mask_phenological_cycle ~= 1) = nan;
% h = imagesc (browning_dominant_component_2001_2019);
% set(h,'alphadata',~isnan(browning_dominant_component_2001_2019))
% set(gca, 'color', 'k');
% set(gca,'xtick',[],'xticklabel',[])
% set(gca,'ytick',[],'yticklabel',[])

%             nan_length = length (var (isnan (var)));
%
%             if nan_length ~= 5
%
%                 if lai > 0 % greening pixels
%                     greening_dominant_component_2001_2019 (i,j) = find (var == max (var));
%                     browning_dominant_component_2001_2019 (i,j) = nan;
%                 elseif lai < 0 % browning pixels
%                     browning_dominant_component_2001_2019 (i,j) = find (var == min (var));
%                     greening_dominant_component_2001_2019 (i,j) = nan;
%                 end
%             else
%                 greening_dominant_component_2001_2019 (i,j) = nan;
%                 browning_dominant_component_2001_2019 (i,j) = nan;
%             end
%
%         else
%             greening_dominant_component_2001_2019 (i,j) = nan;
%             browning_dominant_component_2001_2019 (i,j) = nan;
%         end

% save greening_dominant_component_2001_2019 greening_dominant_component_2001_2019
% save browning_dominant_component_2001_2019 browning_dominant_component_2001_2019