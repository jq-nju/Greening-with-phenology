
clear
clc

% load data
load('MMEM_LAI_s1_snowfilled_sgfilter.mat')
load('mask_phenological_cycle.mat')

MMEM_LAI_s1_PKD_reference = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        
        % i = 120; j = 582;
        if mask == 1
            timeseries = MMEM_LAI_s1_snowfilled_sgfilter (i,j,:);
            timeseries = timeseries (1,:);
            
            % calculate average
            timeseries_matrix = reshape(timeseries,[24,504/24]);
            timeseries_matrix = timeseries_matrix';
            
            lai_average = mean (timeseries_matrix);
            
            % daily interpolation
            lai_3years = [lai_average,lai_average,lai_average];
            
            xx = 1:1095;
            x_1 = 8:15:365;
            x_2 = x_1 + 365;
            x_3 = x_2 + 365;
            
            x_3years = [x_1,x_2,x_3];
            
            daily_lai_reference = interp1 (x_3years,lai_3years,xx,'spline');
            daily_lai_reference = daily_lai_reference (1,366:730);
            
            peak_date_lai_average = find (daily_lai_reference == max (daily_lai_reference));
            MMEM_LAI_s1_PKD_reference (i,j) = peak_date_lai_average (1);
            
        else
            MMEM_LAI_s1_PKD_reference (i,j) = nan;
        end
        
    end
end

save MMEM_LAI_s1_PKD_reference MMEM_LAI_s1_PKD_reference


clear
clc

% load data
load('MMEM_LAI_s2_snowfilled_sgfilter.mat')
load('mask_phenological_cycle.mat')

MMEM_LAI_s2_PKD_reference = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        
        % i = 120; j = 582;
        if mask == 1
            timeseries = MMEM_LAI_s2_snowfilled_sgfilter (i,j,:);
            timeseries = timeseries (1,:);
            
            % calculate average
            timeseries_matrix = reshape(timeseries,[24,504/24]);
            timeseries_matrix = timeseries_matrix';
            
            lai_average = mean (timeseries_matrix);
            
            % daily interpolation
            lai_3years = [lai_average,lai_average,lai_average];
            
            xx = 1:1095;
            x_1 = 8:15:365;
            x_2 = x_1 + 365;
            x_3 = x_2 + 365;
            
            x_3years = [x_1,x_2,x_3];
            
            daily_lai_reference = interp1 (x_3years,lai_3years,xx,'spline');
            daily_lai_reference = daily_lai_reference (1,366:730);
            
            peak_date_lai_average = find (daily_lai_reference == max (daily_lai_reference));
            MMEM_LAI_s2_PKD_reference (i,j) = peak_date_lai_average (1);
            
        else
            MMEM_LAI_s2_PKD_reference (i,j) = nan;
        end
        
    end
end

save MMEM_LAI_s2_PKD_reference MMEM_LAI_s2_PKD_reference


clear
clc

% load data
load('MMEM_LAI_s3_snowfilled_sgfilter.mat')
load('mask_phenological_cycle.mat')

MMEM_LAI_s3_PKD_reference = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        
        % i = 120; j = 582;
        if mask == 1
            timeseries = MMEM_LAI_s3_snowfilled_sgfilter (i,j,:);
            timeseries = timeseries (1,:);
            
            % calculate average
            timeseries_matrix = reshape(timeseries,[24,504/24]);
            timeseries_matrix = timeseries_matrix';
            
            lai_average = mean (timeseries_matrix);
            
            % daily interpolation
            lai_3years = [lai_average,lai_average,lai_average];
            
            xx = 1:1095;
            x_1 = 8:15:365;
            x_2 = x_1 + 365;
            x_3 = x_2 + 365;
            
            x_3years = [x_1,x_2,x_3];
            
            daily_lai_reference = interp1 (x_3years,lai_3years,xx,'spline');
            daily_lai_reference = daily_lai_reference (1,366:730);
            
            peak_date_lai_average = find (daily_lai_reference == max (daily_lai_reference));
            MMEM_LAI_s3_PKD_reference (i,j) = peak_date_lai_average (1);
            
        else
            MMEM_LAI_s3_PKD_reference (i,j) = nan;
        end
        
    end
end

save MMEM_LAI_s3_PKD_reference MMEM_LAI_s3_PKD_reference