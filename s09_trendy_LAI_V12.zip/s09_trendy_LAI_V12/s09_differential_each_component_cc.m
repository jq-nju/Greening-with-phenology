
clear
clc

load('MMEM_LAI_s1_filled.mat')
load('MMEM_LAI_s2_filled.mat')

load('mask_phenological_cycle.mat')

years = 1:19;

% i = 120; j = 582;
parfor i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        
        if mask == 1
            
            %% s1
            alpha_s1 = MMEM_LAI_s1_ALPHA_2000_2020_filled (i,j,:);
            beta_s1  = MMEM_LAI_s1_BETA_2000_2020_filled (i,j,:);
            amp_s1   = MMEM_LAI_s1_AMP_2000_2020_filled (i,j,:);
            spl_s1   = MMEM_LAI_s1_SPL_2000_2020_filled (i,j,:);
            apl_s1   = MMEM_LAI_s1_APL_2000_2020_filled (i,j,:);
            lai_s1   = MMEM_LAI_s1_LAIgs_2000_2020_filled (i,j,:);
            
            alpha_s1 = alpha_s1 (1,:);
            beta_s1  = beta_s1 (1,:);
            amp_s1   = amp_s1 (1,:);
            spl_s1   = spl_s1 (1,:);
            apl_s1   = apl_s1 (1,:);
            lai_s1   = lai_s1 (1,:);
            
            d_alpha_s1 = alpha_s1 - mean (alpha_s1);
            d_beta_s1  = beta_s1 - mean (beta_s1);
            d_amp_s1   = amp_s1 - mean (amp_s1);
            d_spl_s1   = spl_s1 - mean (spl_s1);
            d_apl_s1   = apl_s1 - mean (apl_s1);
            d_lai_s1   = lai_s1 - mean (lai_s1);
            
            component_alpha_s1 = spl_s1 .* amp_s1 .* d_alpha_s1;
            component_beta_s1  = apl_s1 .* amp_s1 .* d_beta_s1;
            component_amp_s1 = (alpha_s1 .* spl_s1 + beta_s1 .* apl_s1) .* d_amp_s1;
            component_spl_s1   = alpha_s1 .* amp_s1 .* d_spl_s1;
            component_apl_s1   = beta_s1 .* amp_s1 .* d_apl_s1;
            component_lai_s1   = d_lai_s1;
            
            %% s2
            alpha_s2 = MMEM_LAI_s2_ALPHA_2000_2020_filled (i,j,:);
            beta_s2  = MMEM_LAI_s2_BETA_2000_2020_filled (i,j,:);
            amp_s2   = MMEM_LAI_s2_AMP_2000_2020_filled (i,j,:);
            spl_s2   = MMEM_LAI_s2_SPL_2000_2020_filled (i,j,:);
            apl_s2   = MMEM_LAI_s2_APL_2000_2020_filled (i,j,:);
            lai_s2   = MMEM_LAI_s2_LAIgs_2000_2020_filled (i,j,:);
            
            alpha_s2 = alpha_s2 (1,:);
            beta_s2  = beta_s2 (1,:);
            amp_s2   = amp_s2 (1,:);
            spl_s2   = spl_s2 (1,:);
            apl_s2   = apl_s2 (1,:);
            lai_s2   = lai_s2 (1,:);
            
            d_alpha_s2 = alpha_s2 - mean (alpha_s2);
            d_beta_s2  = beta_s2 - mean (beta_s2);
            d_amp_s2   = amp_s2 - mean (amp_s2);
            d_spl_s2   = spl_s2 - mean (spl_s2);
            d_apl_s2   = apl_s2 - mean (apl_s2);
            d_lai_s2   = lai_s2 - mean (lai_s2);
            
            component_alpha_s2 = spl_s2 .* amp_s2 .* d_alpha_s2;
            component_beta_s2  = apl_s2 .* amp_s2 .* d_beta_s2;
            component_amp_s2 = (alpha_s2 .* spl_s2 + beta_s2 .* apl_s2) .* d_amp_s2;
            component_spl_s2   = alpha_s2 .* amp_s2 .* d_spl_s2;
            component_apl_s2   = beta_s2 .* amp_s2 .* d_apl_s2;
            component_lai_s2   = d_lai_s2;
            
            nan_alpha_s1 = length (alpha_s1 (isnan (alpha_s1)));
            nan_beta_s1  = length (beta_s1 (isnan (beta_s1)));
            
            nan_alpha_s2 = length (alpha_s2 (isnan (alpha_s2)));
            nan_beta_s2  = length (beta_s2 (isnan (beta_s2)));
            
            if nan_alpha_s1 == 0 && nan_beta_s1 == 0 && nan_alpha_s2 == 0 && nan_beta_s2 == 0
                
                %% s2 - s1
                component_alpha = component_alpha_s2 - component_alpha_s1;
                component_beta = component_beta_s2 - component_beta_s1;
                component_amp = component_amp_s2 - component_amp_s1;
                component_spl = component_spl_s2 - component_spl_s1;
                component_apl = component_apl_s2 - component_apl_s1;
                component_lai = component_lai_s2 - component_lai_s1;
                
                % Mann–Kendall Tau-b with Sen's method
                significance_alpha = 0.1; % significance level: 95%
                wantplot = 0;    % do not plot
                
                % lai
                datain = [years;component_lai];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                lai_slope_cc  (i,j) = sen;
                lai_sig_cc  (i,j) = sig;
                
                % alpha
                datain = [years;component_alpha];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                alpha_slope_cc  (i,j) = sen;
                alpha_sig_cc (i,j) = sig;
                
                % spl
                datain = [years;component_spl];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                spl_slope_cc  (i,j) = sen;
                spl_sig_cc (i,j) = sig;
                
                % apl
                datain = [years;component_apl];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                apl_slope_cc  (i,j) = sen;
                apl_sig_cc (i,j) = sig;
                
                % amp
                datain = [years;component_amp];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                amp_slope_cc  (i,j) = sen;
                amp_sig_cc (i,j) = sig;
                
                % beta
                datain = [years;component_beta];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                beta_slope_cc  (i,j) = sen;
                beta_sig_cc (i,j) = sig;
                
            else
                
                lai_slope_cc  (i,j)   = nan;
                lai_sig_cc  (i,j) = nan;
                
                alpha_slope_cc  (i,j) = nan;
                alpha_sig_cc  (i,j) = nan;
                
                spl_slope_cc  (i,j)   = nan;
                spl_sig_cc  (i,j) = nan;
                
                apl_slope_cc  (i,j)   = nan;
                apl_sig_cc  (i,j) = nan;
                
                amp_slope_cc  (i,j)   = nan;
                amp_sig_cc  (i,j) = nan;
                
                beta_slope_cc  (i,j)  = nan;
                beta_sig_cc  (i,j)  = nan;
                
            end
            
        else
            
            lai_slope_cc  (i,j)   = nan;
            lai_sig_cc  (i,j) = nan;
            
            alpha_slope_cc  (i,j) = nan;
            alpha_sig_cc  (i,j) = nan;
            
            spl_slope_cc  (i,j)   = nan;
            spl_sig_cc  (i,j) = nan;
            
            apl_slope_cc  (i,j)   = nan;
            apl_sig_cc  (i,j) = nan;
            
            amp_slope_cc  (i,j)   = nan;
            amp_sig_cc  (i,j) = nan;
            
            beta_slope_cc  (i,j)  = nan;
            beta_sig_cc  (i,j)  = nan;
        end
    end
end

% % convert .mat into tiff files
% filepath = 'C:\Users\田家旗\Desktop\decompose LAI\s5_define_each_component\geoinfo_37years.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s1_SPL_2000_2020',MMEM_LAI_s1_SPL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_APL_2000_2020',MMEM_LAI_s1_APL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_ALPHA_2000_2020',MMEM_LAI_s1_ALPHA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_BETA_2000_2020',MMEM_LAI_s1_BETA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_AMP_2000_2020',MMEM_LAI_s1_AMP_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_LAI_2000_2020',MMEM_LAI_s1_LAI_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);