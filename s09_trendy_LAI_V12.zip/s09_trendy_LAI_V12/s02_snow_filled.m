%% s1
% snow pixels filled by 5th percentile

clear
clc

load('MMEM_LAI_s1.mat')
load('Freeze_Thaw_1982_2020_05degree.mat')

MMEM_LAI_s1_snowfilled = zeros (347,720,504);
freeze_thaw_mask = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        % i = 120; j = 582;
        lai = MMEM_LAI_s1 (i,j,:);
        lai = lai (1,:);
        
        lai (isnan (lai)) = 0;
        nan_length = length (lai (lai == 0));
        
        if nan_length == 252 % background pixels
            
            MMEM_LAI_s1_snowfilled (i,j,:) = 0;
            
        else
            
            % interpolate monthly into 15 days
            xx = 1:252;
            xxx = 0.5:0.5:252;
            lai = interp1 (xx,lai,xxx);
            
            ft_19 = Freeze_Thaw_2000_05degree (i,j,:); ft_19 = ft_19 (1,8:15:365);
            ft_20 = Freeze_Thaw_2001_05degree (i,j,:); ft_20 = ft_20 (1,8:15:365);
            ft_21 = Freeze_Thaw_2002_05degree (i,j,:); ft_21 = ft_21 (1,8:15:365);
            ft_22 = Freeze_Thaw_2003_05degree (i,j,:); ft_22 = ft_22 (1,8:15:365);
            ft_23 = Freeze_Thaw_2004_05degree (i,j,:); ft_23 = ft_23 (1,8:15:365);
            ft_24 = Freeze_Thaw_2005_05degree (i,j,:); ft_24 = ft_24 (1,8:15:365);
            ft_25 = Freeze_Thaw_2006_05degree (i,j,:); ft_25 = ft_25 (1,8:15:365);
            ft_26 = Freeze_Thaw_2007_05degree (i,j,:); ft_26 = ft_26 (1,8:15:365);
            ft_27 = Freeze_Thaw_2008_05degree (i,j,:); ft_27 = ft_27 (1,8:15:365);
            ft_28 = Freeze_Thaw_2009_05degree (i,j,:); ft_28 = ft_28 (1,8:15:365);
            ft_29 = Freeze_Thaw_2010_05degree (i,j,:); ft_29 = ft_29 (1,8:15:365);
            ft_30 = Freeze_Thaw_2011_05degree (i,j,:); ft_30 = ft_30 (1,8:15:365);
            ft_31 = Freeze_Thaw_2012_05degree (i,j,:); ft_31 = ft_31 (1,8:15:365);
            ft_32 = Freeze_Thaw_2013_05degree (i,j,:); ft_32 = ft_32 (1,8:15:365);
            ft_33 = Freeze_Thaw_2014_05degree (i,j,:); ft_33 = ft_33 (1,8:15:365);
            ft_34 = Freeze_Thaw_2015_05degree (i,j,:); ft_34 = ft_34 (1,8:15:365);
            ft_35 = Freeze_Thaw_2016_05degree (i,j,:); ft_35 = ft_35 (1,8:15:365);
            ft_36 = Freeze_Thaw_2017_05degree (i,j,:); ft_36 = ft_36 (1,8:15:365);
            ft_37 = Freeze_Thaw_2018_05degree (i,j,:); ft_37 = ft_37 (1,8:15:365);
            ft_38 = Freeze_Thaw_2019_05degree (i,j,:); ft_38 = ft_38 (1,8:15:365);
            ft_39 = Freeze_Thaw_2020_05degree (i,j,:); ft_39 = ft_39 (1,8:15:365);
            
            ft = [ft_19,ft_20,ft_21,ft_22,ft_23,ft_24,ft_25,ft_26,ft_27,ft_28,ft_29,ft_30,ft_31,ft_32,ft_33,ft_34,ft_35,ft_36,ft_37,ft_38,ft_39];
            
            ft = single (ft);
            
            % generate a freeze-thaw mask
            ft_length = length (ft (ft == 253));
            if ft_length == 504 % no freeze
                freeze_thaw_mask (i,j) = 1;
            else
                freeze_thaw_mask (i,j) = 0;
            end
            
            lai (ft == 0) = nan; % Frozen (AM and PM frozen)
            lai (ft == 2) = nan; % Transitional (AM frozen, PM thawed)
            lai (ft == 3) = nan; % Inverse Transitional (AM thawed, PM frozen)
            
            data = lai;
            data (isnan (data)) = [];
            
            lai_background = prctile(data,5);
            lai (isnan (lai)) = lai_background;
            
            MMEM_LAI_s1_snowfilled (i,j,:) = lai;
        end
    end
end

MMEM_LAI_s1_snowfilled = single (MMEM_LAI_s1_snowfilled);
save MMEM_LAI_s1_snowfilled MMEM_LAI_s1_snowfilled
% save freeze_thaw_mask freeze_thaw_mask

% convert .mat into tiff files
filepath = 'D:\decompose LAI\s14_trendy_LAI_V12\12_MMEM_LAI_v2\s1_snow_filled\geoinfo_05degree_504bands.tif';
[Data, R] = geotiffread(filepath);
info = geotiffinfo(filepath);
geotiffwrite('MMEM_LAI_s1_snowfilled', MMEM_LAI_s1_snowfilled, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% s2
% snow pixels filled by 5th percentile

clear
clc

load('MMEM_LAI_s2.mat')
load('Freeze_Thaw_1982_2020_05degree.mat')

MMEM_LAI_s2_snowfilled = zeros (347,720,504);
freeze_thaw_mask = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        % i = 120; j = 582;
        lai = MMEM_LAI_s2 (i,j,:);
        lai = lai (1,:);
        
        lai (isnan (lai)) = 0;
        nan_length = length (lai (lai == 0));
        
        if nan_length == 252 % background pixels
            
            MMEM_LAI_s2_snowfilled (i,j,:) = 0;
            
        else
            
            % interpolate monthly into 15 days
            xx = 1:252;
            xxx = 0.5:0.5:252;
            lai = interp1 (xx,lai,xxx);
            
            ft_19 = Freeze_Thaw_2000_05degree (i,j,:); ft_19 = ft_19 (1,8:15:365);
            ft_20 = Freeze_Thaw_2001_05degree (i,j,:); ft_20 = ft_20 (1,8:15:365);
            ft_21 = Freeze_Thaw_2002_05degree (i,j,:); ft_21 = ft_21 (1,8:15:365);
            ft_22 = Freeze_Thaw_2003_05degree (i,j,:); ft_22 = ft_22 (1,8:15:365);
            ft_23 = Freeze_Thaw_2004_05degree (i,j,:); ft_23 = ft_23 (1,8:15:365);
            ft_24 = Freeze_Thaw_2005_05degree (i,j,:); ft_24 = ft_24 (1,8:15:365);
            ft_25 = Freeze_Thaw_2006_05degree (i,j,:); ft_25 = ft_25 (1,8:15:365);
            ft_26 = Freeze_Thaw_2007_05degree (i,j,:); ft_26 = ft_26 (1,8:15:365);
            ft_27 = Freeze_Thaw_2008_05degree (i,j,:); ft_27 = ft_27 (1,8:15:365);
            ft_28 = Freeze_Thaw_2009_05degree (i,j,:); ft_28 = ft_28 (1,8:15:365);
            ft_29 = Freeze_Thaw_2010_05degree (i,j,:); ft_29 = ft_29 (1,8:15:365);
            ft_30 = Freeze_Thaw_2011_05degree (i,j,:); ft_30 = ft_30 (1,8:15:365);
            ft_31 = Freeze_Thaw_2012_05degree (i,j,:); ft_31 = ft_31 (1,8:15:365);
            ft_32 = Freeze_Thaw_2013_05degree (i,j,:); ft_32 = ft_32 (1,8:15:365);
            ft_33 = Freeze_Thaw_2014_05degree (i,j,:); ft_33 = ft_33 (1,8:15:365);
            ft_34 = Freeze_Thaw_2015_05degree (i,j,:); ft_34 = ft_34 (1,8:15:365);
            ft_35 = Freeze_Thaw_2016_05degree (i,j,:); ft_35 = ft_35 (1,8:15:365);
            ft_36 = Freeze_Thaw_2017_05degree (i,j,:); ft_36 = ft_36 (1,8:15:365);
            ft_37 = Freeze_Thaw_2018_05degree (i,j,:); ft_37 = ft_37 (1,8:15:365);
            ft_38 = Freeze_Thaw_2019_05degree (i,j,:); ft_38 = ft_38 (1,8:15:365);
            ft_39 = Freeze_Thaw_2020_05degree (i,j,:); ft_39 = ft_39 (1,8:15:365);
            
            ft = [ft_19,ft_20,ft_21,ft_22,ft_23,ft_24,ft_25,ft_26,ft_27,ft_28,ft_29,ft_30,ft_31,ft_32,ft_33,ft_34,ft_35,ft_36,ft_37,ft_38,ft_39];
            
            ft = single (ft);
            
            % generate a freeze-thaw mask
            ft_length = length (ft (ft == 253));
            if ft_length == 504 % no freeze
                freeze_thaw_mask (i,j) = 1;
            else
                freeze_thaw_mask (i,j) = 0;
            end
            
            lai (ft == 0) = nan; % Frozen (AM and PM frozen)
            lai (ft == 2) = nan; % Transitional (AM frozen, PM thawed)
            lai (ft == 3) = nan; % Inverse Transitional (AM thawed, PM frozen)
            
            data = lai;
            data (isnan (data)) = [];
            
            lai_background = prctile(data,5);
            lai (isnan (lai)) = lai_background;
            
            MMEM_LAI_s2_snowfilled (i,j,:) = lai;
        end
    end
end

MMEM_LAI_s2_snowfilled = single (MMEM_LAI_s2_snowfilled);
save MMEM_LAI_s2_snowfilled MMEM_LAI_s2_snowfilled
% save freeze_thaw_mask freeze_thaw_mask

% convert .mat into tiff files
filepath = 'D:\decompose LAI\s14_trendy_LAI_V12\12_MMEM_LAI_v2\s1_snow_filled\geoinfo_05degree_504bands.tif';
[Data, R] = geotiffread(filepath);
info = geotiffinfo(filepath);
geotiffwrite('MMEM_LAI_s2_snowfilled', MMEM_LAI_s2_snowfilled, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% s3
% snow pixels filled by 5th percentile

clear
clc

load('MMEM_LAI_s3.mat')
load('Freeze_Thaw_1982_2020_05degree.mat')

MMEM_LAI_s3_snowfilled = zeros (347,720,504);
freeze_thaw_mask = zeros (347,720);

for i = 1:347
    for j = 1:720
        
        % i = 120; j = 582;
        lai = MMEM_LAI_s3 (i,j,:);
        lai = lai (1,:);
        
        lai (isnan (lai)) = 0;
        nan_length = length (lai (lai == 0));
        
        if nan_length == 252 % background pixels
            
            MMEM_LAI_s3_snowfilled (i,j,:) = 0;
            
        else
            
            % interpolate monthly into 15 days
            xx = 1:252;
            xxx = 0.5:0.5:252;
            lai = interp1 (xx,lai,xxx);
            
            ft_19 = Freeze_Thaw_2000_05degree (i,j,:); ft_19 = ft_19 (1,8:15:365);
            ft_20 = Freeze_Thaw_2001_05degree (i,j,:); ft_20 = ft_20 (1,8:15:365);
            ft_21 = Freeze_Thaw_2002_05degree (i,j,:); ft_21 = ft_21 (1,8:15:365);
            ft_22 = Freeze_Thaw_2003_05degree (i,j,:); ft_22 = ft_22 (1,8:15:365);
            ft_23 = Freeze_Thaw_2004_05degree (i,j,:); ft_23 = ft_23 (1,8:15:365);
            ft_24 = Freeze_Thaw_2005_05degree (i,j,:); ft_24 = ft_24 (1,8:15:365);
            ft_25 = Freeze_Thaw_2006_05degree (i,j,:); ft_25 = ft_25 (1,8:15:365);
            ft_26 = Freeze_Thaw_2007_05degree (i,j,:); ft_26 = ft_26 (1,8:15:365);
            ft_27 = Freeze_Thaw_2008_05degree (i,j,:); ft_27 = ft_27 (1,8:15:365);
            ft_28 = Freeze_Thaw_2009_05degree (i,j,:); ft_28 = ft_28 (1,8:15:365);
            ft_29 = Freeze_Thaw_2010_05degree (i,j,:); ft_29 = ft_29 (1,8:15:365);
            ft_30 = Freeze_Thaw_2011_05degree (i,j,:); ft_30 = ft_30 (1,8:15:365);
            ft_31 = Freeze_Thaw_2012_05degree (i,j,:); ft_31 = ft_31 (1,8:15:365);
            ft_32 = Freeze_Thaw_2013_05degree (i,j,:); ft_32 = ft_32 (1,8:15:365);
            ft_33 = Freeze_Thaw_2014_05degree (i,j,:); ft_33 = ft_33 (1,8:15:365);
            ft_34 = Freeze_Thaw_2015_05degree (i,j,:); ft_34 = ft_34 (1,8:15:365);
            ft_35 = Freeze_Thaw_2016_05degree (i,j,:); ft_35 = ft_35 (1,8:15:365);
            ft_36 = Freeze_Thaw_2017_05degree (i,j,:); ft_36 = ft_36 (1,8:15:365);
            ft_37 = Freeze_Thaw_2018_05degree (i,j,:); ft_37 = ft_37 (1,8:15:365);
            ft_38 = Freeze_Thaw_2019_05degree (i,j,:); ft_38 = ft_38 (1,8:15:365);
            ft_39 = Freeze_Thaw_2020_05degree (i,j,:); ft_39 = ft_39 (1,8:15:365);
            
            ft = [ft_19,ft_20,ft_21,ft_22,ft_23,ft_24,ft_25,ft_26,ft_27,ft_28,ft_29,ft_30,ft_31,ft_32,ft_33,ft_34,ft_35,ft_36,ft_37,ft_38,ft_39];
            
            ft = single (ft);
            
            % generate a freeze-thaw mask
            ft_length = length (ft (ft == 253));
            if ft_length == 504 % no freeze
                freeze_thaw_mask (i,j) = 1;
            else
                freeze_thaw_mask (i,j) = 0;
            end
            
            lai (ft == 0) = nan; % Frozen (AM and PM frozen)
            lai (ft == 2) = nan; % Transitional (AM frozen, PM thawed)
            lai (ft == 3) = nan; % Inverse Transitional (AM thawed, PM frozen)
            
            data = lai;
            data (isnan (data)) = [];
            
            lai_background = prctile(data,5);
            lai (isnan (lai)) = lai_background;
            
            MMEM_LAI_s3_snowfilled (i,j,:) = lai;
        end
    end
end

MMEM_LAI_s3_snowfilled = single (MMEM_LAI_s3_snowfilled);
save MMEM_LAI_s3_snowfilled MMEM_LAI_s3_snowfilled
% save freeze_thaw_mask freeze_thaw_mask

% convert .mat into tiff files
filepath = 'D:\decompose LAI\s14_trendy_LAI_V12\12_MMEM_LAI_v2\s1_snow_filled\geoinfo_05degree_504bands.tif';
[Data, R] = geotiffread(filepath);
info = geotiffinfo(filepath);
geotiffwrite('MMEM_LAI_s3_snowfilled', MMEM_LAI_s3_snowfilled, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);