clear
clc

load('slope_MK_2000_2020_MMEM_lcc.mat')
load('slope_MK_2000_2020_MMEM_cc.mat')
load('slope_MK_2000_2020_MMEM_co2.mat')
load('greening_dominant_component_2001_2019.mat')

mask_greening_pixels = greening_dominant_component_2001_2019;
mask_greening_pixels (~isnan (mask_greening_pixels)) = 1;

%% dominant factors: co2, cc, lcc or others
for i = 1:347
    for j = 1:720
        
        mask = mask_greening_pixels (i,j);
        
        if mask == 1
            
            ALPHA_co2 = alpha_slope_co2 (i,j);
            BETA_co2  = beta_slope_co2 (i,j);
            AMP_co2   = amp_slope_co2 (i,j);
            SPL_co2   = spl_slope_co2 (i,j);
            APL_co2   = apl_slope_co2 (i,j);
            
            ALPHA_cc = alpha_slope_cc (i,j);
            BETA_cc  = beta_slope_cc (i,j);
            AMP_cc   = amp_slope_cc (i,j);
            SPL_cc   = spl_slope_cc (i,j);
            APL_cc   = apl_slope_cc (i,j);
            
            ALPHA_lcc = alpha_slope_lcc (i,j);
            BETA_lcc  = beta_slope_lcc (i,j);
            AMP_lcc   = amp_slope_lcc (i,j);
            SPL_lcc   = spl_slope_lcc (i,j);
            APL_lcc   = apl_slope_lcc (i,j);
            
            s_co2 = [ALPHA_co2,BETA_co2,AMP_co2,SPL_co2,APL_co2];
            s_cc  = [ALPHA_cc,BETA_cc,AMP_cc,SPL_cc,APL_cc];
            s_lcc = [ALPHA_lcc,BETA_lcc,AMP_lcc,SPL_lcc,APL_lcc];
            
            var = greening_dominant_component_2001_2019 (i,j);
            
            if ~isnan (var)
                
                greening_co2 = s_co2 (var);
                greening_cc  = s_cc (var);
                greening_lcc = s_lcc (var);
                
                greening = [greening_co2,greening_cc,greening_lcc];
                greening_max = find (greening == max (greening));
                
                if greening_max == 1 % co2
                    co2_cc_lcc_dominant_factor (i,j) = 1;
                elseif greening_max == 2 % cc
                    co2_cc_lcc_dominant_factor (i,j) = 2;
                elseif greening_max == 3 % lcc
                    co2_cc_lcc_dominant_factor (i,j) = 3;
                else
                    co2_cc_lcc_dominant_factor (i,j) = nan;
                end
                
                %             elseif var >= 6 && var <= 10 % browning pixel
                %
                %                 browning_co2 = s_co2 (var - 5);
                %                 browning_cc  = s_cc (var - 5);
                %                 browning_lcc = s_lcc (var - 5);
                %
                %                 browning = [browning_co2,browning_cc,browning_lcc];
                %                 browning_min = find (browning == min (browning));
                %
                %                 if browning_min == 1 % co2
                %                     co2_cc_lcc_dominant_factor (i,j) = 4;
                %                 elseif browning_min == 2 % cc
                %                     co2_cc_lcc_dominant_factor (i,j) = 5;
                %                 elseif browning_min == 3 % lcc
                %                     co2_cc_lcc_dominant_factor (i,j) = 6;
                %                 else
                %                     co2_cc_lcc_dominant_factor (i,j) = nan;
                %                 end
                
            else
                co2_cc_lcc_dominant_factor (i,j) = nan;
            end
        else
            co2_cc_lcc_dominant_factor (i,j) = nan;
        end
    end
end

save co2_cc_lcc_dominant_factor co2_cc_lcc_dominant_factor

% convert .mat into tiff files
% filepath = 'D:\decompose LAI\decompose LAI_new_test\s10_Random_Forest\version_for greening_only\s03_random_forest_component_greening_dominant_factor\geoinfo.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('co2_cc_lcc_dominant_factor',co2_cc_lcc_dominant_factor,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);

%% plot spatial patterns
h = imagesc (co2_cc_lcc_dominant_factor);
set(h,'alphadata',~isnan(co2_cc_lcc_dominant_factor))
set(gca, 'color', 'k');
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

% ����ͼ��
% imagesc(data);
colorbar;

% �Զ�����ɫӳ��
% ������ɫ����ÿһ�д���һ����ɫ
cmap = [
    0 0 1;    % ��ɫ - ��Ӧ 1
    0 1 0;    % ��ɫ - ��Ӧ 2
    0 0.5 0;  % ����ɫ - ��Ӧ -2
    ];

% ����ͼ����ʾ�ķ�Χ��������
caxis([1 3]);

% ���� colormap
colormap(cmap);

%
% subplot (2,2,3)
% co2_cc_lcc_dominant_factor = reshape (co2_cc_lcc_dominant_factor,[1,347*720]);
% co2_cc_lcc_dominant_factor (isnan (co2_cc_lcc_dominant_factor)) = [];
%
% a = length (co2_cc_lcc_dominant_factor(co2_cc_lcc_dominant_factor == 2));
% b = length (co2_cc_lcc_dominant_factor(co2_cc_lcc_dominant_factor == 3));
% c = length (co2_cc_lcc_dominant_factor(co2_cc_lcc_dominant_factor == 4));
%
% proportion = [a,b,c];
% pie (proportion)
%
% subplot (2,2,4)
% min_s2s3s4s5_decomposition = reshape (min_s2s3s4s5_decomposition,[1,347*720]);
% min_s2s3s4s5_decomposition (isnan (min_s2s3s4s5_decomposition)) = [];
%
% a = length (min_s2s3s4s5_decomposition(min_s2s3s4s5_decomposition == 2));
% b = length (min_s2s3s4s5_decomposition(min_s2s3s4s5_decomposition == 3));
% c = length (min_s2s3s4s5_decomposition(min_s2s3s4s5_decomposition == 4));
%
% proportion = [a,b,c];
% pie (proportion)