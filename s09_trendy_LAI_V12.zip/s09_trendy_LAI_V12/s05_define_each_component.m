
clear
clc

load('MMEM_LAI_s1_snowfilled_sgfilter.mat')
load('mask_phenological_cycle.mat')
load('MMEM_LAI_s1_PKD_reference.mat')

DOY = 8:15:365;
DOY_3years = [DOY, DOY + 365, DOY + 2 * 365];
DOY_3years_daily = 1:1095;
moving_window = 1:24:433;

MMEM_LAI_s1_ALPHA_2000_2020   = zeros (347,720,19);
MMEM_LAI_s1_BETA_2000_2020    = zeros (347,720,19);
MMEM_LAI_s1_AMP_2000_2020     = zeros (347,720,19);
MMEM_LAI_s1_SPL_2000_2020     = zeros (347,720,19);
MMEM_LAI_s1_APL_2000_2020     = zeros (347,720,19);
MMEM_LAI_s1_LAIgs_2000_2020  = zeros (347,720,19);

for N_year = 1:19
    window_num = moving_window (N_year);
    
    % i = 79; j = 610;
    parfor i = 1:347
        for j = 1:720
            
            mask = mask_phenological_cycle (i,j);
            
            pkd_vi_average = MMEM_LAI_s1_PKD_reference (i,j);
            pkd_vi_average = double (pkd_vi_average);
            
            if mask == 1 % extract by threshold
                
                vi = MMEM_LAI_s1_snowfilled_sgfilter (i,j,:);
                vi = vi (1,:);
                vi = double (vi);
                
                % phenology extraction
                vi_3years = vi (window_num : window_num + 71);
                
                % daily interpolation
                vi_3years_daily = interp1 (DOY_3years,vi_3years,DOY_3years_daily,'spline');
                
                % find 3-cycle peaks
                % find peaks using function: "findpeaks" rather than find maximum
                
                cycle1 = vi_3years_daily (1 : 365);
                cycle2 = vi_3years_daily (366 : 730);
                cycle3 = vi_3years_daily (731 : end);
                
                % to avoid worng recognition, we used the steps below:
                % (1) using "peak date" derived from average 19-year NDVI as a reference
                % (2) defining a valid range of "peak date" (threshold: -60, +60)
                % (3) detecting "peak" and "maxmimum" at the same time
                % (4) and then, to select that one closest to the "peak date" reference
                
                t1 = pkd_vi_average - 60;
                t2 = pkd_vi_average + 60;
                
                if t1 < 1
                    t1 = 1;
                end
                
                if t2 > 365
                    t2 = 365;
                end
                
                % screening the values out of valid range
                cycle1 (1:t1)   = -999;
                cycle1 (t2:end) = -999;
                
                cycle2 (1:t1)   = -999;
                cycle2 (t2:end) = -999;
                
                cycle3 (1:t1)   = -999;
                cycle3 (t2:end) = -999;
                
                [valuePeak_1,positionPeak_1] = findpeaks (cycle1);
                [valueMax_1,positionMax_1]   = find (cycle1 == max (cycle1));
                if isempty (positionPeak_1) % no-peak
                    peak_cycle1 = pkd_vi_average;
                else
                    position_1  = [positionPeak_1,positionMax_1];
                    [~,Index]   = min (abs (position_1 - pkd_vi_average));
                    peak_cycle1 = position_1 (Index);
                end
                
                [valuePeak_2,positionPeak_2] = findpeaks (cycle2);
                [valueMax_2,positionMax_2]   = find (cycle2 == max (cycle2));
                if isempty (positionPeak_2) % no-peak
                    peak_cycle2 = pkd_vi_average + 365;
                else
                    position_2  = [positionPeak_2,positionMax_2];
                    [~,Index]   = min (abs (position_2 - pkd_vi_average));
                    peak_cycle2 = position_2 (Index) + 365;
                end
                
                [valuePeak_3,positionPeak_3] = findpeaks (cycle3);
                [valueMax_3,positionMax_3]   = find (cycle3 == max (cycle3));
                if isempty (positionPeak_3) % no-peak
                    peak_cycle3 = pkd_vi_average + 2 * 365;
                else
                    position_3  = [positionPeak_3,positionMax_3];
                    [~,Index]   = min (abs (position_3 - pkd_vi_average));
                    peak_cycle3 = position_3 (Index) + 2 * 365;
                end
                
                % find target-cycle (cycle2) bottoms
                left_cycle  = vi_3years_daily (peak_cycle1:peak_cycle2);
                right_cycle = vi_3years_daily (peak_cycle2:peak_cycle3);
                
                left_bottom  = find (left_cycle == min (left_cycle)) + peak_cycle1 - 1;
                left_bottom  = left_bottom (1);
                
                right_bottom = find (right_cycle == min (right_cycle)) + peak_cycle2 - 1;
                right_bottom = right_bottom (1);
                
                vi_used = vi_3years_daily (left_bottom:right_bottom);
                
                % extract phenological metrics
                % divide greening and senescence timeseries
                peak = find (vi_used == max (vi_used));
                peak = peak (1);
                
                vi_greening   = vi_used (1:peak);
                vi_senescence = vi_used (peak:end);
                
                % find max and min
                peak_value = max (vi_used);
                min_greening   = min (vi_greening);
                min_senescence = min (vi_senescence);
                
                % define SOS and EOS using threshold: 15%
                amp_greening   = peak_value - min_greening;
                amp_senescence = peak_value - min_senescence;
                
                vi_greening_ratio   = (vi_greening - min_greening)/amp_greening;
                vi_senescence_ratio = (vi_senescence - min_senescence)/amp_senescence;
                
                % values lower than 0: phenology oocurs in the previous year
                % values larger than 365: phenology oocurs in the next year
                
                sos = find (vi_greening_ratio >= 0.15);
                eos = find (vi_senescence_ratio >= 0.15);
                
                if ~isempty (sos) && ~isempty (eos)
                    
                    sos_vi_used = sos (1);
                    sos = sos (1) + left_bottom;
                    
                    eos_vi_used = eos (end) + peak - 1;
                    eos = eos (end) + peak - 1 + left_bottom;
                    
                    pos = peak_cycle2;
                    amp = vi_3years_daily (pos);
                    spl = pos - sos;
                    apl = eos - pos;
                    alpha = sum(vi_3years_daily (1,sos:pos))/(spl*amp);
                    beta  = sum(vi_3years_daily (1,pos+1:eos))/(apl*amp);
                    NDVI = sum (vi_3years_daily (sos:eos));
                    
                    MMEM_LAI_s1_SPL_2000_2020 (i,j,N_year)     = spl;
                    MMEM_LAI_s1_APL_2000_2020 (i,j,N_year)     = apl;
                    MMEM_LAI_s1_ALPHA_2000_2020 (i,j,N_year)   = alpha;
                    MMEM_LAI_s1_BETA_2000_2020 (i,j,N_year)    = beta;
                    MMEM_LAI_s1_AMP_2000_2020 (i,j,N_year)     = amp;
                    MMEM_LAI_s1_LAIgs_2000_2020 (i,j,N_year)   = NDVI;
                    
                else
                    
                    MMEM_LAI_s1_SPL_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s1_APL_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s1_ALPHA_2000_2020 (i,j,N_year)   = nan;
                    MMEM_LAI_s1_BETA_2000_2020 (i,j,N_year)    = nan;
                    MMEM_LAI_s1_AMP_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s1_LAIgs_2000_2020 (i,j,N_year)   = nan;
                    
                end
                
                %             elseif mask == 0 % extract by all seasons
                %
                %                 vi = MMEM_LAI_s1_snowfilled_sgfilter (i,j,:);
                %                 vi = vi (1,:);
                %                 vi = double (vi);
                %
                %                 % phenology extraction
                %                 vi_3years = vi (window_num : window_num + 71);
                %
                %                 % daily interpolation
                %                 vi_3years_daily = interp1 (DOY_3years,vi_3years,DOY_3years_daily,'spline');
                %
                %                 % find 3-cycle peaks
                %                 % find peaks using function: "findpeaks" rather than find maximum
                %
                %                 cycle1 = vi_3years_daily (1 : 365);
                %                 cycle2 = vi_3years_daily (366 : 730);
                %                 cycle3 = vi_3years_daily (731 : end);
                %
                %                 % to avoid worng recognition, we used the steps below:
                %                 % (1) using "peak date" derived from average 32-year NDVI as a reference
                %                 % (2) defining a valid range of "peak date" (threshold: -60, +60)
                %                 % (3) detecting "peak" and "maxmimum" at the same time
                %                 % (4) and then, to select that one closest to the "peak date" reference
                %
                %                 %                 t1 = pkd_vi_average - 60;
                %                 %                 t2 = pkd_vi_average + 60;
                %                 %
                %                 %                 if t1 < 1
                %                 %                     t1 = 1;
                %                 %                 end
                %                 %
                %                 %                 if t2 > 365
                %                 %                     t2 = 365;
                %                 %                 end
                %                 %
                %                 %                 % screening the values out of valid range
                %                 %                 cycle1 (1:t1)   = -999;
                %                 %                 cycle1 (t2:end) = -999;
                %                 %
                %                 %                 cycle2 (1:t1)   = -999;
                %                 %                 cycle2 (t2:end) = -999;
                %                 %
                %                 %                 cycle3 (1:t1)   = -999;
                %                 %                 cycle3 (t2:end) = -999;
                %                 %
                %                 %                 [valuePeak_1,positionPeak_1] = findpeaks (cycle1);
                %                 %                 [valueMax_1,positionMax_1]   = find (cycle1 == max (cycle1));
                %                 %                 if isempty (positionPeak_1) % no-peak
                %                 %                     peak_cycle1 = pkd_vi_average;
                %                 %                 else
                %                 %                     position_1  = [positionPeak_1,positionMax_1];
                %                 %                     [~,Index]   = min (abs (position_1 - pkd_vi_average));
                %                 %                     peak_cycle1 = position_1 (Index);
                %                 %                 end
                %                 %
                %                 %                 [valuePeak_2,positionPeak_2] = findpeaks (cycle2);
                %                 %                 [valueMax_2,positionMax_2]   = find (cycle2 == max (cycle2));
                %                 %                 if isempty (positionPeak_2) % no-peak
                %                 %                     peak_cycle2 = pkd_vi_average + 365;
                %                 %                 else
                %                 %                     position_2  = [positionPeak_2,positionMax_2];
                %                 %                     [~,Index]   = min (abs (position_2 - pkd_vi_average));
                %                 %                     peak_cycle2 = position_2 (Index) + 365;
                %                 %                 end
                %                 %
                %                 %                 [valuePeak_3,positionPeak_3] = findpeaks (cycle3);
                %                 %                 [valueMax_3,positionMax_3]   = find (cycle3 == max (cycle3));
                %                 %                 if isempty (positionPeak_3) % no-peak
                %                 %                     peak_cycle3 = pkd_vi_average + 2 * 365;
                %                 %                 else
                %                 %                     position_3  = [positionPeak_3,positionMax_3];
                %                 %                     [~,Index]   = min (abs (position_3 - pkd_vi_average));
                %                 %                     peak_cycle3 = position_3 (Index) + 2 * 365;
                %                 %                 end
                %                 %
                %                 %                 % find target-cycle (cycle2) bottoms
                %                 %                 left_cycle  = vi_3years_daily (peak_cycle1:peak_cycle2);
                %                 %                 right_cycle = vi_3years_daily (peak_cycle2:peak_cycle3);
                %                 %
                %                 %                 left_bottom  = find (left_cycle == min (left_cycle)) + peak_cycle1 - 1;
                %                 %                 left_bottom  = left_bottom (1);
                %                 %
                %                 %                 right_bottom = find (right_cycle == min (right_cycle)) + peak_cycle2 - 1;
                %                 %                 right_bottom = right_bottom (1);
                %                 %
                %                 %                 vi_used = vi_3years_daily (left_bottom:right_bottom);
                %
                %                 % extract phenological metrics
                %                 % divide greening and senescence timeseries
                %                 peak = find (cycle2 == max (cycle2));
                %                 peak = peak (1);
                %
                %                 % vi_greening   = cycle2 (1:peak);
                %                 % vi_senescence = cycle2 (peak:end);
                %
                %                 sos = 1;
                %                 eos = 365;
                %
                %                 NDVI = sum (cycle2 (sos:eos));
                %
                %                 MMEM_LAI_s1_SOS_2000_2020 (i,j,N_year)     = sos + 365;
                %                 MMEM_LAI_s1_EOS_2000_2020 (i,j,N_year)     = eos + 365;
                %                 MMEM_LAI_s1_POS_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s1_SPL_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s1_APL_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s1_ALPHA_2000_2020 (i,j,N_year)   = nan;
                %                 MMEM_LAI_s1_BETA_2000_2020 (i,j,N_year)    = nan;
                %                 MMEM_LAI_s1_AMP_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s1_LAIgs_2000_2020 (i,j,N_year)   = NDVI;
                %                 MMEM_LAI_s1_NDVImean_2000_2020 (i,j,N_year) = NDVI/365;
                
            else
                
                MMEM_LAI_s1_SPL_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s1_APL_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s1_ALPHA_2000_2020 (i,j,N_year)   = nan;
                MMEM_LAI_s1_BETA_2000_2020 (i,j,N_year)    = nan;
                MMEM_LAI_s1_AMP_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s1_LAIgs_2000_2020 (i,j,N_year)  = nan;
                
            end
        end
    end
end

save MMEM_LAI_s1_SPL_2000_2020 MMEM_LAI_s1_SPL_2000_2020
save MMEM_LAI_s1_APL_2000_2020 MMEM_LAI_s1_APL_2000_2020
save MMEM_LAI_s1_ALPHA_2000_2020 MMEM_LAI_s1_ALPHA_2000_2020
save MMEM_LAI_s1_BETA_2000_2020 MMEM_LAI_s1_BETA_2000_2020
save MMEM_LAI_s1_AMP_2000_2020 MMEM_LAI_s1_AMP_2000_2020
save MMEM_LAI_s1_LAIgs_2000_2020 MMEM_LAI_s1_LAIgs_2000_2020

% % convert .mat into tiff files
% filepath = 'D:\decompose LAI\s08_define_each_component\geoinfo.tif';
% [Data, R] = geotiffread(filepath);
% info = geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s1_SOS_2000_2020', MMEM_LAI_s1_SOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_EOS_2000_2020', MMEM_LAI_s1_EOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_POS_2000_2020', MMEM_LAI_s1_POS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_SPL_2000_2020', MMEM_LAI_s1_SPL_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_APL_2000_2020', MMEM_LAI_s1_APL_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_ALPHA_2000_2020', MMEM_LAI_s1_ALPHA_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_BETA_2000_2020', MMEM_LAI_s1_BETA_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_AMP_2000_2020', MMEM_LAI_s1_AMP_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_EOS_2000_2020', MMEM_LAI_s1_EOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_LAIgs_2000_2020', MMEM_LAI_s1_LAIgs_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);


clear
clc

load('MMEM_LAI_s2_snowfilled_sgfilter.mat')
load('mask_phenological_cycle.mat')
load('MMEM_LAI_s2_PKD_reference.mat')

DOY = 8:15:365;
DOY_3years = [DOY, DOY + 365, DOY + 2 * 365];
DOY_3years_daily = 1:1095;
moving_window = 1:24:433;

MMEM_LAI_s2_ALPHA_2000_2020   = zeros (347,720,19);
MMEM_LAI_s2_BETA_2000_2020    = zeros (347,720,19);
MMEM_LAI_s2_AMP_2000_2020     = zeros (347,720,19);
MMEM_LAI_s2_SPL_2000_2020     = zeros (347,720,19);
MMEM_LAI_s2_APL_2000_2020     = zeros (347,720,19);
MMEM_LAI_s2_LAIgs_2000_2020  = zeros (347,720,19);

for N_year = 1:19
    window_num = moving_window (N_year);
    
    % i = 79; j = 610;
    parfor i = 1:347
        for j = 1:720
            
            mask = mask_phenological_cycle (i,j);
            
            pkd_vi_average = MMEM_LAI_s2_PKD_reference (i,j);
            pkd_vi_average = double (pkd_vi_average);
            
            if mask == 1 % extract by threshold
                
                vi = MMEM_LAI_s2_snowfilled_sgfilter (i,j,:);
                vi = vi (1,:);
                vi = double (vi);
                
                % phenology extraction
                vi_3years = vi (window_num : window_num + 71);
                
                % daily interpolation
                vi_3years_daily = interp1 (DOY_3years,vi_3years,DOY_3years_daily,'spline');
                
                % find 3-cycle peaks
                % find peaks using function: "findpeaks" rather than find maximum
                
                cycle1 = vi_3years_daily (1 : 365);
                cycle2 = vi_3years_daily (366 : 730);
                cycle3 = vi_3years_daily (731 : end);
                
                % to avoid worng recognition, we used the steps below:
                % (1) using "peak date" derived from average 19-year NDVI as a reference
                % (2) defining a valid range of "peak date" (threshold: -60, +60)
                % (3) detecting "peak" and "maxmimum" at the same time
                % (4) and then, to select that one closest to the "peak date" reference
                
                t1 = pkd_vi_average - 60;
                t2 = pkd_vi_average + 60;
                
                if t1 < 1
                    t1 = 1;
                end
                
                if t2 > 365
                    t2 = 365;
                end
                
                % screening the values out of valid range
                cycle1 (1:t1)   = -999;
                cycle1 (t2:end) = -999;
                
                cycle2 (1:t1)   = -999;
                cycle2 (t2:end) = -999;
                
                cycle3 (1:t1)   = -999;
                cycle3 (t2:end) = -999;
                
                [valuePeak_1,positionPeak_1] = findpeaks (cycle1);
                [valueMax_1,positionMax_1]   = find (cycle1 == max (cycle1));
                if isempty (positionPeak_1) % no-peak
                    peak_cycle1 = pkd_vi_average;
                else
                    position_1  = [positionPeak_1,positionMax_1];
                    [~,Index]   = min (abs (position_1 - pkd_vi_average));
                    peak_cycle1 = position_1 (Index);
                end
                
                [valuePeak_2,positionPeak_2] = findpeaks (cycle2);
                [valueMax_2,positionMax_2]   = find (cycle2 == max (cycle2));
                if isempty (positionPeak_2) % no-peak
                    peak_cycle2 = pkd_vi_average + 365;
                else
                    position_2  = [positionPeak_2,positionMax_2];
                    [~,Index]   = min (abs (position_2 - pkd_vi_average));
                    peak_cycle2 = position_2 (Index) + 365;
                end
                
                [valuePeak_3,positionPeak_3] = findpeaks (cycle3);
                [valueMax_3,positionMax_3]   = find (cycle3 == max (cycle3));
                if isempty (positionPeak_3) % no-peak
                    peak_cycle3 = pkd_vi_average + 2 * 365;
                else
                    position_3  = [positionPeak_3,positionMax_3];
                    [~,Index]   = min (abs (position_3 - pkd_vi_average));
                    peak_cycle3 = position_3 (Index) + 2 * 365;
                end
                
                % find target-cycle (cycle2) bottoms
                left_cycle  = vi_3years_daily (peak_cycle1:peak_cycle2);
                right_cycle = vi_3years_daily (peak_cycle2:peak_cycle3);
                
                left_bottom  = find (left_cycle == min (left_cycle)) + peak_cycle1 - 1;
                left_bottom  = left_bottom (1);
                
                right_bottom = find (right_cycle == min (right_cycle)) + peak_cycle2 - 1;
                right_bottom = right_bottom (1);
                
                vi_used = vi_3years_daily (left_bottom:right_bottom);
                
                % extract phenological metrics
                % divide greening and senescence timeseries
                peak = find (vi_used == max (vi_used));
                peak = peak (1);
                
                vi_greening   = vi_used (1:peak);
                vi_senescence = vi_used (peak:end);
                
                % find max and min
                peak_value = max (vi_used);
                min_greening   = min (vi_greening);
                min_senescence = min (vi_senescence);
                
                % define SOS and EOS using threshold: 15%
                amp_greening   = peak_value - min_greening;
                amp_senescence = peak_value - min_senescence;
                
                vi_greening_ratio   = (vi_greening - min_greening)/amp_greening;
                vi_senescence_ratio = (vi_senescence - min_senescence)/amp_senescence;
                
                % values lower than 0: phenology oocurs in the previous year
                % values larger than 365: phenology oocurs in the next year
                
                sos = find (vi_greening_ratio >= 0.15);
                eos = find (vi_senescence_ratio >= 0.15);
                
                if ~isempty (sos) && ~isempty (eos)
                    
                    sos_vi_used = sos (1);
                    sos = sos (1) + left_bottom;
                    
                    eos_vi_used = eos (end) + peak - 1;
                    eos = eos (end) + peak - 1 + left_bottom;
                    
                    pos = peak_cycle2;
                    amp = vi_3years_daily (pos);
                    spl = pos - sos;
                    apl = eos - pos;
                    alpha = sum(vi_3years_daily (1,sos:pos))/(spl*amp);
                    beta  = sum(vi_3years_daily (1,pos+1:eos))/(apl*amp);
                    NDVI = sum (vi_3years_daily (sos:eos));
                    
                    MMEM_LAI_s2_SPL_2000_2020 (i,j,N_year)     = spl;
                    MMEM_LAI_s2_APL_2000_2020 (i,j,N_year)     = apl;
                    MMEM_LAI_s2_ALPHA_2000_2020 (i,j,N_year)   = alpha;
                    MMEM_LAI_s2_BETA_2000_2020 (i,j,N_year)    = beta;
                    MMEM_LAI_s2_AMP_2000_2020 (i,j,N_year)     = amp;
                    MMEM_LAI_s2_LAIgs_2000_2020 (i,j,N_year)   = NDVI;
                    
                else
                    
                    MMEM_LAI_s2_SPL_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s2_APL_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s2_ALPHA_2000_2020 (i,j,N_year)   = nan;
                    MMEM_LAI_s2_BETA_2000_2020 (i,j,N_year)    = nan;
                    MMEM_LAI_s2_AMP_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s2_LAIgs_2000_2020 (i,j,N_year)   = nan;
                    
                end
                
                %             elseif mask == 0 % extract by all seasons
                %
                %                 vi = MMEM_LAI_s2_snowfilled_sgfilter (i,j,:);
                %                 vi = vi (1,:);
                %                 vi = double (vi);
                %
                %                 % phenology extraction
                %                 vi_3years = vi (window_num : window_num + 71);
                %
                %                 % daily interpolation
                %                 vi_3years_daily = interp1 (DOY_3years,vi_3years,DOY_3years_daily,'spline');
                %
                %                 % find 3-cycle peaks
                %                 % find peaks using function: "findpeaks" rather than find maximum
                %
                %                 cycle1 = vi_3years_daily (1 : 365);
                %                 cycle2 = vi_3years_daily (366 : 730);
                %                 cycle3 = vi_3years_daily (731 : end);
                %
                %                 % to avoid worng recognition, we used the steps below:
                %                 % (1) using "peak date" derived from average 32-year NDVI as a reference
                %                 % (2) defining a valid range of "peak date" (threshold: -60, +60)
                %                 % (3) detecting "peak" and "maxmimum" at the same time
                %                 % (4) and then, to select that one closest to the "peak date" reference
                %
                %                 %                 t1 = pkd_vi_average - 60;
                %                 %                 t2 = pkd_vi_average + 60;
                %                 %
                %                 %                 if t1 < 1
                %                 %                     t1 = 1;
                %                 %                 end
                %                 %
                %                 %                 if t2 > 365
                %                 %                     t2 = 365;
                %                 %                 end
                %                 %
                %                 %                 % screening the values out of valid range
                %                 %                 cycle1 (1:t1)   = -999;
                %                 %                 cycle1 (t2:end) = -999;
                %                 %
                %                 %                 cycle2 (1:t1)   = -999;
                %                 %                 cycle2 (t2:end) = -999;
                %                 %
                %                 %                 cycle3 (1:t1)   = -999;
                %                 %                 cycle3 (t2:end) = -999;
                %                 %
                %                 %                 [valuePeak_1,positionPeak_1] = findpeaks (cycle1);
                %                 %                 [valueMax_1,positionMax_1]   = find (cycle1 == max (cycle1));
                %                 %                 if isempty (positionPeak_1) % no-peak
                %                 %                     peak_cycle1 = pkd_vi_average;
                %                 %                 else
                %                 %                     position_1  = [positionPeak_1,positionMax_1];
                %                 %                     [~,Index]   = min (abs (position_1 - pkd_vi_average));
                %                 %                     peak_cycle1 = position_1 (Index);
                %                 %                 end
                %                 %
                %                 %                 [valuePeak_2,positionPeak_2] = findpeaks (cycle2);
                %                 %                 [valueMax_2,positionMax_2]   = find (cycle2 == max (cycle2));
                %                 %                 if isempty (positionPeak_2) % no-peak
                %                 %                     peak_cycle2 = pkd_vi_average + 365;
                %                 %                 else
                %                 %                     position_2  = [positionPeak_2,positionMax_2];
                %                 %                     [~,Index]   = min (abs (position_2 - pkd_vi_average));
                %                 %                     peak_cycle2 = position_2 (Index) + 365;
                %                 %                 end
                %                 %
                %                 %                 [valuePeak_3,positionPeak_3] = findpeaks (cycle3);
                %                 %                 [valueMax_3,positionMax_3]   = find (cycle3 == max (cycle3));
                %                 %                 if isempty (positionPeak_3) % no-peak
                %                 %                     peak_cycle3 = pkd_vi_average + 2 * 365;
                %                 %                 else
                %                 %                     position_3  = [positionPeak_3,positionMax_3];
                %                 %                     [~,Index]   = min (abs (position_3 - pkd_vi_average));
                %                 %                     peak_cycle3 = position_3 (Index) + 2 * 365;
                %                 %                 end
                %                 %
                %                 %                 % find target-cycle (cycle2) bottoms
                %                 %                 left_cycle  = vi_3years_daily (peak_cycle1:peak_cycle2);
                %                 %                 right_cycle = vi_3years_daily (peak_cycle2:peak_cycle3);
                %                 %
                %                 %                 left_bottom  = find (left_cycle == min (left_cycle)) + peak_cycle1 - 1;
                %                 %                 left_bottom  = left_bottom (1);
                %                 %
                %                 %                 right_bottom = find (right_cycle == min (right_cycle)) + peak_cycle2 - 1;
                %                 %                 right_bottom = right_bottom (1);
                %                 %
                %                 %                 vi_used = vi_3years_daily (left_bottom:right_bottom);
                %
                %                 % extract phenological metrics
                %                 % divide greening and senescence timeseries
                %                 peak = find (cycle2 == max (cycle2));
                %                 peak = peak (1);
                %
                %                 % vi_greening   = cycle2 (1:peak);
                %                 % vi_senescence = cycle2 (peak:end);
                %
                %                 sos = 1;
                %                 eos = 365;
                %
                %                 NDVI = sum (cycle2 (sos:eos));
                %
                %                 MMEM_LAI_s2_SOS_2000_2020 (i,j,N_year)     = sos + 365;
                %                 MMEM_LAI_s2_EOS_2000_2020 (i,j,N_year)     = eos + 365;
                %                 MMEM_LAI_s2_POS_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s2_SPL_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s2_APL_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s2_ALPHA_2000_2020 (i,j,N_year)   = nan;
                %                 MMEM_LAI_s2_BETA_2000_2020 (i,j,N_year)    = nan;
                %                 MMEM_LAI_s2_AMP_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s2_LAIgs_2000_2020 (i,j,N_year)   = NDVI;
                %                 MMEM_LAI_s2_NDVImean_2000_2020 (i,j,N_year) = NDVI/365;
                
            else
                
                MMEM_LAI_s2_SPL_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s2_APL_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s2_ALPHA_2000_2020 (i,j,N_year)   = nan;
                MMEM_LAI_s2_BETA_2000_2020 (i,j,N_year)    = nan;
                MMEM_LAI_s2_AMP_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s2_LAIgs_2000_2020 (i,j,N_year)  = nan;
                
            end
        end
    end
end

save MMEM_LAI_s2_SPL_2000_2020 MMEM_LAI_s2_SPL_2000_2020
save MMEM_LAI_s2_APL_2000_2020 MMEM_LAI_s2_APL_2000_2020
save MMEM_LAI_s2_ALPHA_2000_2020 MMEM_LAI_s2_ALPHA_2000_2020
save MMEM_LAI_s2_BETA_2000_2020 MMEM_LAI_s2_BETA_2000_2020
save MMEM_LAI_s2_AMP_2000_2020 MMEM_LAI_s2_AMP_2000_2020
save MMEM_LAI_s2_LAIgs_2000_2020 MMEM_LAI_s2_LAIgs_2000_2020

% % convert .mat into tiff files
% filepath = 'D:\decompose LAI\s08_define_each_component\geoinfo.tif';
% [Data, R] = geotiffread(filepath);
% info = geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s2_SOS_2000_2020', MMEM_LAI_s2_SOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_EOS_2000_2020', MMEM_LAI_s2_EOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_POS_2000_2020', MMEM_LAI_s2_POS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_SPL_2000_2020', MMEM_LAI_s2_SPL_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_APL_2000_2020', MMEM_LAI_s2_APL_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_ALPHA_2000_2020', MMEM_LAI_s2_ALPHA_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_BETA_2000_2020', MMEM_LAI_s2_BETA_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_AMP_2000_2020', MMEM_LAI_s2_AMP_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_EOS_2000_2020', MMEM_LAI_s2_EOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_LAIgs_2000_2020', MMEM_LAI_s2_LAIgs_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);


clear
clc

load('MMEM_LAI_s3_snowfilled_sgfilter.mat')
load('mask_phenological_cycle.mat')
load('MMEM_LAI_s3_PKD_reference.mat')

DOY = 8:15:365;
DOY_3years = [DOY, DOY + 365, DOY + 2 * 365];
DOY_3years_daily = 1:1095;
moving_window = 1:24:433;

MMEM_LAI_s3_ALPHA_2000_2020   = zeros (347,720,19);
MMEM_LAI_s3_BETA_2000_2020    = zeros (347,720,19);
MMEM_LAI_s3_AMP_2000_2020     = zeros (347,720,19);
MMEM_LAI_s3_SPL_2000_2020     = zeros (347,720,19);
MMEM_LAI_s3_APL_2000_2020     = zeros (347,720,19);
MMEM_LAI_s3_LAIgs_2000_2020  = zeros (347,720,19);

for N_year = 1:19
    window_num = moving_window (N_year);
    
    % i = 79; j = 610;
    parfor i = 1:347
        for j = 1:720
            
            mask = mask_phenological_cycle (i,j);
            
            pkd_vi_average = MMEM_LAI_s3_PKD_reference (i,j);
            pkd_vi_average = double (pkd_vi_average);
            
            if mask == 1 % extract by threshold
                
                vi = MMEM_LAI_s3_snowfilled_sgfilter (i,j,:);
                vi = vi (1,:);
                vi = double (vi);
                
                % phenology extraction
                vi_3years = vi (window_num : window_num + 71);
                
                % daily interpolation
                vi_3years_daily = interp1 (DOY_3years,vi_3years,DOY_3years_daily,'spline');
                
                % find 3-cycle peaks
                % find peaks using function: "findpeaks" rather than find maximum
                
                cycle1 = vi_3years_daily (1 : 365);
                cycle2 = vi_3years_daily (366 : 730);
                cycle3 = vi_3years_daily (731 : end);
                
                % to avoid worng recognition, we used the steps below:
                % (1) using "peak date" derived from average 19-year NDVI as a reference
                % (2) defining a valid range of "peak date" (threshold: -60, +60)
                % (3) detecting "peak" and "maxmimum" at the same time
                % (4) and then, to select that one closest to the "peak date" reference
                
                t1 = pkd_vi_average - 60;
                t2 = pkd_vi_average + 60;
                
                if t1 < 1
                    t1 = 1;
                end
                
                if t2 > 365
                    t2 = 365;
                end
                
                % screening the values out of valid range
                cycle1 (1:t1)   = -999;
                cycle1 (t2:end) = -999;
                
                cycle2 (1:t1)   = -999;
                cycle2 (t2:end) = -999;
                
                cycle3 (1:t1)   = -999;
                cycle3 (t2:end) = -999;
                
                [valuePeak_1,positionPeak_1] = findpeaks (cycle1);
                [valueMax_1,positionMax_1]   = find (cycle1 == max (cycle1));
                if isempty (positionPeak_1) % no-peak
                    peak_cycle1 = pkd_vi_average;
                else
                    position_1  = [positionPeak_1,positionMax_1];
                    [~,Index]   = min (abs (position_1 - pkd_vi_average));
                    peak_cycle1 = position_1 (Index);
                end
                
                [valuePeak_2,positionPeak_2] = findpeaks (cycle2);
                [valueMax_2,positionMax_2]   = find (cycle2 == max (cycle2));
                if isempty (positionPeak_2) % no-peak
                    peak_cycle2 = pkd_vi_average + 365;
                else
                    position_2  = [positionPeak_2,positionMax_2];
                    [~,Index]   = min (abs (position_2 - pkd_vi_average));
                    peak_cycle2 = position_2 (Index) + 365;
                end
                
                [valuePeak_3,positionPeak_3] = findpeaks (cycle3);
                [valueMax_3,positionMax_3]   = find (cycle3 == max (cycle3));
                if isempty (positionPeak_3) % no-peak
                    peak_cycle3 = pkd_vi_average + 2 * 365;
                else
                    position_3  = [positionPeak_3,positionMax_3];
                    [~,Index]   = min (abs (position_3 - pkd_vi_average));
                    peak_cycle3 = position_3 (Index) + 2 * 365;
                end
                
                % find target-cycle (cycle2) bottoms
                left_cycle  = vi_3years_daily (peak_cycle1:peak_cycle2);
                right_cycle = vi_3years_daily (peak_cycle2:peak_cycle3);
                
                left_bottom  = find (left_cycle == min (left_cycle)) + peak_cycle1 - 1;
                left_bottom  = left_bottom (1);
                
                right_bottom = find (right_cycle == min (right_cycle)) + peak_cycle2 - 1;
                right_bottom = right_bottom (1);
                
                vi_used = vi_3years_daily (left_bottom:right_bottom);
                
                % extract phenological metrics
                % divide greening and senescence timeseries
                peak = find (vi_used == max (vi_used));
                peak = peak (1);
                
                vi_greening   = vi_used (1:peak);
                vi_senescence = vi_used (peak:end);
                
                % find max and min
                peak_value = max (vi_used);
                min_greening   = min (vi_greening);
                min_senescence = min (vi_senescence);
                
                % define SOS and EOS using threshold: 15%
                amp_greening   = peak_value - min_greening;
                amp_senescence = peak_value - min_senescence;
                
                vi_greening_ratio   = (vi_greening - min_greening)/amp_greening;
                vi_senescence_ratio = (vi_senescence - min_senescence)/amp_senescence;
                
                % values lower than 0: phenology oocurs in the previous year
                % values larger than 365: phenology oocurs in the next year
                
                sos = find (vi_greening_ratio >= 0.15);
                eos = find (vi_senescence_ratio >= 0.15);
                
                if ~isempty (sos) && ~isempty (eos)
                    
                    sos_vi_used = sos (1);
                    sos = sos (1) + left_bottom;
                    
                    eos_vi_used = eos (end) + peak - 1;
                    eos = eos (end) + peak - 1 + left_bottom;
                    
                    pos = peak_cycle2;
                    amp = vi_3years_daily (pos);
                    spl = pos - sos;
                    apl = eos - pos;
                    alpha = sum(vi_3years_daily (1,sos:pos))/(spl*amp);
                    beta  = sum(vi_3years_daily (1,pos+1:eos))/(apl*amp);
                    NDVI = sum (vi_3years_daily (sos:eos));
                    
                    MMEM_LAI_s3_SPL_2000_2020 (i,j,N_year)     = spl;
                    MMEM_LAI_s3_APL_2000_2020 (i,j,N_year)     = apl;
                    MMEM_LAI_s3_ALPHA_2000_2020 (i,j,N_year)   = alpha;
                    MMEM_LAI_s3_BETA_2000_2020 (i,j,N_year)    = beta;
                    MMEM_LAI_s3_AMP_2000_2020 (i,j,N_year)     = amp;
                    MMEM_LAI_s3_LAIgs_2000_2020 (i,j,N_year)   = NDVI;
                    
                else
                    
                    MMEM_LAI_s3_SPL_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s3_APL_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s3_ALPHA_2000_2020 (i,j,N_year)   = nan;
                    MMEM_LAI_s3_BETA_2000_2020 (i,j,N_year)    = nan;
                    MMEM_LAI_s3_AMP_2000_2020 (i,j,N_year)     = nan;
                    MMEM_LAI_s3_LAIgs_2000_2020 (i,j,N_year)   = nan;
                    
                end
                
                %             elseif mask == 0 % extract by all seasons
                %
                %                 vi = MMEM_LAI_s3_snowfilled_sgfilter (i,j,:);
                %                 vi = vi (1,:);
                %                 vi = double (vi);
                %
                %                 % phenology extraction
                %                 vi_3years = vi (window_num : window_num + 71);
                %
                %                 % daily interpolation
                %                 vi_3years_daily = interp1 (DOY_3years,vi_3years,DOY_3years_daily,'spline');
                %
                %                 % find 3-cycle peaks
                %                 % find peaks using function: "findpeaks" rather than find maximum
                %
                %                 cycle1 = vi_3years_daily (1 : 365);
                %                 cycle2 = vi_3years_daily (366 : 730);
                %                 cycle3 = vi_3years_daily (731 : end);
                %
                %                 % to avoid worng recognition, we used the steps below:
                %                 % (1) using "peak date" derived from average 32-year NDVI as a reference
                %                 % (2) defining a valid range of "peak date" (threshold: -60, +60)
                %                 % (3) detecting "peak" and "maxmimum" at the same time
                %                 % (4) and then, to select that one closest to the "peak date" reference
                %
                %                 %                 t1 = pkd_vi_average - 60;
                %                 %                 t2 = pkd_vi_average + 60;
                %                 %
                %                 %                 if t1 < 1
                %                 %                     t1 = 1;
                %                 %                 end
                %                 %
                %                 %                 if t2 > 365
                %                 %                     t2 = 365;
                %                 %                 end
                %                 %
                %                 %                 % screening the values out of valid range
                %                 %                 cycle1 (1:t1)   = -999;
                %                 %                 cycle1 (t2:end) = -999;
                %                 %
                %                 %                 cycle2 (1:t1)   = -999;
                %                 %                 cycle2 (t2:end) = -999;
                %                 %
                %                 %                 cycle3 (1:t1)   = -999;
                %                 %                 cycle3 (t2:end) = -999;
                %                 %
                %                 %                 [valuePeak_1,positionPeak_1] = findpeaks (cycle1);
                %                 %                 [valueMax_1,positionMax_1]   = find (cycle1 == max (cycle1));
                %                 %                 if isempty (positionPeak_1) % no-peak
                %                 %                     peak_cycle1 = pkd_vi_average;
                %                 %                 else
                %                 %                     position_1  = [positionPeak_1,positionMax_1];
                %                 %                     [~,Index]   = min (abs (position_1 - pkd_vi_average));
                %                 %                     peak_cycle1 = position_1 (Index);
                %                 %                 end
                %                 %
                %                 %                 [valuePeak_2,positionPeak_2] = findpeaks (cycle2);
                %                 %                 [valueMax_2,positionMax_2]   = find (cycle2 == max (cycle2));
                %                 %                 if isempty (positionPeak_2) % no-peak
                %                 %                     peak_cycle2 = pkd_vi_average + 365;
                %                 %                 else
                %                 %                     position_2  = [positionPeak_2,positionMax_2];
                %                 %                     [~,Index]   = min (abs (position_2 - pkd_vi_average));
                %                 %                     peak_cycle2 = position_2 (Index) + 365;
                %                 %                 end
                %                 %
                %                 %                 [valuePeak_3,positionPeak_3] = findpeaks (cycle3);
                %                 %                 [valueMax_3,positionMax_3]   = find (cycle3 == max (cycle3));
                %                 %                 if isempty (positionPeak_3) % no-peak
                %                 %                     peak_cycle3 = pkd_vi_average + 2 * 365;
                %                 %                 else
                %                 %                     position_3  = [positionPeak_3,positionMax_3];
                %                 %                     [~,Index]   = min (abs (position_3 - pkd_vi_average));
                %                 %                     peak_cycle3 = position_3 (Index) + 2 * 365;
                %                 %                 end
                %                 %
                %                 %                 % find target-cycle (cycle2) bottoms
                %                 %                 left_cycle  = vi_3years_daily (peak_cycle1:peak_cycle2);
                %                 %                 right_cycle = vi_3years_daily (peak_cycle2:peak_cycle3);
                %                 %
                %                 %                 left_bottom  = find (left_cycle == min (left_cycle)) + peak_cycle1 - 1;
                %                 %                 left_bottom  = left_bottom (1);
                %                 %
                %                 %                 right_bottom = find (right_cycle == min (right_cycle)) + peak_cycle2 - 1;
                %                 %                 right_bottom = right_bottom (1);
                %                 %
                %                 %                 vi_used = vi_3years_daily (left_bottom:right_bottom);
                %
                %                 % extract phenological metrics
                %                 % divide greening and senescence timeseries
                %                 peak = find (cycle2 == max (cycle2));
                %                 peak = peak (1);
                %
                %                 % vi_greening   = cycle2 (1:peak);
                %                 % vi_senescence = cycle2 (peak:end);
                %
                %                 sos = 1;
                %                 eos = 365;
                %
                %                 NDVI = sum (cycle2 (sos:eos));
                %
                %                 MMEM_LAI_s3_SOS_2000_2020 (i,j,N_year)     = sos + 365;
                %                 MMEM_LAI_s3_EOS_2000_2020 (i,j,N_year)     = eos + 365;
                %                 MMEM_LAI_s3_POS_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s3_SPL_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s3_APL_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s3_ALPHA_2000_2020 (i,j,N_year)   = nan;
                %                 MMEM_LAI_s3_BETA_2000_2020 (i,j,N_year)    = nan;
                %                 MMEM_LAI_s3_AMP_2000_2020 (i,j,N_year)     = nan;
                %                 MMEM_LAI_s3_LAIgs_2000_2020 (i,j,N_year)   = NDVI;
                %                 MMEM_LAI_s3_NDVImean_2000_2020 (i,j,N_year) = NDVI/365;
                
            else
                
                MMEM_LAI_s3_SPL_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s3_APL_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s3_ALPHA_2000_2020 (i,j,N_year)   = nan;
                MMEM_LAI_s3_BETA_2000_2020 (i,j,N_year)    = nan;
                MMEM_LAI_s3_AMP_2000_2020 (i,j,N_year)     = nan;
                MMEM_LAI_s3_LAIgs_2000_2020 (i,j,N_year)  = nan;
                
            end
        end
    end
end

save MMEM_LAI_s3_SPL_2000_2020 MMEM_LAI_s3_SPL_2000_2020
save MMEM_LAI_s3_APL_2000_2020 MMEM_LAI_s3_APL_2000_2020
save MMEM_LAI_s3_ALPHA_2000_2020 MMEM_LAI_s3_ALPHA_2000_2020
save MMEM_LAI_s3_BETA_2000_2020 MMEM_LAI_s3_BETA_2000_2020
save MMEM_LAI_s3_AMP_2000_2020 MMEM_LAI_s3_AMP_2000_2020
save MMEM_LAI_s3_LAIgs_2000_2020 MMEM_LAI_s3_LAIgs_2000_2020

% % convert .mat into tiff files
% filepath = 'D:\decompose LAI\s08_define_each_component\geoinfo.tif';
% [Data, R] = geotiffread(filepath);
% info = geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s3_SOS_2000_2020', MMEM_LAI_s3_SOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_EOS_2000_2020', MMEM_LAI_s3_EOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_POS_2000_2020', MMEM_LAI_s3_POS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_SPL_2000_2020', MMEM_LAI_s3_SPL_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_APL_2000_2020', MMEM_LAI_s3_APL_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_ALPHA_2000_2020', MMEM_LAI_s3_ALPHA_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_BETA_2000_2020', MMEM_LAI_s3_BETA_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_AMP_2000_2020', MMEM_LAI_s3_AMP_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_EOS_2000_2020', MMEM_LAI_s3_EOS_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_LAIgs_2000_2020', MMEM_LAI_s3_LAIgs_2000_2020, R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);