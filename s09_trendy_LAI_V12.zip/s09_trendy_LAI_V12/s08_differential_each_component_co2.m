
clear
clc

load('MMEM_LAI_s1_filled.mat')
load('mask_phenological_cycle.mat')

years = 1:19;

% i = 120; j = 582;
parfor i = 1:347
    for j = 1:720
        
        mask = mask_phenological_cycle (i,j);
        
        if mask == 1
            
            alpha = MMEM_LAI_s1_ALPHA_2000_2020_filled (i,j,:);
            beta  = MMEM_LAI_s1_BETA_2000_2020_filled (i,j,:);
            amp   = MMEM_LAI_s1_AMP_2000_2020_filled (i,j,:);
            spl   = MMEM_LAI_s1_SPL_2000_2020_filled (i,j,:);
            apl   = MMEM_LAI_s1_APL_2000_2020_filled (i,j,:);
            lai   = MMEM_LAI_s1_LAIgs_2000_2020_filled (i,j,:);
            
            alpha = alpha (1,:);
            beta  = beta (1,:);
            amp   = amp (1,:);
            spl   = spl (1,:);
            apl   = apl (1,:);
            lai   = lai (1,:);
            
            nan_alpha = length (alpha (isnan (alpha)));
            nan_beta  = length (beta (isnan (beta)));
            
            if nan_alpha == 0 && nan_beta == 0
                
                d_alpha = alpha - mean (alpha);
                d_beta  = beta - mean (beta);
                d_amp   = amp - mean (amp);
                d_spl   = spl - mean (spl);
                d_apl   = apl - mean (apl);
                d_lai   = lai - mean (lai);
                
                component_alpha = spl .* amp .* d_alpha;
                component_beta  = apl .* amp .* d_beta;
                component_amp = (alpha .* spl + beta .* apl) .* d_amp;
                component_spl   = alpha .* amp .* d_spl;
                component_apl   = beta .* amp .* d_apl;
                component_lai   = d_lai;
                
                % Mann–Kendall Tau-b with Sen's method
                significance_alpha = 0.1; % significance level: 95%
                wantplot = 0;    % do not plot
                
                % lai
                datain = [years;component_lai];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                lai_slope_co2  (i,j) = sen;
                lai_sig_co2  (i,j) = sig;
                
                % alpha
                datain = [years;component_alpha];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                alpha_slope_co2  (i,j) = sen;
                alpha_sig_co2 (i,j) = sig;
                
                % spl
                datain = [years;component_spl];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                spl_slope_co2  (i,j) = sen;
                spl_sig_co2 (i,j) = sig;
                
                % apl
                datain = [years;component_apl];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                apl_slope_co2  (i,j) = sen;
                apl_sig_co2 (i,j) = sig;
                
                % amp
                datain = [years;component_amp];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                amp_slope_co2  (i,j) = sen;
                amp_sig_co2 (i,j) = sig;
                
                % beta
                datain = [years;component_beta];
                datain = datain';
                [h, sig, sen] = MannKendall_SenSlope (datain, significance_alpha, wantplot);
                beta_slope_co2  (i,j) = sen;
                beta_sig_co2 (i,j) = sig;
                
            else
                
                lai_slope_co2  (i,j)   = nan;
                lai_sig_co2  (i,j) = nan;
                
                alpha_slope_co2  (i,j) = nan;
                alpha_sig_co2  (i,j) = nan;
                
                spl_slope_co2  (i,j)   = nan;
                spl_sig_co2  (i,j) = nan;
                
                apl_slope_co2  (i,j)   = nan;
                apl_sig_co2  (i,j) = nan;
                
                amp_slope_co2  (i,j)   = nan;
                amp_sig_co2  (i,j) = nan;
                
                beta_slope_co2  (i,j)  = nan;
                beta_sig_co2  (i,j)  = nan;
                
            end
            
        else
            
            lai_slope_co2  (i,j)   = nan;
            lai_sig_co2  (i,j) = nan;
            
            alpha_slope_co2  (i,j) = nan;
            alpha_sig_co2  (i,j) = nan;
            
            spl_slope_co2  (i,j)   = nan;
            spl_sig_co2  (i,j) = nan;
            
            apl_slope_co2  (i,j)   = nan;
            apl_sig_co2  (i,j) = nan;
            
            amp_slope_co2  (i,j)   = nan;
            amp_sig_co2  (i,j) = nan;
            
            beta_slope_co2  (i,j)  = nan;
            beta_sig_co2  (i,j)  = nan;
            
        end
    end
end

% % convert .mat into tiff files
% filepath = 'C:\Users\田家旗\Desktop\decompose LAI\s5_define_each_component\geoinfo_37years.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s1_SPL_2000_2020',MMEM_LAI_s1_SPL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_APL_2000_2020',MMEM_LAI_s1_APL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_ALPHA_2000_2020',MMEM_LAI_s1_ALPHA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_BETA_2000_2020',MMEM_LAI_s1_BETA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_AMP_2000_2020',MMEM_LAI_s1_AMP_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_LAI_2000_2020',MMEM_LAI_s1_LAI_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);