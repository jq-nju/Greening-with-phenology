%% s1

clear
clc

load('JULES_LAI_s1_2000_2020_05degree.mat')
load('VISIT_LAI_s1_2000_2020_05degree.mat')
load('CLASSIC_LAI_s1_2000_2020_05degree.mat')
load('OCN_LAI_s1_2000_2020_05degree.mat')
load('LPJ_GUESS_LAI_s1_2000_2020_05degree.mat')
load('SDGVM_LAI_s1_2000_2020_05degree.mat')
load('YIBs_LAI_s1_2000_2020_05degree.mat')
load('ORCHIDEE_LAI_s1_2000_2020_05degree.mat')
load('CABLE_LAI_s1_2000_2020_05degree.mat')

MMEM_LAI_s1 = zeros (347,720,252);
MMEM = zeros (252,9);

for i = 1:347
    for j = 1:720

        JULES = JULES_LAI_s1_2000_2020_05degree (i,j,:);
        VISIT = VISIT_LAI_s1_2000_2020_05degree (i,j,:);
        CLASSIC = CLASSIC_LAI_s1_2000_2020_05degree (i,j,:);
        OCN = OCN_LAI_s1_2000_2020_05degree (i,j,:);
        LPJ = LPJ_GUESS_LAI_s1_2000_2020_05degree (i,j,:);
        SDGVM = SDGVM_LAI_s1_2000_2020_05degree (i,j,:);
        YIBs = YIBs_LAI_s1_2000_2020_05degree (i,j,:);
        ORCHIDEE = ORCHIDEE_LAI_s1_2000_2020_05degree (i,j,:);
        CABLE = CABLE_LAI_s1_2000_2020_05degree(i,j,:);

        MMEM (:,1)  = JULES (1,:);
        MMEM (:,2)  = VISIT (1,:);
        MMEM (:,3)  = CLASSIC (1,:);
        MMEM (:,4)  = OCN (1,:);
        MMEM (:,5)  = LPJ (1,:);
        MMEM (:,6)  = SDGVM (1,:);
        MMEM (:,7)  = YIBs (1,:);
        MMEM (:,8)  = ORCHIDEE (1,:);
        MMEM (:,9) = CABLE (1,:);

        MMEM (MMEM >= 9) = nan;
        MMEM (MMEM <= 0)  = nan;

        MMEM_LAI_s1 (i,j,:) = nanmean (MMEM,2);
    end
end

save MMEM_LAI_s1 MMEM_LAI_s1


%% s2

clear
clc

load('JULES_LAI_s2_2000_2020_05degree.mat')
load('VISIT_LAI_s2_2000_2020_05degree.mat')
load('CLASSIC_LAI_s2_2000_2020_05degree.mat')
load('OCN_LAI_s2_2000_2020_05degree.mat')
load('LPJ_GUESS_LAI_s2_2000_2020_05degree.mat')
load('SDGVM_LAI_s2_2000_2020_05degree.mat')
load('YIBs_LAI_s2_2000_2020_05degree.mat')
load('ORCHIDEE_LAI_s2_2000_2020_05degree.mat')
load('CABLE_LAI_s2_2000_2020_05degree.mat')

MMEM_LAI_s2 = zeros (347,720,252);
MMEM = zeros (252,9);

for i = 1:347
    for j = 1:720

        JULES = JULES_LAI_s2_2000_2020_05degree (i,j,:);
        VISIT = VISIT_LAI_s2_2000_2020_05degree (i,j,:);
        CLASSIC = CLASSIC_LAI_s2_2000_2020_05degree (i,j,:);
        OCN = OCN_LAI_s2_2000_2020_05degree (i,j,:);
        LPJ = LPJ_GUESS_LAI_s2_2000_2020_05degree (i,j,:);
        SDGVM = SDGVM_LAI_s2_2000_2020_05degree (i,j,:);
        YIBs = YIBs_LAI_s2_2000_2020_05degree (i,j,:);
        ORCHIDEE = ORCHIDEE_LAI_s2_2000_2020_05degree (i,j,:);
        CABLE = CABLE_LAI_s2_2000_2020_05degree(i,j,:);

        MMEM (:,1)  = JULES (1,:);
        MMEM (:,2)  = VISIT (1,:);
        MMEM (:,3)  = CLASSIC (1,:);
        MMEM (:,4)  = OCN (1,:);
        MMEM (:,5)  = LPJ (1,:);
        MMEM (:,6)  = SDGVM (1,:);
        MMEM (:,7)  = YIBs (1,:);
        MMEM (:,8)  = ORCHIDEE (1,:);
        MMEM (:,9) = CABLE (1,:);

        MMEM (MMEM >= 9) = nan;
        MMEM (MMEM <= 0)  = nan;

        MMEM_LAI_s2 (i,j,:) = nanmean (MMEM,2);
    end
end

save MMEM_LAI_s2 MMEM_LAI_s2

%% s3

clear
clc

load('JULES_LAI_s3_2000_2020_05degree.mat')
load('VISIT_LAI_s3_2000_2020_05degree.mat')
load('CLASSIC_LAI_s3_2000_2020_05degree.mat')
load('OCN_LAI_s3_2000_2020_05degree.mat')
load('LPJ_GUESS_LAI_s3_2000_2020_05degree.mat')
load('SDGVM_LAI_s3_2000_2020_05degree.mat')
load('YIBs_LAI_s3_2000_2020_05degree.mat')
load('ORCHIDEE_LAI_s3_2000_2020_05degree.mat')
load('CABLE_LAI_s3_2000_2020_05degree.mat')

MMEM_LAI_s3 = zeros (347,720,252);
MMEM = zeros (252,9);

for i = 1:347
    for j = 1:720

        JULES = JULES_LAI_s3_2000_2020_05degree (i,j,:);
        VISIT = VISIT_LAI_s3_2000_2020_05degree (i,j,:);
        CLASSIC = CLASSIC_LAI_s3_2000_2020_05degree (i,j,:);
        OCN = OCN_LAI_s3_2000_2020_05degree (i,j,:);
        LPJ = LPJ_GUESS_LAI_s3_2000_2020_05degree (i,j,:);
        SDGVM = SDGVM_LAI_s3_2000_2020_05degree (i,j,:);
        YIBs = YIBs_LAI_s3_2000_2020_05degree (i,j,:);
        ORCHIDEE = ORCHIDEE_LAI_s3_2000_2020_05degree (i,j,:);
        CABLE = CABLE_LAI_s3_2000_2020_05degree(i,j,:);

        MMEM (:,1)  = JULES (1,:);
        MMEM (:,2)  = VISIT (1,:);
        MMEM (:,3)  = CLASSIC (1,:);
        MMEM (:,4)  = OCN (1,:);
        MMEM (:,5)  = LPJ (1,:);
        MMEM (:,6)  = SDGVM (1,:);
        MMEM (:,7)  = YIBs (1,:);
        MMEM (:,8)  = ORCHIDEE (1,:);
        MMEM (:,9) = CABLE (1,:);

        MMEM (MMEM >= 9) = nan;
        MMEM (MMEM <= 0)  = nan;

        MMEM_LAI_s3 (i,j,:) = nanmean (MMEM,2);
    end
end

save MMEM_LAI_s3 MMEM_LAI_s3