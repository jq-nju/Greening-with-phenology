
clear
clc

load('MMEM_LAI_s1.mat')

% fill missing values (e.g., NAN)
MMEM_LAI_s1_ALPHA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        ALPHA = MMEM_LAI_s1_ALPHA_2000_2020 (i,j,:);
        ALPHA = ALPHA (1,:);
        
        ALPHA (ALPHA > 1) = nan;
        ALPHA (ALPHA < 0) = nan;
        
        nan_length = length (ALPHA (isnan (ALPHA)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (ALPHA) - 3*nanstd (ALPHA);
            outlier_2 = nanmean (ALPHA) + 3*nanstd (ALPHA);
            
            ALPHA (ALPHA < outlier_1) = nan;
            ALPHA (ALPHA > outlier_2) = nan;
            
            MMEM_LAI_s1_ALPHA_2000_2020_filled (i,j,:) = fillmissing(ALPHA,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s1_ALPHA_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s1_ALPHA_2000_2020_filled MMEM_LAI_s1_ALPHA_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s1_BETA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        BETA = MMEM_LAI_s1_BETA_2000_2020 (i,j,:);
        BETA = BETA (1,:);
        
        BETA (BETA > 1) = nan;
        BETA (BETA < 0) = nan;
        
        nan_length = length (BETA (isnan (BETA)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (BETA) - 3*nanstd (BETA);
            outlier_2 = nanmean (BETA) + 3*nanstd (BETA);
            
            BETA (BETA < outlier_1) = nan;
            BETA (BETA > outlier_2) = nan;
            
            MMEM_LAI_s1_BETA_2000_2020_filled (i,j,:) = fillmissing(BETA,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s1_BETA_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s1_BETA_2000_2020_filled MMEM_LAI_s1_BETA_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s1_AMP_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        AMP = MMEM_LAI_s1_AMP_2000_2020 (i,j,:);
        AMP = AMP (1,:);
        
        nan_length = length (AMP (isnan (AMP)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (AMP) - 3*nanstd (AMP);
            outlier_2 = nanmean (AMP) + 3*nanstd (AMP);
            
            AMP (AMP < outlier_1) = nan;
            AMP (AMP > outlier_2) = nan;
            
            MMEM_LAI_s1_AMP_2000_2020_filled (i,j,:) = fillmissing(AMP,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s1_AMP_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s1_AMP_2000_2020_filled MMEM_LAI_s1_AMP_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s1_SPL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        spl = MMEM_LAI_s1_SPL_2000_2020 (i,j,:);
        spl = spl (1,:);
        
        nan_length = length (spl (isnan (spl)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (spl) - 3*nanstd (spl);
            outlier_2 = nanmean (spl) + 3*nanstd (spl);
            
            spl (spl < outlier_1) = nan;
            spl (spl > outlier_2) = nan;
            
            MMEM_LAI_s1_SPL_2000_2020_filled (i,j,:) = fillmissing(spl,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s1_SPL_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s1_SPL_2000_2020_filled MMEM_LAI_s1_SPL_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s1_APL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        APL = MMEM_LAI_s1_APL_2000_2020 (i,j,:);
        APL = APL (1,:);
        
        nan_length = length (APL (isnan (APL)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (APL) - 3*nanstd (APL);
            outlier_2 = nanmean (APL) + 3*nanstd (APL);
            
            APL (APL < outlier_1) = nan;
            APL (APL > outlier_2) = nan;
            
            MMEM_LAI_s1_APL_2000_2020_filled (i,j,:) = fillmissing(APL,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s1_APL_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s1_APL_2000_2020_filled MMEM_LAI_s1_APL_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s1_LAIgs_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        LAIgs = MMEM_LAI_s1_LAIgs_2000_2020 (i,j,:);
        LAIgs = LAIgs (1,:);
        
        nan_length = length (LAIgs (isnan (LAIgs)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (LAIgs) - 3*nanstd (LAIgs);
            outlier_2 = nanmean (LAIgs) + 3*nanstd (LAIgs);
            
            LAIgs (LAIgs < outlier_1) = nan;
            LAIgs (LAIgs > outlier_2) = nan;
            
            MMEM_LAI_s1_LAIgs_2000_2020_filled (i,j,:) = fillmissing(LAIgs,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s1_LAIgs_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s1_LAIgs_2000_2020_filled MMEM_LAI_s1_LAIgs_2000_2020_filled

% % convert .mat into tiff files
% filepath = 'C:\Users\田家旗\Desktop\decompose LAI\s5_define_each_component\geoinfo_37years.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s1_SPL_2000_2020',MMEM_LAI_s1_SPL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_APL_2000_2020',MMEM_LAI_s1_APL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_ALPHA_2000_2020',MMEM_LAI_s1_ALPHA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_BETA_2000_2020',MMEM_LAI_s1_BETA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_AMP_2000_2020',MMEM_LAI_s1_AMP_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s1_LAI_2000_2020',MMEM_LAI_s1_LAI_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);


clear
clc

load('MMEM_LAI_s2.mat')

% fill missing values (e.g., NAN)
MMEM_LAI_s2_ALPHA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        ALPHA = MMEM_LAI_s2_ALPHA_2000_2020 (i,j,:);
        ALPHA = ALPHA (1,:);
        
        ALPHA (ALPHA > 1) = nan;
        ALPHA (ALPHA < 0) = nan;
        
        nan_length = length (ALPHA (isnan (ALPHA)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (ALPHA) - 3*nanstd (ALPHA);
            outlier_2 = nanmean (ALPHA) + 3*nanstd (ALPHA);
            
            ALPHA (ALPHA < outlier_1) = nan;
            ALPHA (ALPHA > outlier_2) = nan;
            
            MMEM_LAI_s2_ALPHA_2000_2020_filled (i,j,:) = fillmissing(ALPHA,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s2_ALPHA_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s2_ALPHA_2000_2020_filled MMEM_LAI_s2_ALPHA_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s2_BETA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        BETA = MMEM_LAI_s2_BETA_2000_2020 (i,j,:);
        BETA = BETA (1,:);
        
        BETA (BETA > 1) = nan;
        BETA (BETA < 0) = nan;
        
        nan_length = length (BETA (isnan (BETA)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (BETA) - 3*nanstd (BETA);
            outlier_2 = nanmean (BETA) + 3*nanstd (BETA);
            
            BETA (BETA < outlier_1) = nan;
            BETA (BETA > outlier_2) = nan;
            
            MMEM_LAI_s2_BETA_2000_2020_filled (i,j,:) = fillmissing(BETA,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s2_BETA_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s2_BETA_2000_2020_filled MMEM_LAI_s2_BETA_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s2_AMP_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        AMP = MMEM_LAI_s2_AMP_2000_2020 (i,j,:);
        AMP = AMP (1,:);
        
        nan_length = length (AMP (isnan (AMP)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (AMP) - 3*nanstd (AMP);
            outlier_2 = nanmean (AMP) + 3*nanstd (AMP);
            
            AMP (AMP < outlier_1) = nan;
            AMP (AMP > outlier_2) = nan;
            
            MMEM_LAI_s2_AMP_2000_2020_filled (i,j,:) = fillmissing(AMP,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s2_AMP_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s2_AMP_2000_2020_filled MMEM_LAI_s2_AMP_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s2_SPL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        spl = MMEM_LAI_s2_SPL_2000_2020 (i,j,:);
        spl = spl (1,:);
        
        nan_length = length (spl (isnan (spl)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (spl) - 3*nanstd (spl);
            outlier_2 = nanmean (spl) + 3*nanstd (spl);
            
            spl (spl < outlier_1) = nan;
            spl (spl > outlier_2) = nan;
            
            MMEM_LAI_s2_SPL_2000_2020_filled (i,j,:) = fillmissing(spl,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s2_SPL_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s2_SPL_2000_2020_filled MMEM_LAI_s2_SPL_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s2_APL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        APL = MMEM_LAI_s2_APL_2000_2020 (i,j,:);
        APL = APL (1,:);
        
        nan_length = length (APL (isnan (APL)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (APL) - 3*nanstd (APL);
            outlier_2 = nanmean (APL) + 3*nanstd (APL);
            
            APL (APL < outlier_1) = nan;
            APL (APL > outlier_2) = nan;
            
            MMEM_LAI_s2_APL_2000_2020_filled (i,j,:) = fillmissing(APL,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s2_APL_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s2_APL_2000_2020_filled MMEM_LAI_s2_APL_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s2_LAIgs_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        LAIgs = MMEM_LAI_s2_LAIgs_2000_2020 (i,j,:);
        LAIgs = LAIgs (1,:);
        
        nan_length = length (LAIgs (isnan (LAIgs)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (LAIgs) - 3*nanstd (LAIgs);
            outlier_2 = nanmean (LAIgs) + 3*nanstd (LAIgs);
            
            LAIgs (LAIgs < outlier_1) = nan;
            LAIgs (LAIgs > outlier_2) = nan;
            
            MMEM_LAI_s2_LAIgs_2000_2020_filled (i,j,:) = fillmissing(LAIgs,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s2_LAIgs_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s2_LAIgs_2000_2020_filled MMEM_LAI_s2_LAIgs_2000_2020_filled

% % convert .mat into tiff files
% filepath = 'C:\Users\田家旗\Desktop\decompose LAI\s5_define_each_component\geoinfo_37years.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s2_SPL_2000_2020',MMEM_LAI_s2_SPL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_APL_2000_2020',MMEM_LAI_s2_APL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_ALPHA_2000_2020',MMEM_LAI_s2_ALPHA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_BETA_2000_2020',MMEM_LAI_s2_BETA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_AMP_2000_2020',MMEM_LAI_s2_AMP_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s2_LAI_2000_2020',MMEM_LAI_s2_LAI_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);


clear
clc

load('MMEM_LAI_s3.mat')

% fill missing values (e.g., NAN)
MMEM_LAI_s3_ALPHA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        ALPHA = MMEM_LAI_s3_ALPHA_2000_2020 (i,j,:);
        ALPHA = ALPHA (1,:);
        
        ALPHA (ALPHA > 1) = nan;
        ALPHA (ALPHA < 0) = nan;
        
        nan_length = length (ALPHA (isnan (ALPHA)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (ALPHA) - 3*nanstd (ALPHA);
            outlier_2 = nanmean (ALPHA) + 3*nanstd (ALPHA);
            
            ALPHA (ALPHA < outlier_1) = nan;
            ALPHA (ALPHA > outlier_2) = nan;
            
            MMEM_LAI_s3_ALPHA_2000_2020_filled (i,j,:) = fillmissing(ALPHA,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s3_ALPHA_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s3_ALPHA_2000_2020_filled MMEM_LAI_s3_ALPHA_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s3_BETA_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        BETA = MMEM_LAI_s3_BETA_2000_2020 (i,j,:);
        BETA = BETA (1,:);
        
        BETA (BETA > 1) = nan;
        BETA (BETA < 0) = nan;
        
        nan_length = length (BETA (isnan (BETA)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (BETA) - 3*nanstd (BETA);
            outlier_2 = nanmean (BETA) + 3*nanstd (BETA);
            
            BETA (BETA < outlier_1) = nan;
            BETA (BETA > outlier_2) = nan;
            
            MMEM_LAI_s3_BETA_2000_2020_filled (i,j,:) = fillmissing(BETA,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s3_BETA_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s3_BETA_2000_2020_filled MMEM_LAI_s3_BETA_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s3_AMP_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        AMP = MMEM_LAI_s3_AMP_2000_2020 (i,j,:);
        AMP = AMP (1,:);
        
        nan_length = length (AMP (isnan (AMP)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (AMP) - 3*nanstd (AMP);
            outlier_2 = nanmean (AMP) + 3*nanstd (AMP);
            
            AMP (AMP < outlier_1) = nan;
            AMP (AMP > outlier_2) = nan;
            
            MMEM_LAI_s3_AMP_2000_2020_filled (i,j,:) = fillmissing(AMP,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s3_AMP_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s3_AMP_2000_2020_filled MMEM_LAI_s3_AMP_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s3_SPL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        spl = MMEM_LAI_s3_SPL_2000_2020 (i,j,:);
        spl = spl (1,:);
        
        nan_length = length (spl (isnan (spl)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (spl) - 3*nanstd (spl);
            outlier_2 = nanmean (spl) + 3*nanstd (spl);
            
            spl (spl < outlier_1) = nan;
            spl (spl > outlier_2) = nan;
            
            MMEM_LAI_s3_SPL_2000_2020_filled (i,j,:) = fillmissing(spl,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s3_SPL_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s3_SPL_2000_2020_filled MMEM_LAI_s3_SPL_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s3_APL_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        APL = MMEM_LAI_s3_APL_2000_2020 (i,j,:);
        APL = APL (1,:);
        
        nan_length = length (APL (isnan (APL)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (APL) - 3*nanstd (APL);
            outlier_2 = nanmean (APL) + 3*nanstd (APL);
            
            APL (APL < outlier_1) = nan;
            APL (APL > outlier_2) = nan;
            
            MMEM_LAI_s3_APL_2000_2020_filled (i,j,:) = fillmissing(APL,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s3_APL_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s3_APL_2000_2020_filled MMEM_LAI_s3_APL_2000_2020_filled

% fill missing values (e.g., NAN)
MMEM_LAI_s3_LAIgs_2000_2020_filled = zeros (347,720,19);

for i = 1:347
    for j = 1:720
        
        LAIgs = MMEM_LAI_s3_LAIgs_2000_2020 (i,j,:);
        LAIgs = LAIgs (1,:);
        
        nan_length = length (LAIgs (isnan (LAIgs)));
        
        if nan_length ~= 19
            
            outlier_1 = nanmean (LAIgs) - 3*nanstd (LAIgs);
            outlier_2 = nanmean (LAIgs) + 3*nanstd (LAIgs);
            
            LAIgs (LAIgs < outlier_1) = nan;
            LAIgs (LAIgs > outlier_2) = nan;
            
            MMEM_LAI_s3_LAIgs_2000_2020_filled (i,j,:) = fillmissing(LAIgs,'linear','EndValues','nearest');
            
        else
            
            MMEM_LAI_s3_LAIgs_2000_2020_filled (i,j,:) = nan;
            
        end
        
    end
end

save MMEM_LAI_s3_LAIgs_2000_2020_filled MMEM_LAI_s3_LAIgs_2000_2020_filled

% % convert .mat into tiff files
% filepath = 'C:\Users\田家旗\Desktop\decompose LAI\s5_define_each_component\geoinfo_37years.tif';
% [Data, R] = geotiffread(filepath);
% info=geotiffinfo(filepath);
% geotiffwrite('MMEM_LAI_s3_SPL_2000_2020',MMEM_LAI_s3_SPL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_APL_2000_2020',MMEM_LAI_s3_APL_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_ALPHA_2000_2020',MMEM_LAI_s3_ALPHA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_BETA_2000_2020',MMEM_LAI_s3_BETA_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_AMP_2000_2020',MMEM_LAI_s3_AMP_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
% geotiffwrite('MMEM_LAI_s3_LAI_2000_2020',MMEM_LAI_s3_LAI_2000_2020,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);